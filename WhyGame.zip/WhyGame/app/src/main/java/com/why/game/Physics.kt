package com.why.game

import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** محاكاة فيزياء Verlet بسيطة (بلا مكتبات)، الوحدات "وحدات عالم" عرضها 1000. */
class Pt(var x: Float, var y: Float, val r: Float, val owner: Int = 0) {
    var px = x
    var py = y
    var lastHit = 0f
}

class Stick(val a: Pt, val b: Pt, val len: Float)

class Box(val x: Float, val y: Float, val w: Float, val h: Float, val bounce: Float = 0.15f, val pad: Boolean = false)

class Seg(var ax: Float, var ay: Float, var bx: Float, var by: Float, val th: Float, val bounce: Float = 0.2f)

/** شكل للرسم فقط (النجوم، القلوب، المربعات...). الاصطدام يتم عبر Seg لحوافه. */
class Shape(val pts: FloatArray, val color: Int, val circle: Boolean = false)

class Spinner(val cx: Float, val cy: Float, val half: Float, val speed: Float) {
    var ang = 0f
    val seg = Seg(cx - half, cy, cx + half, cy, 9f, 0.3f)
    fun update(dt: Float) {
        ang += speed * dt
        val dx = cos(ang) * half
        val dy = sin(ang) * half
        seg.ax = cx - dx; seg.ay = cy - dy
        seg.bx = cx + dx; seg.by = cy + dy
    }
}

class Rope(val ax: Float, val ay: Float, val pt: Pt, val len: Float)

class Impact(val x: Float, val y: Float, val speed: Float, val index: Int, val bounce: Float)

class World(val w: Float, val h: Float) {
    companion object {
        const val DT = 1f / 120f
        const val PTS = 14
    }

    val boxes = ArrayList<Box>()
    val segs = ArrayList<Seg>()
    val shapes = ArrayList<Shape>()
    val spinners = ArrayList<Spinner>()
    val points = ArrayList<Pt>()
    val sticks = ArrayList<Stick>()
    var rope: Rope? = null
    var gravity = 1800f
    var friction = 0.03f
    var frozen = false
    var multi = false
    var onImpact: ((Impact) -> Unit)? = null

    /** نقطة يمسكها الإصبع وموضع الإصبع. */
    var grab: Pt? = null
    var gx = 0f
    var gy = 0f

    fun launch(vx: Float, vy: Float) {
        frozen = false
        for (p in points) {
            p.px = p.x - vx * DT
            p.py = p.y - vy * DT
        }
    }

    fun nearest(x: Float, y: Float, maxD: Float): Pt? {
        var best: Pt? = null
        var bd = maxD
        for (p in points) {
            val d = hypot(p.x - x, p.y - y)
            if (d < bd) { bd = d; best = p }
        }
        return best
    }

    /** دفعة سرعة للنقاط القريبة من (cx,cy). تعيد قوة الإصابة 0..1 (0 = أخطأ). */
    fun impulse(cx: Float, cy: Float, radius: Float, speed: Float, down: Boolean, only: Int = -1, except: Int = -1): Float {
        if (frozen) return 0f
        var best = 0f
        for (p in points) {
            if (only >= 0 && p.owner != only) continue
            if (except >= 0 && p.owner == except) continue
            val dx = p.x - cx
            val dy = p.y - cy
            val d = hypot(dx, dy)
            if (d >= radius) continue
            val f = (1f - d / radius) * speed
            val nx: Float
            val ny: Float
            if (down) { nx = 0f; ny = 1f }
            else if (d > 1f) { nx = dx / d; ny = dy / d }
            else { nx = 0f; ny = -1f }
            p.px -= nx * f * DT
            p.py -= ny * f * DT
            best = maxOf(best, 1f - d / radius)
        }
        return best
    }

    fun step(dt: Float) {
        if (frozen) return
        for (s in spinners) s.update(dt)
        val g = gravity * dt * dt
        for (p in points) {
            var vx = (p.x - p.px) * 0.999f
            var vy = (p.y - p.py) * 0.999f
            val sp = hypot(vx, vy)
            if (sp > 60f) { vx *= 60f / sp; vy *= 60f / sp }
            p.px = p.x
            p.py = p.y
            p.x += vx
            p.y += vy + g
            if (p.lastHit > 0f) p.lastHit -= dt
        }
        grab?.let { q ->
            q.x += (gx - q.x) * 0.3f
            q.y += (gy - q.y) * 0.3f
        }
        repeat(6) {
            solveSticks()
            solveRope()
            if (multi) charCollide()
            collide(dt)
        }
    }

    private fun solveSticks() {
        for (s in sticks) {
            val dx = s.b.x - s.a.x
            val dy = s.b.y - s.a.y
            val d = sqrt(dx * dx + dy * dy)
            if (d < 1e-5f) continue
            val k = (d - s.len) / d * 0.5f
            s.a.x += dx * k; s.a.y += dy * k
            s.b.x -= dx * k; s.b.y -= dy * k
        }
    }

    private fun solveRope() {
        val r = rope ?: return
        val dx = r.pt.x - r.ax
        val dy = r.pt.y - r.ay
        val d = sqrt(dx * dx + dy * dy)
        if (d > r.len) {
            val k = r.len / d
            r.pt.x = r.ax + dx * k
            r.pt.y = r.ay + dy * k
        }
    }

    /** تنافر ناعم بين نقاط شخصيات مختلفة (النقاط مرتبة في كتل من PTS). */
    private fun charCollide() {
        val n = points.size
        for (i in 0 until n) {
            val a = points[i]
            var j = (i / PTS + 1) * PTS
            while (j < n) {
                val b = points[j]
                val dx = b.x - a.x
                val dy = b.y - a.y
                val m = a.r + b.r
                if (dx > m || dx < -m || dy > m || dy < -m) { j++; continue }
                val d2 = dx * dx + dy * dy
                if (d2 < m * m && d2 > 1e-6f) {
                    val d = sqrt(d2)
                    val push = (m - d) * 0.25f
                    val nx = dx / d
                    val ny = dy / d
                    a.x -= nx * push; a.y -= ny * push
                    b.x += nx * push; b.y += ny * push
                }
                j++
            }
        }
    }

    private fun collide(dt: Float) {
        for (i in points.indices) {
            val p = points[i]
            for (b in boxes) boxCollide(i, p, b, dt)
            for (s in segs) segCollide(i, p, s, dt)
            for (sp in spinners) segCollide(i, p, sp.seg, dt)
        }
    }

    private fun boxCollide(i: Int, p: Pt, b: Box, dt: Float) {
        val l = b.x - p.r
        val r = b.x + b.w + p.r
        val t = b.y - p.r
        val bt = b.y + b.h + p.r
        if (p.x <= l || p.x >= r || p.y <= t || p.y >= bt) return
        val dl = p.x - l
        val dr = r - p.x
        val dtp = p.y - t
        val db = bt - p.y
        val m = min(min(dl, dr), min(dtp, db))
        val vx = p.x - p.px
        val vy = p.y - p.py
        var nx = 0f
        var ny = 0f
        when (m) {
            dl -> { nx = -1f; p.x = l }
            dr -> { nx = 1f; p.x = r }
            dtp -> { ny = -1f; p.y = t }
            else -> { ny = 1f; p.y = bt }
        }
        respond(i, p, vx, vy, nx, ny, b.bounce, dt)
    }

    private fun segCollide(i: Int, p: Pt, s: Seg, dt: Float) {
        val rad = p.r + s.th
        if (p.y < minOf(s.ay, s.by) - rad || p.y > maxOf(s.ay, s.by) + rad) return
        if (p.x < minOf(s.ax, s.bx) - rad || p.x > maxOf(s.ax, s.bx) + rad) return
        val abx = s.bx - s.ax
        val aby = s.by - s.ay
        val l2 = abx * abx + aby * aby
        var t = if (l2 > 0f) ((p.x - s.ax) * abx + (p.y - s.ay) * aby) / l2 else 0f
        if (t < 0f) t = 0f
        if (t > 1f) t = 1f
        val cx = s.ax + abx * t
        val cy = s.ay + aby * t
        val dx = p.x - cx
        val dy = p.y - cy
        val d2 = dx * dx + dy * dy
        if (d2 >= rad * rad) return
        val d = sqrt(d2)
        val nx = if (d > 1e-4f) dx / d else 0f
        val ny = if (d > 1e-4f) dy / d else -1f
        val vx = p.x - p.px
        val vy = p.y - p.py
        p.x = cx + nx * rad
        p.y = cy + ny * rad
        respond(i, p, vx, vy, nx, ny, s.bounce, dt)
    }

    private fun respond(i: Int, p: Pt, vx: Float, vy: Float, nx: Float, ny: Float, e: Float, dt: Float) {
        val vn = vx * nx + vy * ny
        if (vn >= 0f) {
            p.px = p.x - vx
            p.py = p.y - vy
            return
        }
        var nvx = vx - (1f + e) * vn * nx
        var nvy = vy - (1f + e) * vn * ny
        val tx = -ny
        val ty = nx
        val vt = nvx * tx + nvy * ty
        nvx -= vt * tx * friction
        nvy -= vt * ty * friction
        p.px = p.x - nvx
        p.py = p.y - nvy
        val speed = -vn / dt
        if (speed > 250f && p.lastHit <= 0f) {
            p.lastHit = 0.2f
            onImpact?.invoke(Impact(p.x, p.y, speed, i, e))
        }
    }
}

private fun dist(a: Pt, b: Pt) = hypot(a.x - b.x, a.y - b.y)

/** شخصية كرتونية رخوة: 14 نقطة موصولة بعصيّ. k = مقياس الحجم. */
class Ragdoll(world: World?, cx: Float, cy: Float, val k: Float, owner: Int = 0) {
    val head = Pt(cx, cy - 66f * k, 13f * k, owner)
    val neck = Pt(cx, cy - 48f * k, 5f * k, owner)
    val shL = Pt(cx - 14f * k, cy - 48f * k, 6f * k, owner)
    val shR = Pt(cx + 14f * k, cy - 48f * k, 6f * k, owner)
    val hipL = Pt(cx - 9f * k, cy, 7f * k, owner)
    val hipR = Pt(cx + 9f * k, cy, 7f * k, owner)
    val elL = Pt(cx - 26f * k, cy - 26f * k, 5f * k, owner)
    val elR = Pt(cx + 26f * k, cy - 26f * k, 5f * k, owner)
    val haL = Pt(cx - 30f * k, cy - 4f * k, 5f * k, owner)
    val haR = Pt(cx + 30f * k, cy - 4f * k, 5f * k, owner)
    val knL = Pt(cx - 10f * k, cy + 28f * k, 6f * k, owner)
    val knR = Pt(cx + 10f * k, cy + 28f * k, 6f * k, owner)
    val ftL = Pt(cx - 10f * k, cy + 58f * k, 6f * k, owner)
    val ftR = Pt(cx + 10f * k, cy + 58f * k, 6f * k, owner)

    val pts = listOf(head, neck, shL, shR, hipL, hipR, elL, elR, haL, haR, knL, knR, ftL, ftR)
    val sticks: List<Stick>

    init {
        val pairs = listOf(
            head to neck, neck to shL, neck to shR, shL to shR,
            hipL to hipR, shL to hipL, shR to hipR, shL to hipR, shR to hipL,
            shL to elL, elL to haL, shR to elR, elR to haR,
            hipL to knL, knL to ftL, hipR to knR, knR to ftR
        )
        sticks = pairs.map { Stick(it.first, it.second, dist(it.first, it.second)) }
        if (world != null) {
            world.points.addAll(pts)
            world.sticks.addAll(sticks)
        }
    }
}
