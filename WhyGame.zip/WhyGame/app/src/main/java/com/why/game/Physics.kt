package com.why.game

import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.cos
import kotlin.math.sin

/** محاكاة فيزياء Verlet بسيطة (بلا مكتبات)، الوحدات "وحدات عالم" عرضها 1000. */
class Pt(var x: Float, var y: Float, val r: Float) {
    var px = x
    var py = y
    var lastHit = 0f
}

class Stick(val a: Pt, val b: Pt, val len: Float)

class Box(val x: Float, val y: Float, val w: Float, val h: Float, val bounce: Float = 0.15f, val pad: Boolean = false)

class Seg(var ax: Float, var ay: Float, var bx: Float, var by: Float, val th: Float, val bounce: Float = 0.2f)

class Spinner(val cx: Float, val cy: Float, val half: Float, val speed: Float) {
    var ang = 0f
    val seg = Seg(cx - half, cy, cx + half, cy, 9f, 0.3f)
    fun update(dt: Float) {
        ang += speed * dt
        val dx = cos(ang) * half
        val dy = sin(ang) * half
        seg.ax = cx - dx; seg.ay = cy - dy
        seg.bx = cx + dx; seg.by = cy + dy
    }
}

class Rope(val ax: Float, val ay: Float, val pt: Pt, val len: Float)

class Impact(val x: Float, val y: Float, val speed: Float, val index: Int)

class World(val w: Float, val h: Float) {
    companion object {
        const val DT = 1f / 120f
    }

    val boxes = ArrayList<Box>()
    val segs = ArrayList<Seg>()
    val spinners = ArrayList<Spinner>()
    val points = ArrayList<Pt>()
    val sticks = ArrayList<Stick>()
    var rope: Rope? = null
    var gravity = 1800f
    var friction = 0.08f
    var frozen = false
    var onImpact: ((Impact) -> Unit)? = null

    fun launch(vx: Float, vy: Float) {
        frozen = false
        for (p in points) {
            p.px = p.x - vx * DT
            p.py = p.y - vy * DT
        }
    }

    fun step(dt: Float) {
        if (frozen) return
        for (s in spinners) s.update(dt)
        val g = gravity * dt * dt
        for (p in points) {
            var vx = (p.x - p.px) * 0.999f
            var vy = (p.y - p.py) * 0.999f
            val sp = hypot(vx, vy)
            if (sp > 60f) { vx *= 60f / sp; vy *= 60f / sp }
            p.px = p.x
            p.py = p.y
            p.x += vx
            p.y += vy + g
            if (p.lastHit > 0f) p.lastHit -= dt
        }
        repeat(6) {
            solveSticks()
            solveRope()
            collide(dt)
        }
    }

    private fun solveSticks() {
        for (s in sticks) {
            val dx = s.b.x - s.a.x
            val dy = s.b.y - s.a.y
            val d = sqrt(dx * dx + dy * dy)
            if (d < 1e-5f) continue
            val k = (d - s.len) / d * 0.5f
            s.a.x += dx * k; s.a.y += dy * k
            s.b.x -= dx * k; s.b.y -= dy * k
        }
    }

    private fun solveRope() {
        val r = rope ?: return
        val dx = r.pt.x - r.ax
        val dy = r.pt.y - r.ay
        val d = sqrt(dx * dx + dy * dy)
        if (d > r.len) {
            val k = r.len / d
            r.pt.x = r.ax + dx * k
            r.pt.y = r.ay + dy * k
        }
    }

    private fun collide(dt: Float) {
        for (i in points.indices) {
            val p = points[i]
            for (b in boxes) boxCollide(i, p, b, dt)
            for (s in segs) segCollide(i, p, s, dt)
            for (sp in spinners) segCollide(i, p, sp.seg, dt)
        }
    }

    private fun boxCollide(i: Int, p: Pt, b: Box, dt: Float) {
        val l = b.x - p.r
        val r = b.x + b.w + p.r
        val t = b.y - p.r
        val bt = b.y + b.h + p.r
        if (p.x <= l || p.x >= r || p.y <= t || p.y >= bt) return
        val dl = p.x - l
        val dr = r - p.x
        val dtp = p.y - t
        val db = bt - p.y
        val m = min(min(dl, dr), min(dtp, db))
        val vx = p.x - p.px
        val vy = p.y - p.py
        var nx = 0f
        var ny = 0f
        when (m) {
            dl -> { nx = -1f; p.x = l }
            dr -> { nx = 1f; p.x = r }
            dtp -> { ny = -1f; p.y = t }
            else -> { ny = 1f; p.y = bt }
        }
        respond(i, p, vx, vy, nx, ny, b.bounce, dt)
    }

    private fun segCollide(i: Int, p: Pt, s: Seg, dt: Float) {
        val abx = s.bx - s.ax
        val aby = s.by - s.ay
        val l2 = abx * abx + aby * aby
        var t = if (l2 > 0f) ((p.x - s.ax) * abx + (p.y - s.ay) * aby) / l2 else 0f
        if (t < 0f) t = 0f
        if (t > 1f) t = 1f
        val cx = s.ax + abx * t
        val cy = s.ay + aby * t
        val dx = p.x - cx
        val dy = p.y - cy
        val rad = p.r + s.th
        val d2 = dx * dx + dy * dy
        if (d2 >= rad * rad) return
        val d = sqrt(d2)
        val nx = if (d > 1e-4f) dx / d else 0f
        val ny = if (d > 1e-4f) dy / d else -1f
        val vx = p.x - p.px
        val vy = p.y - p.py
        p.x = cx + nx * rad
        p.y = cy + ny * rad
        respond(i, p, vx, vy, nx, ny, s.bounce, dt)
    }

    private fun respond(i: Int, p: Pt, vx: Float, vy: Float, nx: Float, ny: Float, e: Float, dt: Float) {
        val vn = vx * nx + vy * ny
        if (vn >= 0f) {
            p.px = p.x - vx
            p.py = p.y - vy
            return
        }
        var nvx = vx - (1f + e) * vn * nx
        var nvy = vy - (1f + e) * vn * ny
        val tx = -ny
        val ty = nx
        val vt = nvx * tx + nvy * ty
        nvx -= vt * tx * friction
        nvy -= vt * ty * friction
        p.px = p.x - nvx
        p.py = p.y - nvy
        val speed = -vn / dt
        if (speed > 250f && p.lastHit <= 0f) {
            p.lastHit = 0.2f
            onImpact?.invoke(Impact(p.x, p.y, speed, i))
        }
    }
}

private fun dist(a: Pt, b: Pt) = hypot(a.x - b.x, a.y - b.y)

/** شخصية كرتونية رخوة: 14 نقطة موصولة بعصيّ. k = مقياس الحجم. */
class Ragdoll(world: World?, cx: Float, cy: Float, val k: Float) {
    val head = Pt(cx, cy - 66f * k, 13f * k)
    val neck = Pt(cx, cy - 48f * k, 5f * k)
    val shL = Pt(cx - 14f * k, cy - 48f * k, 6f * k)
    val shR = Pt(cx + 14f * k, cy - 48f * k, 6f * k)
    val hipL = Pt(cx - 9f * k, cy, 7f * k)
    val hipR = Pt(cx + 9f * k, cy, 7f * k)
    val elL = Pt(cx - 26f * k, cy - 26f * k, 5f * k)
    val elR = Pt(cx + 26f * k, cy - 26f * k, 5f * k)
    val haL = Pt(cx - 30f * k, cy - 4f * k, 5f * k)
    val haR = Pt(cx + 30f * k, cy - 4f * k, 5f * k)
    val knL = Pt(cx - 10f * k, cy + 28f * k, 6f * k)
    val knR = Pt(cx + 10f * k, cy + 28f * k, 6f * k)
    val ftL = Pt(cx - 10f * k, cy + 58f * k, 6f * k)
    val ftR = Pt(cx + 10f * k, cy + 58f * k, 6f * k)

    val pts = listOf(head, neck, shL, shR, hipL, hipR, elL, elR, haL, haR, knL, knR, ftL, ftR)
    val sticks: List<Stick>

    init {
        val pairs = listOf(
            head to neck, neck to shL, neck to shR, shL to shR,
            hipL to hipR, shL to hipL, shR to hipR, shL to hipR, shR to hipL,
            shL to elL, elL to haL, shR to elR, elR to haR,
            hipL to knL, knL to ftL, hipR to knR, knR to ftR
        )
        sticks = pairs.map { Stick(it.first, it.second, dist(it.first, it.second)) }
        if (world != null) {
            world.points.addAll(pts)
            world.sticks.addAll(sticks)
        }
    }
}
