package com.why.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** مؤثرات صوتية تُولَّد برمجيًا (بلا ملفات صوت وبلا أذونات). */
class Sounds {
    companion object {
        const val THUD = 0
        const val HIT = 1
        const val CRACK = 2
        const val BOING = 3
        const val CANNON = 4
        const val SNAP = 5
        const val OUCH = 6
        const val WIN = 7
        const val FAIL = 8
        const val CLICK = 9
        const val WHOOSH = 10
        const val COUNT = 11
        private const val RATE = 22050
    }

    var enabled = true
    private val tracks = arrayOfNulls<AudioTrack>(COUNT)
    private val rnd = Random(5)

    init {
        for (i in 0 until COUNT) {
            try {
                tracks[i] = make(synth(i))
            } catch (e: Exception) {
                tracks[i] = null
            }
        }
    }

    fun play(id: Int) {
        if (!enabled || id < 0 || id >= COUNT) return
        try {
            val t = tracks[id] ?: return
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
        }
    }

    fun release() {
        for (t in tracks) try { t?.release() } catch (e: Exception) { }
    }

    private fun make(data: ShortArray): AudioTrack {
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(data, 0, data.size)
        return track
    }

    // ---------- توليف ----------
    private fun sine(f0: Float, f1: Float, dur: Float, vol: Float, decay: Float): FloatArray {
        val n = (dur * RATE).toInt()
        val out = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val f = f0 + (f1 - f0) * (t / dur)
            phase += 2.0 * PI * f / RATE
            out[i] = (sin(phase) * vol * exp(-decay * t)).toFloat()
        }
        return out
    }

    private fun noise(dur: Float, vol: Float, decay: Float, smooth: Float): FloatArray {
        val n = (dur * RATE).toInt()
        val out = FloatArray(n)
        var y = 0f
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val x = rnd.nextFloat() * 2f - 1f
            y += (x - y) * smooth
            out[i] = y * vol * exp(-decay * t)
        }
        return out
    }

    private fun brass(f0: Float, f1: Float, dur: Float): FloatArray {
        val n = (dur * RATE).toInt()
        val out = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val f = f0 + (f1 - f0) * (t / dur)
            phase += 2.0 * PI * f / RATE
            val env = if (t < 0.03f) t / 0.03f else exp(-2.5f * (t - 0.03f))
            val s = sin(phase) + 0.5 * sin(2 * phase) + 0.3 * sin(3 * phase)
            out[i] = (s * 0.4 * env).toFloat()
        }
        return out
    }

    private fun boing(): FloatArray {
        val dur = 0.4f
        val n = (dur * RATE).toInt()
        val out = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val f = 250f + 450f * sin(PI.toFloat() * t / dur) + 40f * sin(60f * t)
            phase += 2.0 * PI * f / RATE
            out[i] = (sin(phase) * 0.8 * exp(-3f * t)).toFloat()
        }
        return out
    }

    private fun add(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(maxOf(a.size, b.size))
        for (i in a.indices) out[i] += a[i]
        for (i in b.indices) out[i] += b[i]
        return out
    }

    private fun concat(vararg parts: FloatArray): FloatArray {
        var total = 0
        for (p in parts) total += p.size
        val out = FloatArray(total)
        var pos = 0
        for (p in parts) {
            System.arraycopy(p, 0, out, pos, p.size)
            pos += p.size
        }
        return out
    }

    private fun toShort(a: FloatArray): ShortArray =
        ShortArray(a.size) { (a[it].coerceIn(-1f, 1f) * 32767f * 0.8f).toInt().toShort() }

    private fun synth(id: Int): ShortArray {
        val d = when (id) {
            THUD -> add(sine(140f, 60f, 0.14f, 0.9f, 22f), noise(0.08f, 0.5f, 45f, 0.2f))
            HIT -> add(sine(220f, 70f, 0.18f, 1.0f, 16f), noise(0.12f, 0.7f, 30f, 0.4f))
            CRACK -> add(noise(0.10f, 0.8f, 35f, 0.9f), sine(1100f, 350f, 0.12f, 0.6f, 25f))
            BOING -> boing()
            CANNON -> add(noise(0.3f, 0.9f, 9f, 0.05f), sine(180f, 35f, 0.35f, 1.0f, 7f))
            SNAP -> add(noise(0.05f, 0.7f, 60f, 0.9f), sine(1500f, 700f, 0.06f, 0.5f, 40f))
            OUCH -> concat(sine(600f, 1200f, 0.1f, 0.7f, 5f), sine(1200f, 500f, 0.18f, 0.7f, 8f))
            WIN -> concat(
                sine(523f, 523f, 0.13f, 0.7f, 6f), sine(659f, 659f, 0.13f, 0.7f, 6f),
                sine(784f, 784f, 0.13f, 0.7f, 6f), sine(1047f, 1047f, 0.3f, 0.7f, 5f)
            )
            FAIL -> concat(
                brass(233f, 233f, 0.3f), brass(220f, 220f, 0.3f),
                brass(208f, 208f, 0.3f), brass(185f, 130f, 0.7f)
            )
            CLICK -> sine(900f, 900f, 0.04f, 0.5f, 60f)
            else -> noise(0.22f, 0.5f, 8f, 0.12f)
        }
        return toShort(d)
    }
}
