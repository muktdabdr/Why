package com.why.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import java.util.Random
import kotlin.math.exp
import kotlin.math.sin

/** مؤثرات صوتية مولَّدة بالكود (بلا ملفات صوت). صرفة بلا Android لتسهيل الاختبار. */
object Synth {
    const val RATE = 22050
    private const val TAU = 6.2831855f
    private const val PI_F = 3.1415927f
    private val rnd = Random(7)

    private fun noise() = rnd.nextFloat() * 2f - 1f

    private fun toShort(v: Float, amp: Float = 0.8f): Short =
        (v.coerceIn(-1f, 1f) * amp * 32767f).toInt().toShort()

    private fun gen(sec: Float, f: (Float) -> Float): ShortArray {
        val n = (sec * RATE).toInt()
        return ShortArray(n) { i -> toShort(f(i / RATE.toFloat())) }
    }

    private fun thud() = gen(0.2f) { t -> sin(TAU * (90f * t - 200f * t * t)) * exp(-18f * t) + 0.4f * noise() * exp(-60f * t) }
    private fun bonk() = gen(0.16f) { t -> (sin(TAU * 220f * t) + 0.5f * sin(TAU * 340f * t)) * exp(-22f * t) * 0.7f }
    private fun boing() = gen(0.5f) { t -> sin(TAU * (300f * t + 4f * (1f - kotlin.math.cos(TAU * 9f * t)))) * exp(-5f * t) }
    private fun squeak() = gen(0.22f) { t -> sin(TAU * (900f * t + 2500f * t * t)) * sin(PI_F * t / 0.22f) * 0.8f }
    private fun ow() = gen(0.45f) { t ->
        val ph = TAU * (650f * t - 600f * t * t) + 3f * sin(TAU * 28f * t)
        (sin(ph) + 0.4f * sin(2f * ph)) * sin(PI_F * t / 0.45f) * 0.7f
    }
    private fun snap() = gen(0.07f) { t -> noise() * exp(-70f * t) }
    private fun crack() = gen(0.12f) { t -> (noise() * 0.7f + sin(TAU * 1500f * t) * 0.3f) * exp(-45f * t) }
    private fun pop() = gen(0.12f) { t -> sin(TAU * (520f * t - 1800f * t * t)) * exp(-35f * t) }
    private fun click() = gen(0.04f) { t -> sin(TAU * 900f * t) * exp(-90f * t) }

    private fun boom(): ShortArray {
        val n = (0.7f * RATE).toInt()
        var y = 0f
        return ShortArray(n) { i ->
            val t = i / RATE.toFloat()
            y += (noise() - y) * 0.06f
            toShort((y * 6f + sin(TAU * 55f * t) * 0.8f) * exp(-5f * t), 0.9f)
        }
    }

    private fun whoosh(): ShortArray {
        val n = (0.35f * RATE).toInt()
        var y = 0f
        return ShortArray(n) { i ->
            val t = i / RATE.toFloat()
            y += (noise() - y) * 0.12f
            toShort(y * 5f * sin(PI_F * t / 0.35f), 0.7f)
        }
    }

    private fun note(freq: Float, sec: Float, drop: Float = 0f) = gen(sec) { t ->
        val ph = TAU * (freq * t - drop * t * t)
        (sin(ph) + 0.3f * sin(2f * ph)) * minOf(1f, t * 80f) * exp(-2.5f * t) * 0.8f
    }

    private fun concat(vararg a: ShortArray): ShortArray {
        val out = ShortArray(a.sumOf { it.size })
        var p = 0
        for (x in a) { x.copyInto(out, p); p += x.size }
        return out
    }

    fun all(): Map<String, ShortArray> = mapOf(
        "thud" to thud(), "bonk" to bonk(), "boing" to boing(), "squeak" to squeak(), "ow" to ow(),
        "snap" to snap(), "crack" to crack(), "pop" to pop(), "click" to click(),
        "boom" to boom(), "whoosh" to whoosh(),
        "tada" to concat(note(523f, 0.11f), note(659f, 0.11f), note(784f, 0.11f), note(1047f, 0.4f)),
        "sad" to concat(note(392f, 0.22f), note(370f, 0.22f), note(349f, 0.22f), note(330f, 0.6f, 40f))
    )
}

object Sfx {
    @Volatile var ready = false
    @Volatile var enabled = true
    private val tracks = HashMap<String, List<AudioTrack>>()
    private val idx = HashMap<String, Int>()
    private val lastMs = HashMap<String, Long>()
    private val doubled = setOf("thud", "bonk", "pop", "crack", "click")

    private fun make(data: ShortArray): AudioTrack? = try {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(Synth.RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        t
    } catch (e: Exception) {
        null
    }

    fun init() {
        if (ready) return
        try {
            for ((name, data) in Synth.all()) {
                val n = if (name in doubled) 2 else 1
                val list = ArrayList<AudioTrack>()
                repeat(n) { make(data)?.let { list.add(it) } }
                tracks[name] = list
            }
            ready = true
        } catch (e: Exception) {
        }
    }

    fun play(name: String, vol: Float) {
        if (!ready || !enabled) return
        val now = SystemClock.uptimeMillis()
        if (now - (lastMs[name] ?: 0L) < 70L) return
        lastMs[name] = now
        val list = tracks[name] ?: return
        if (list.isEmpty()) return
        val i = (idx[name] ?: 0) % list.size
        idx[name] = i + 1
        val t = list[i]
        try {
            t.stop()
            t.reloadStaticData()
            t.setVolume(vol.coerceIn(0.05f, 1f))
            t.play()
        } catch (e: Exception) {
        }
    }

    fun release() {
        ready = false
        for (l in tracks.values) for (t in l) try { t.release() } catch (e: Exception) { }
        tracks.clear()
    }
}
