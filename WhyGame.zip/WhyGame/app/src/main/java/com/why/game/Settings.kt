package com.why.game

import android.content.SharedPreferences

/** إعدادات اللعبة (تُحفظ على الجهاز). */
class Settings {
    var volume = 8        // 0..10
    var sound = true
    var vibrate = true
    var btnScale = 1      // 0 صغير، 1 متوسط، 2 كبير
    var toolsLeft = false
    var starIcon = 0
    var heartIcon = 1
    var bg = 0            // 0..7 (7 = صورة من الهاتف)
    var email = ""

    val scale: Float get() = floatArrayOf(0.85f, 1f, 1.2f)[btnScale.coerceIn(0, 2)]

    fun load(p: SharedPreferences) {
        volume = p.getInt("s_volume", 8).coerceIn(0, 10)
        sound = p.getBoolean("sound", true)
        vibrate = p.getBoolean("s_vibrate", true)
        btnScale = p.getInt("s_btn", 1).coerceIn(0, 2)
        toolsLeft = p.getBoolean("s_left", false)
        starIcon = p.getInt("s_star", 0).coerceIn(0, ICONS.size - 1)
        heartIcon = p.getInt("s_heart", 1).coerceIn(0, ICONS.size - 1)
        bg = p.getInt("s_bg", 0).coerceIn(0, BG.size - 1)
        email = p.getString("s_email", "") ?: ""
    }

    fun save(p: SharedPreferences) {
        p.edit().putInt("s_volume", volume).putBoolean("sound", sound).putBoolean("s_vibrate", vibrate)
            .putInt("s_btn", btnScale).putBoolean("s_left", toolsLeft).putInt("s_star", starIcon)
            .putInt("s_heart", heartIcon).putInt("s_bg", bg).putString("s_email", email).apply()
    }

    companion object {
        val BTN = listOf("صغير", "متوسط", "كبير")
        val ICONS = listOf("نجمة", "قلب", "ماسة", "عملة", "زهرة", "وجه")
        val BG = listOf("حسب المستوى", "ليلي", "غروب", "غابة", "حلوى", "فضاء", "سماء", "صورتي")
    }
}

/** رمز التقدم: نص ست عشري قابل للنسخ والإرسال بالبريد (بلا Base64 لضمان العمل على كل الإصدارات). */
object ProgressCodec {
    private const val PREFIX = "WHY1-"
    private const val HEX = "0123456789abcdef"

    fun encode(text: String): String {
        val sb = StringBuilder(PREFIX)
        for (b in text.toByteArray(Charsets.UTF_8)) {
            val v = b.toInt() and 255
            sb.append(HEX[v shr 4]).append(HEX[v and 15])
        }
        return sb.toString()
    }

    fun decode(raw: String): String? {
        val start = raw.indexOf(PREFIX)
        if (start < 0) return null
        val hex = StringBuilder()
        for (ch in raw.substring(start + PREFIX.length)) {
            if (ch.isWhitespace()) continue
            if (Character.digit(ch, 16) < 0) break
            hex.append(ch)
        }
        if (hex.isEmpty() || hex.length % 2 != 0) return null
        val out = ByteArray(hex.length / 2)
        for (i in out.indices) {
            out[i] = ((Character.digit(hex[2 * i], 16) shl 4) or Character.digit(hex[2 * i + 1], 16)).toByte()
        }
        return String(out, Charsets.UTF_8)
    }
}
