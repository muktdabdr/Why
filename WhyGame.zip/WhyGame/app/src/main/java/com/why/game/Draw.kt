package com.why.game

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** كل الرسم الكرتوني (شخصية، عالم، شعار). */
object Draw {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private const val OUTLINE = 0xFF222222.toInt()

    private fun line(c: Canvas, a: Pt, b: Pt, w: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        c.drawLine(a.x, a.y, b.x, b.y, p)
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(x, y, r, p)
    }

    fun character(c: Canvas, rd: Ragdoll, look: Look, dazed: Float) {
        val k = rd.k
        val shirt = Look.COLORS[look.shirt]
        val pants = Look.COLORS[look.pants]
        val skin = Look.SKIN[look.skin]

        line(c, rd.hipL, rd.knL, 12f * k, pants)
        line(c, rd.knL, rd.ftL, 11f * k, pants)
        line(c, rd.hipR, rd.knR, 12f * k, pants)
        line(c, rd.knR, rd.ftR, 11f * k, pants)
        dot(c, rd.ftL.x, rd.ftL.y, 7f * k, 0xFF2B2B2B.toInt())
        dot(c, rd.ftR.x, rd.ftR.y, 7f * k, 0xFF2B2B2B.toInt())

        path.reset()
        path.moveTo(rd.shL.x, rd.shL.y)
        path.lineTo(rd.shR.x, rd.shR.y)
        path.lineTo(rd.hipR.x, rd.hipR.y)
        path.lineTo(rd.hipL.x, rd.hipL.y)
        path.close()
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 10f * k
        p.color = shirt
        c.drawPath(path, p)

        line(c, rd.shL, rd.elL, 10f * k, shirt)
        line(c, rd.elL, rd.haL, 9f * k, skin)
        line(c, rd.shR, rd.elR, 10f * k, shirt)
        line(c, rd.elR, rd.haR, 9f * k, skin)
        dot(c, rd.haL.x, rd.haL.y, 5.5f * k, skin)
        dot(c, rd.haR.x, rd.haR.y, 5.5f * k, skin)

        val dx = rd.head.x - rd.neck.x
        val dy = rd.head.y - rd.neck.y
        val len = hypot(dx, dy)
        val ux = if (len > 0.01f) dx / len else 0f
        val uy = if (len > 0.01f) dy / len else -1f
        val deg = Math.toDegrees(atan2(ux.toDouble(), (-uy).toDouble())).toFloat()
        c.save()
        c.translate(rd.head.x, rd.head.y)
        c.rotate(deg)
        face(c, 14.5f * k, look = look, dazed = dazed, skin = skin, shirt = shirt)
        c.restore()
    }

    private fun face(c: Canvas, hr: Float, look: Look, dazed: Float, skin: Int, shirt: Int) {
        p.style = Paint.Style.FILL
        p.color = skin
        c.drawCircle(0f, 0f, hr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = hr * 0.12f
        p.color = OUTLINE
        c.drawCircle(0f, 0f, hr, p)

        val ex = hr * 0.42f
        val ey = -hr * 0.05f
        p.strokeCap = Paint.Cap.ROUND
        if (dazed > 0f) {
            p.strokeWidth = hr * 0.14f
            for (s in intArrayOf(-1, 1)) {
                val x = s * ex
                c.drawLine(x - hr * 0.2f, ey - hr * 0.2f, x + hr * 0.2f, ey + hr * 0.2f, p)
                c.drawLine(x + hr * 0.2f, ey - hr * 0.2f, x - hr * 0.2f, ey + hr * 0.2f, p)
            }
            p.style = Paint.Style.FILL
            c.drawOval(-hr * 0.22f, hr * 0.35f, hr * 0.22f, hr * 0.78f, p)
            p.color = 0xFF4FC3F7.toInt()
            c.drawCircle(-ex, ey + hr * 0.55f, hr * 0.11f, p)
            c.drawCircle(ex, ey + hr * 0.55f, hr * 0.11f, p)
        } else {
            when (look.face) {
                0, 1 -> {
                    val r = if (look.face == 0) hr * 0.26f else hr * 0.36f
                    for (s in intArrayOf(-1, 1)) {
                        p.style = Paint.Style.FILL
                        p.color = Color.WHITE
                        c.drawCircle(s * ex, ey, r, p)
                        p.color = OUTLINE
                        c.drawCircle(s * ex, ey, r * 0.5f, p)
                    }
                }
                else -> {
                    p.strokeWidth = hr * 0.14f
                    for (s in intArrayOf(-1, 1)) c.drawLine(s * ex - hr * 0.22f, ey, s * ex + hr * 0.22f, ey, p)
                }
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = hr * 0.12f
            p.color = OUTLINE
            rect.set(-hr * 0.4f, hr * 0.05f, hr * 0.4f, hr * 0.6f)
            c.drawArc(rect, 20f, 140f, false, p)
        }

        if (look.glasses) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = hr * 0.1f
            p.color = OUTLINE
            c.drawCircle(-ex, ey, hr * 0.36f, p)
            c.drawCircle(ex, ey, hr * 0.36f, p)
            c.drawLine(-ex + hr * 0.36f, ey, ex - hr * 0.36f, ey, p)
        }

        when (look.hat) {
            1 -> {
                p.style = Paint.Style.FILL
                p.color = 0xFF1C1C1C.toInt()
                c.drawRect(-hr * 0.7f, -hr * 1.9f, hr * 0.7f, -hr * 0.95f, p)
                c.drawRect(-hr * 1.05f, -hr * 1.05f, hr * 1.05f, -hr * 0.85f, p)
            }
            2 -> {
                p.style = Paint.Style.FILL
                p.color = shirt
                rect.set(-hr * 1.05f, -hr * 1.5f, hr * 1.05f, hr * 0.1f)
                c.drawArc(rect, 180f, 180f, true, p)
            }
            3 -> {
                c.save()
                c.rotate(-18f)
                p.style = Paint.Style.FILL
                p.color = Color.WHITE
                c.drawRect(-hr * 1.05f, -hr * 0.8f, hr * 1.05f, -hr * 0.45f, p)
                p.color = 0xFFE53935.toInt()
                c.drawRect(-hr * 0.07f, -hr * 0.8f, hr * 0.07f, -hr * 0.45f, p)
                c.restore()
            }
        }
    }

    fun world(c: Canvas, lv: Level, top: Float, bottom: Float) {
        val w = lv.world
        val body = Color.HSVToColor(floatArrayOf(lv.hue, 0.30f, 0.45f))
        val edge = Color.HSVToColor(floatArrayOf(lv.hue, 0.20f, 0.75f))
        p.style = Paint.Style.FILL
        for (b in w.boxes) {
            if (b.y + b.h < top || b.y > bottom) continue
            p.color = if (b.pad) 0xFFFF9800.toInt() else body
            c.drawRect(b.x, b.y, b.x + b.w, b.y + b.h, p)
            p.color = if (b.pad) 0xFFFFE082.toInt() else edge
            c.drawRect(b.x, b.y, b.x + b.w, b.y + 6f, p)
        }
        for (s in w.segs) {
            if (maxOf(s.ay, s.by) < top || minOf(s.ay, s.by) > bottom) continue
            if (s.ax == s.bx && s.ay == s.by) {
                p.style = Paint.Style.FILL
                p.color = edge
                c.drawCircle(s.ax, s.ay, s.th, p)
            } else {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = s.th * 2f
                p.color = edge
                c.drawLine(s.ax, s.ay, s.bx, s.by, p)
            }
        }
        for (sp in w.spinners) {
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = sp.seg.th * 2f
            p.color = 0xFFFFC107.toInt()
            c.drawLine(sp.seg.ax, sp.seg.ay, sp.seg.bx, sp.seg.by, p)
            p.style = Paint.Style.FILL
            c.drawCircle(sp.cx, sp.cy, 12f, p)
        }
        val r = w.rope
        if (r != null) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f
            p.color = 0xFFC9A66B.toInt()
            c.drawLine(r.ax, r.ay, r.pt.x, r.pt.y, p)
            p.style = Paint.Style.FILL
            c.drawCircle(r.ax, r.ay, 8f, p)
        }
    }

    /** شعار: وجه كرتوني متعذَّب (عيون X وحلزون، دموع، ضمادة، نجوم تدور). */
    fun logo(c: Canvas, cx: Float, cy: Float, r: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xFFFFD54F.toInt()
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.06f
        p.color = OUTLINE
        c.drawCircle(cx, cy, r, p)

        p.style = Paint.Style.FILL
        p.color = 0xFFFFE082.toInt()
        c.drawCircle(cx + r * 0.55f, cy - r * 0.62f, r * 0.17f, p)

        c.save()
        c.rotate(-18f, cx, cy)
        p.color = Color.WHITE
        c.drawRect(cx - r * 0.9f, cy - r * 0.78f, cx + r * 0.9f, cy - r * 0.5f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.03f
        p.color = OUTLINE
        c.drawRect(cx - r * 0.9f, cy - r * 0.78f, cx + r * 0.9f, cy - r * 0.5f, p)
        c.restore()

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.07f
        p.color = OUTLINE
        val lx = cx - r * 0.38f
        val rx = cx + r * 0.38f
        val ey = cy - r * 0.12f
        val a = r * 0.17f
        c.drawLine(lx - a, ey - a, lx + a, ey + a, p)
        c.drawLine(lx + a, ey - a, lx - a, ey + a, p)
        path.reset()
        for (i in 0..40) {
            val ang = i * 0.4f + t * 3f
            val rr = r * 0.02f + i * r * 0.0045f
            val x = rx + cos(ang) * rr
            val y = ey + sin(ang) * rr
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, p)

        path.reset()
        val my = cy + r * 0.55f
        path.moveTo(cx - r * 0.45f, my)
        for (i in 1..6) path.lineTo(cx - r * 0.45f + i * r * 0.15f, my + (if (i % 2 == 0) 0f else -r * 0.13f))
        c.drawPath(path, p)

        p.style = Paint.Style.FILL
        p.color = 0xFF4FC3F7.toInt()
        val fall = (t * 0.8f) % 1f
        c.drawCircle(lx - r * 0.12f, ey + r * 0.3f + fall * r * 0.35f, r * 0.06f, p)
        c.drawCircle(rx + r * 0.12f, ey + r * 0.3f + ((fall + 0.5f) % 1f) * r * 0.35f, r * 0.06f, p)

        p.color = 0xFFFFEB3B.toInt()
        for (i in 0 until 4) {
            val ang = t * 2f + i * 1.5708f
            c.drawCircle(cx + cos(ang) * r * 1.18f, cy - r * 0.95f + sin(ang) * r * 0.2f, r * 0.07f, p)
        }
    }
}
