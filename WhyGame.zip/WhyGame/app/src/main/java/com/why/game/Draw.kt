package com.why.game

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** كل الرسم الكرتوني (شخصية، عالم، مؤثرات، شعار). */
object Draw {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private const val OUTLINE = 0xFF222222.toInt()

    private fun line(c: Canvas, a: Pt, b: Pt, w: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        c.drawLine(a.x, a.y, b.x, b.y, p)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        c.drawLine(x1, y1, x2, y2, p)
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(x, y, r, p)
    }

    private fun poly(c: Canvas, color: Int, vararg v: Float) {
        path.reset()
        path.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { path.lineTo(v[i], v[i + 1]); i += 2 }
        path.close()
        p.style = Paint.Style.FILL
        p.color = color
        c.drawPath(path, p)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun star(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        path.reset()
        for (i in 0 until 10) {
            val rr = if (i % 2 == 0) r else r * 0.45f
            val a = -1.5708f + i * 0.62831855f
            val x = cx + cos(a) * rr
            val y = cy + sin(a) * rr
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        p.style = Paint.Style.FILL
        p.color = color
        c.drawPath(path, p)
    }

    fun character(c: Canvas, rd: Ragdoll, look: Look, dazed: Float) {
        val k = rd.k
        val outfit = look.outfit
        val shirt = Look.COLORS[look.shirt]
        val pants = Look.COLORS[look.pants]
        val skin = Look.SKIN[look.skin]
        val torso = if (outfit == 2) 0xFF37474F.toInt() else shirt
        val fullSleeve = outfit == 2 || outfit == 3 || outfit == 7

        if (outfit == 6) {
            poly(c, 0xFFD32F2F.toInt(), rd.shL.x, rd.shL.y, rd.shR.x, rd.shR.y, rd.knR.x, rd.knR.y, rd.knL.x, rd.knL.y)
        }
        if (outfit == 3) dot(c, rd.neck.x, rd.neck.y, 9f * k, torso)

        line(c, rd.hipL, rd.knL, 12f * k, pants)
        line(c, rd.knL, rd.ftL, 11f * k, pants)
        line(c, rd.hipR, rd.knR, 12f * k, pants)
        line(c, rd.knR, rd.ftR, 11f * k, pants)
        dot(c, rd.ftL.x, rd.ftL.y, 7f * k, 0xFF2B2B2B.toInt())
        dot(c, rd.ftR.x, rd.ftR.y, 7f * k, 0xFF2B2B2B.toInt())

        if (outfit == 4) {
            poly(c, torso, rd.hipL.x - 6f * k, rd.hipL.y, rd.hipR.x + 6f * k, rd.hipR.y,
                rd.knR.x + 9f * k, rd.knR.y, rd.knL.x - 9f * k, rd.knL.y)
        }

        path.reset()
        path.moveTo(rd.shL.x, rd.shL.y)
        path.lineTo(rd.shR.x, rd.shR.y)
        path.lineTo(rd.hipR.x, rd.hipR.y)
        path.lineTo(rd.hipL.x, rd.hipL.y)
        path.close()
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 10f * k
        p.color = torso
        c.drawPath(path, p)

        val mx = (rd.shL.x + rd.shR.x) / 2f
        val my = (rd.shL.y + rd.shR.y) / 2f
        val hx = (rd.hipL.x + rd.hipR.x) / 2f
        val hy = (rd.hipL.y + rd.hipR.y) / 2f
        when (outfit) {
            1 -> for (t in floatArrayOf(0.25f, 0.5f, 0.75f)) {
                line(c, lerp(rd.shL.x, rd.hipL.x, t), lerp(rd.shL.y, rd.hipL.y, t),
                    lerp(rd.shR.x, rd.hipR.x, t), lerp(rd.shR.y, rd.hipR.y, t), 3.5f * k, 0xCCFFFFFF.toInt())
            }
            2 -> {
                line(c, mx, my, lerp(mx, hx, 0.75f), lerp(my, hy, 0.75f), 5f * k, 0xFFD32F2F.toInt())
                line(c, rd.shL.x, rd.shL.y, mx, lerp(my, hy, 0.25f), 3f * k, Color.WHITE)
                line(c, rd.shR.x, rd.shR.y, mx, lerp(my, hy, 0.25f), 3f * k, Color.WHITE)
            }
            5 -> {
                val bl = floatArrayOf(lerp(rd.shL.x, rd.hipL.x, 0.45f), lerp(rd.shL.y, rd.hipL.y, 0.45f))
                val br = floatArrayOf(lerp(rd.shR.x, rd.hipR.x, 0.45f), lerp(rd.shR.y, rd.hipR.y, 0.45f))
                poly(c, pants, bl[0], bl[1], br[0], br[1], rd.hipR.x, rd.hipR.y, rd.hipL.x, rd.hipL.y)
                line(c, rd.shL.x, rd.shL.y, bl[0], bl[1], 3f * k, pants)
                line(c, rd.shR.x, rd.shR.y, br[0], br[1], 3f * k, pants)
            }
            6 -> dot(c, lerp(mx, hx, 0.4f), lerp(my, hy, 0.4f), 5f * k, 0xFFFFD54F.toInt())
            7 -> for (t in floatArrayOf(0.25f, 0.6f, 0.4f)) {
                star(c, lerp(mx, hx, t) + (t - 0.4f) * 14f * k, lerp(my, hy, t), 3.2f * k, 0xFFFFEB3B.toInt())
            }
        }

        val arm = if (fullSleeve) torso else skin
        line(c, rd.shL, rd.elL, 10f * k, torso)
        line(c, rd.elL, rd.haL, 9f * k, arm)
        line(c, rd.shR, rd.elR, 10f * k, torso)
        line(c, rd.elR, rd.haR, 9f * k, arm)
        dot(c, rd.haL.x, rd.haL.y, 5.5f * k, skin)
        dot(c, rd.haR.x, rd.haR.y, 5.5f * k, skin)

        val dx = rd.head.x - rd.neck.x
        val dy = rd.head.y - rd.neck.y
        val len = hypot(dx, dy)
        val ux = if (len > 0.01f) dx / len else 0f
        val uy = if (len > 0.01f) dy / len else -1f
        val deg = Math.toDegrees(atan2(ux.toDouble(), (-uy).toDouble())).toFloat()
        c.save()
        c.translate(rd.head.x, rd.head.y)
        c.rotate(deg)
        face(c, 14.5f * k, look, dazed, skin, shirt)
        c.restore()
    }

    private fun face(c: Canvas, hr: Float, look: Look, dazed: Float, skin: Int, shirt: Int) {
        val hairCol = Look.HAIRC[look.hairColor]

        // شعر خلفي
        if (look.hair == 4) dot(c, 0f, -hr * 0.3f, hr * 1.4f, hairCol)
        if (look.hair == 3) {
            p.style = Paint.Style.FILL
            p.color = hairCol
            rect.set(-hr * 1.1f, -hr * 1.0f, hr * 1.1f, hr * 1.6f)
            c.drawRoundRect(rect, hr * 0.5f, hr * 0.5f, p)
        }

        if (look.hair == 5) {
            dot(c, -hr * 1.05f, hr * 0.5f, hr * 0.42f, hairCol)
            dot(c, hr * 1.05f, hr * 0.5f, hr * 0.42f, hairCol)
        }
        if (look.hair == 6) {
            p.style = Paint.Style.FILL
            p.color = hairCol
            rect.set(hr * 0.5f, -hr * 1.1f, hr * 1.7f, hr * 0.5f)
            c.drawOval(rect, p)
        }
        if (look.hair == 7) dot(c, 0f, -hr * 1.3f, hr * 0.5f, hairCol)

        p.style = Paint.Style.FILL
        p.color = skin
        c.drawCircle(0f, 0f, hr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = hr * 0.12f
        p.color = OUTLINE
        c.drawCircle(0f, 0f, hr, p)

        // شعر أمامي
        when (look.hair) {
            1, 3, 4, 5, 6, 7 -> {
                p.style = Paint.Style.FILL
                p.color = hairCol
                rect.set(-hr * 1.02f, -hr * 1.05f, hr * 1.02f, hr * 0.5f)
                c.drawArc(rect, 195f, 150f, true, p)
            }
            2 -> {
                poly(c, hairCol, -hr, -hr * 0.3f, -hr * 0.75f, -hr * 1.6f, -hr * 0.4f, -hr * 0.8f,
                    -hr * 0.1f, -hr * 1.8f, hr * 0.2f, -hr * 0.8f, hr * 0.55f, -hr * 1.7f, hr * 0.7f, -hr * 0.7f,
                    hr, -hr * 1.4f, hr, -hr * 0.2f)
            }
        }

        val ex = hr * 0.42f
        val ey = -hr * 0.05f
        p.strokeCap = Paint.Cap.ROUND
        p.style = Paint.Style.STROKE
        p.color = OUTLINE
        if (dazed > 0f) {
            p.strokeWidth = hr * 0.14f
            for (s in intArrayOf(-1, 1)) {
                val x = s * ex
                c.drawLine(x - hr * 0.2f, ey - hr * 0.2f, x + hr * 0.2f, ey + hr * 0.2f, p)
                c.drawLine(x + hr * 0.2f, ey - hr * 0.2f, x - hr * 0.2f, ey + hr * 0.2f, p)
            }
            dot(c, -ex, ey + hr * 0.55f, hr * 0.11f, 0xFF4FC3F7.toInt())
            dot(c, ex, ey + hr * 0.55f, hr * 0.11f, 0xFF4FC3F7.toInt())
        } else {
            when (look.face) {
                0, 1 -> {
                    val r = if (look.face == 0) hr * 0.26f else hr * 0.36f
                    for (s in intArrayOf(-1, 1)) {
                        dot(c, s * ex, ey, r, Color.WHITE)
                        dot(c, s * ex, ey, r * 0.5f, OUTLINE)
                    }
                }
                else -> {
                    p.strokeWidth = hr * 0.14f
                    for (s in intArrayOf(-1, 1)) c.drawLine(s * ex - hr * 0.22f, ey, s * ex + hr * 0.22f, ey, p)
                }
            }
        }

        if (look.girl) {
            p.style = Paint.Style.FILL
            p.color = 0x66FF4081
            c.drawCircle(-hr * 0.68f, hr * 0.3f, hr * 0.17f, p)
            c.drawCircle(hr * 0.68f, hr * 0.3f, hr * 0.17f, p)
            if (dazed <= 0f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = hr * 0.08f
                p.color = OUTLINE
                for (sgn in intArrayOf(-1, 1)) {
                    val x = sgn * ex
                    c.drawLine(x - hr * 0.2f, ey - hr * 0.3f, x - hr * 0.33f, ey - hr * 0.45f, p)
                    c.drawLine(x, ey - hr * 0.33f, x, ey - hr * 0.5f, p)
                    c.drawLine(x + hr * 0.2f, ey - hr * 0.3f, x + hr * 0.33f, ey - hr * 0.45f, p)
                }
            }
        }

        // نظارات
        when (look.glasses) {
            1 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = hr * 0.1f; p.color = OUTLINE
                c.drawCircle(-ex, ey, hr * 0.36f, p); c.drawCircle(ex, ey, hr * 0.36f, p)
                c.drawLine(-ex + hr * 0.36f, ey, ex - hr * 0.36f, ey, p)
            }
            2 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = hr * 0.1f; p.color = OUTLINE
                val s = hr * 0.34f
                c.drawRect(-ex - s, ey - s, -ex + s, ey + s, p)
                c.drawRect(ex - s, ey - s, ex + s, ey + s, p)
                c.drawLine(-ex + s, ey, ex - s, ey, p)
            }
            3 -> {
                p.style = Paint.Style.FILL; p.color = 0xFF111111.toInt()
                rect.set(-ex - hr * 0.4f, ey - hr * 0.28f, -ex + hr * 0.4f, ey + hr * 0.36f)
                c.drawRoundRect(rect, hr * 0.2f, hr * 0.2f, p)
                rect.set(ex - hr * 0.4f, ey - hr * 0.28f, ex + hr * 0.4f, ey + hr * 0.36f)
                c.drawRoundRect(rect, hr * 0.2f, hr * 0.2f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = hr * 0.1f
                c.drawLine(-ex + hr * 0.4f, ey - hr * 0.1f, ex - hr * 0.4f, ey - hr * 0.1f, p)
            }
            4 -> for (s in intArrayOf(-1, 1)) {
                val x = s * ex
                dot(c, x - hr * 0.14f, ey - hr * 0.05f, hr * 0.17f, 0xFFE91E63.toInt())
                dot(c, x + hr * 0.14f, ey - hr * 0.05f, hr * 0.17f, 0xFFE91E63.toInt())
                poly(c, 0xFFE91E63.toInt(), x - hr * 0.3f, ey, x + hr * 0.3f, ey, x, ey + hr * 0.36f)
            }
            5 -> { star(c, -ex, ey, hr * 0.42f, 0xFFFFEB3B.toInt()); star(c, ex, ey, hr * 0.42f, 0xFFFFEB3B.toInt()) }
            6 -> {
                p.style = Paint.Style.FILL; p.color = 0x884FC3F7.toInt()
                rect.set(-hr * 0.9f, ey - hr * 0.3f, hr * 0.9f, ey + hr * 0.3f)
                c.drawRoundRect(rect, hr * 0.3f, hr * 0.3f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = hr * 0.12f; p.color = OUTLINE
                c.drawRoundRect(rect, hr * 0.3f, hr * 0.3f, p)
                c.drawLine(-hr * 0.9f, ey, -hr * 1.05f, ey, p)
                c.drawLine(hr * 0.9f, ey, hr * 1.05f, ey, p)
            }
            7 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = hr * 0.1f; p.color = 0xFFC9A227.toInt()
                c.drawCircle(ex, ey, hr * 0.38f, p)
                c.drawLine(ex, ey + hr * 0.38f, ex + hr * 0.2f, hr * 1.3f, p)
            }
        }

        // لحية وفم
        when (look.beard) {
            1 -> {
                p.style = Paint.Style.FILL; p.color = hairCol
                c.drawOval(-hr * 0.55f, hr * 0.2f, 0f, hr * 0.42f, p)
                c.drawOval(0f, hr * 0.2f, hr * 0.55f, hr * 0.42f, p)
            }
            2 -> {
                p.style = Paint.Style.FILL; p.color = hairCol
                rect.set(-hr * 0.98f, -hr * 0.25f, hr * 0.98f, hr * 1.05f)
                c.drawArc(rect, 25f, 130f, true, p)
            }
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = hr * 0.12f
        p.color = if (look.beard == 2) Color.WHITE else if (look.girl) 0xFFD81B60.toInt() else OUTLINE
        if (dazed > 0f) {
            p.style = Paint.Style.FILL
            c.drawOval(-hr * 0.22f, hr * 0.4f, hr * 0.22f, hr * 0.8f, p)
        } else {
            rect.set(-hr * 0.4f, hr * 0.1f, hr * 0.4f, hr * 0.62f)
            c.drawArc(rect, 20f, 140f, false, p)
        }

        // قبعات
        when (look.hat) {
            1 -> {
                p.style = Paint.Style.FILL; p.color = 0xFF1C1C1C.toInt()
                c.drawRect(-hr * 0.7f, -hr * 1.9f, hr * 0.7f, -hr * 0.95f, p)
                c.drawRect(-hr * 1.05f, -hr * 1.05f, hr * 1.05f, -hr * 0.85f, p)
            }
            2 -> {
                p.style = Paint.Style.FILL; p.color = shirt
                rect.set(-hr * 1.05f, -hr * 1.5f, hr * 1.05f, hr * 0.1f)
                c.drawArc(rect, 180f, 180f, true, p)
                dot(c, 0f, -hr * 1.5f, hr * 0.22f, Color.WHITE)
            }
            3 -> {
                c.save(); c.rotate(-18f)
                p.style = Paint.Style.FILL; p.color = Color.WHITE
                c.drawRect(-hr * 1.05f, -hr * 0.8f, hr * 1.05f, -hr * 0.45f, p)
                p.color = 0xFFE53935.toInt()
                c.drawRect(-hr * 0.07f, -hr * 0.8f, hr * 0.07f, -hr * 0.45f, p)
                c.restore()
            }
            4 -> {
                poly(c, 0xFFFFC107.toInt(), -hr * 0.9f, -hr * 0.9f, -hr * 0.9f, -hr * 1.7f, -hr * 0.45f, -hr * 1.25f,
                    0f, -hr * 1.85f, hr * 0.45f, -hr * 1.25f, hr * 0.9f, -hr * 1.7f, hr * 0.9f, -hr * 0.9f)
                dot(c, 0f, -hr * 1.1f, hr * 0.12f, 0xFFE53935.toInt())
            }
            5 -> {
                p.style = Paint.Style.FILL; p.color = 0xFF8D5A2B.toInt()
                rect.set(-hr * 1.5f, -hr * 1.15f, hr * 1.5f, -hr * 0.8f)
                c.drawOval(rect, p)
                rect.set(-hr * 0.8f, -hr * 1.8f, hr * 0.8f, -hr * 0.9f)
                c.drawRoundRect(rect, hr * 0.3f, hr * 0.3f, p)
            }
            6 -> {
                poly(c, 0xFFE91E63.toInt(), -hr * 0.5f, -hr * 0.85f, hr * 0.5f, -hr * 0.85f, 0f, -hr * 2.4f)
                dot(c, 0f, -hr * 2.4f, hr * 0.15f, 0xFFFFEB3B.toInt())
                dot(c, -hr * 0.12f, -hr * 1.3f, hr * 0.08f, Color.WHITE)
                dot(c, hr * 0.14f, -hr * 1.7f, hr * 0.08f, Color.WHITE)
            }
            7 -> {
                p.style = Paint.Style.FILL; p.color = 0xFF1E88E5.toInt()
                rect.set(-hr * 1.1f, -hr * 1.3f, hr * 1.1f, hr * 0.5f)
                c.drawArc(rect, 180f, 180f, true, p)
                p.color = Color.WHITE
                c.drawRect(-hr * 0.12f, -hr * 1.3f, hr * 0.12f, -hr * 0.4f, p)
            }
            9 -> {
                poly(c, 0xFFFF4081.toInt(), -hr * 0.55f, -hr * 1.1f, -hr * 1.25f, -hr * 1.5f, -hr * 1.25f, -hr * 0.7f)
                poly(c, 0xFFFF4081.toInt(), -hr * 0.55f, -hr * 1.1f, hr * 0.15f, -hr * 1.5f, hr * 0.15f, -hr * 0.7f)
                dot(c, -hr * 0.55f, -hr * 1.1f, hr * 0.2f, 0xFFC2185B.toInt())
            }
            10 -> {
                for (i in 0 until 5) {
                    val a = i * 1.2566371f
                    dot(c, hr * 0.6f + cos(a) * hr * 0.3f, -hr * 1.05f + sin(a) * hr * 0.3f, hr * 0.22f, 0xFFFF80AB.toInt())
                }
                dot(c, hr * 0.6f, -hr * 1.05f, hr * 0.17f, 0xFFFFEB3B.toInt())
            }
            8 -> {
                p.style = Paint.Style.FILL; p.color = Color.WHITE
                c.drawCircle(-hr * 0.5f, -hr * 1.5f, hr * 0.55f, p)
                c.drawCircle(hr * 0.5f, -hr * 1.5f, hr * 0.55f, p)
                c.drawCircle(0f, -hr * 1.85f, hr * 0.6f, p)
                c.drawRect(-hr * 0.85f, -hr * 1.4f, hr * 0.85f, -hr * 0.85f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = hr * 0.08f; p.color = OUTLINE
                c.drawLine(-hr * 0.85f, -hr * 0.85f, hr * 0.85f, -hr * 0.85f, p)
            }
        }
    }

    fun world(c: Canvas, lv: Level, top: Float, bottom: Float) {
        val w = lv.world
        val body = Color.HSVToColor(floatArrayOf(lv.hue, 0.30f, 0.45f))
        val edge = Color.HSVToColor(floatArrayOf(lv.hue, 0.20f, 0.75f))
        p.style = Paint.Style.FILL
        for (b in w.boxes) {
            if (b.y + b.h < top || b.y > bottom) continue
            p.style = Paint.Style.FILL
            p.color = if (b.pad) 0xFFFF9800.toInt() else body
            c.drawRect(b.x, b.y, b.x + b.w, b.y + b.h, p)
            p.color = if (b.pad) 0xFFFFE082.toInt() else edge
            c.drawRect(b.x, b.y, b.x + b.w, b.y + 6f, p)
        }
        for (sh in w.shapes) shape(c, sh, top, bottom)
        for (s in w.segs) {
            if (maxOf(s.ay, s.by) < top || minOf(s.ay, s.by) > bottom) continue
            if (s.ax == s.bx && s.ay == s.by) {
                dot(c, s.ax, s.ay, s.th, edge)
            } else {
                line(c, s.ax, s.ay, s.bx, s.by, s.th * 2f, edge)
            }
        }
        for (sp in w.spinners) {
            line(c, sp.seg.ax, sp.seg.ay, sp.seg.bx, sp.seg.by, sp.seg.th * 2f, 0xFFFFC107.toInt())
            dot(c, sp.cx, sp.cy, 12f, 0xFFFFC107.toInt())
        }
        val r = w.rope
        if (r != null) {
            line(c, r.ax, r.ay, r.pt.x, r.pt.y, 4f, 0xFFC9A66B.toInt())
            dot(c, r.ax, r.ay, 8f, 0xFFC9A66B.toInt())
        }
    }

    private val SHAPE_COLORS = intArrayOf(
        0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(),
        0xFFFDD835.toInt(), 0xFF8E24AA.toInt(), 0xFFFB8C00.toInt()
    )

    private fun shape(c: Canvas, sh: Shape, top: Float, bottom: Float) {
        val col = SHAPE_COLORS[sh.color % SHAPE_COLORS.size]
        p.style = Paint.Style.FILL
        p.color = (col and 0x00FFFFFF) or 0xAA000000.toInt()
        if (sh.circle) {
            if (sh.pts[1] + sh.pts[2] < top || sh.pts[1] - sh.pts[2] > bottom) return
            c.drawCircle(sh.pts[0], sh.pts[1], sh.pts[2], p)
            return
        }
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        var i = 1
        while (i < sh.pts.size) { minY = minOf(minY, sh.pts[i]); maxY = maxOf(maxY, sh.pts[i]); i += 2 }
        if (maxY < top || minY > bottom) return
        path.reset()
        path.moveTo(sh.pts[0], sh.pts[1])
        i = 2
        while (i < sh.pts.size) { path.lineTo(sh.pts[i], sh.pts[i + 1]); i += 2 }
        path.close()
        c.drawPath(path, p)
    }

    fun items(c: Canvas, list: List<Item>, t: Float, top: Float, bottom: Float) {
        for (it in list) {
            if (it.taken || it.y < top - 40f || it.y > bottom + 40f) continue
            val pulse = 1f + 0.12f * sin(t * 4f + it.x)
            if (it.kind == 0) star(c, it.x, it.y, 24f * pulse, 0xFFFFEB3B.toInt())
            else {
                val h = Shapes.heart(it.x, it.y, 22f * pulse)
                path.reset()
                path.moveTo(h[0], h[1])
                var i = 2
                while (i < h.size) { path.lineTo(h[i], h[i + 1]); i += 2 }
                path.close()
                p.style = Paint.Style.FILL
                p.color = 0xFFFF4081.toInt()
                c.drawPath(path, p)
            }
        }
    }

    fun goal(c: Canvas, x: Float, floorY: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.color = (0x4400E676 + ((sin(t * 4f) * 0x22).toInt() shl 24)).toInt()
        c.drawRect(x - 130f, floorY - 120f, x + 130f, floorY, p)
        p.color = 0xFF00E676.toInt()
        c.drawRect(x - 130f, floorY - 12f, x + 130f, floorY, p)
    }

    fun hpBar(c: Canvas, x: Float, y: Float, ratio: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = 0xAA000000.toInt()
        c.drawRect(x - 32f, y, x + 32f, y + 9f, p)
        p.color = color
        c.drawRect(x - 30f, y + 1.5f, x - 30f + 60f * ratio.coerceIn(0f, 1f), y + 7.5f, p)
    }

    fun fx(c: Canvas, list: List<Fx>) {
        for (f in list) {
            val k = 1f - f.life / f.maxLife
            val a = ((1f - k) * 255f).toInt().coerceIn(0, 255)
            when (f.kind) {
                0 -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 5f
                    p.strokeCap = Paint.Cap.ROUND
                    p.color = Color.WHITE
                    p.alpha = a
                    for (i in 0 until 8) {
                        val ang = i * 0.7853982f
                        val r1 = 10f + 40f * k
                        val r2 = 30f + 60f * k
                        c.drawLine(f.x + cos(ang) * r1, f.y + sin(ang) * r1, f.x + cos(ang) * r2, f.y + sin(ang) * r2, p)
                    }
                }
                1 -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 8f
                    p.color = 0xFFFFEB3B.toInt()
                    p.alpha = a
                    c.drawCircle(f.x, f.y, 20f + 100f * k, p)
                }
                else -> {
                    p.style = Paint.Style.FILL
                    p.color = 0xFFFF9800.toInt()
                    p.alpha = a / 2
                    c.drawCircle(f.x, f.y, 30f + 300f * k, p)
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 8f
                    p.color = Color.WHITE
                    p.alpha = a
                    c.drawCircle(f.x, f.y, 30f + 300f * k, p)
                }
            }
            p.alpha = 255
        }
    }

    /** شعار: وجه كرتوني متعذَّب (عيون X وحلزون، دموع، ضمادة، نجوم تدور). */
    fun logo(c: Canvas, cx: Float, cy: Float, r: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xFFFFD54F.toInt()
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.06f
        p.color = OUTLINE
        c.drawCircle(cx, cy, r, p)

        p.style = Paint.Style.FILL
        p.color = 0xFFFFE082.toInt()
        c.drawCircle(cx + r * 0.55f, cy - r * 0.62f, r * 0.17f, p)

        c.save()
        c.rotate(-18f, cx, cy)
        p.color = Color.WHITE
        c.drawRect(cx - r * 0.9f, cy - r * 0.78f, cx + r * 0.9f, cy - r * 0.5f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.03f
        p.color = OUTLINE
        c.drawRect(cx - r * 0.9f, cy - r * 0.78f, cx + r * 0.9f, cy - r * 0.5f, p)
        c.restore()

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.07f
        p.color = OUTLINE
        val lx = cx - r * 0.38f
        val rx = cx + r * 0.38f
        val ey = cy - r * 0.12f
        val a = r * 0.17f
        c.drawLine(lx - a, ey - a, lx + a, ey + a, p)
        c.drawLine(lx + a, ey - a, lx - a, ey + a, p)
        path.reset()
        for (i in 0..40) {
            val ang = i * 0.4f + t * 3f
            val rr = r * 0.02f + i * r * 0.0045f
            val x = rx + cos(ang) * rr
            val y = ey + sin(ang) * rr
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, p)

        path.reset()
        val my = cy + r * 0.55f
        path.moveTo(cx - r * 0.45f, my)
        for (i in 1..6) path.lineTo(cx - r * 0.45f + i * r * 0.15f, my + (if (i % 2 == 0) 0f else -r * 0.13f))
        c.drawPath(path, p)

        p.style = Paint.Style.FILL
        p.color = 0xFF4FC3F7.toInt()
        val fall = (t * 0.8f) % 1f
        c.drawCircle(lx - r * 0.12f, ey + r * 0.3f + fall * r * 0.35f, r * 0.06f, p)
        c.drawCircle(rx + r * 0.12f, ey + r * 0.3f + ((fall + 0.5f) % 1f) * r * 0.35f, r * 0.06f, p)

        p.color = 0xFFFFEB3B.toInt()
        for (i in 0 until 4) {
            val ang = t * 2f + i * 1.5708f
            c.drawCircle(cx + cos(ang) * r * 1.18f, cy - r * 0.95f + sin(ang) * r * 0.2f, r * 0.07f, p)
        }
    }
}
