package com.why.game

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Vibrator
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import java.io.File
import java.util.Random
import kotlin.math.ceil
import kotlin.math.min

class GameView(context: Context) : View(context) {

    private enum class Screen { MENU, CUSTOM, LEVELS, SETTINGS, PLAY }
    private class Btn(val r: RectF, val action: () -> Unit)
    private class Conf(var x: Float, var y: Float, var vx: Float, var vy: Float, val color: Int)

    var onPickImage: (() -> Unit)? = null

    private var screen = Screen.MENU
    private val prefs = context.getSharedPreferences("why", Context.MODE_PRIVATE)
    private val look = Look().also { it.load(prefs) }
    private val settings = Settings().also { it.load(prefs) }
    private var unlocked = prefs.getInt("unlocked", 1).coerceAtLeast(1)
    private var levelId = 1
    private var levelPage = 0
    private var settingsTab = 0
    private var play: Play? = null
    private var preview: Ragdoll? = null
    private var previewW = 0
    private var bgBitmap: Bitmap? = null
    private var camY = 0f
    private var last = System.nanoTime()
    private var t = 0f
    private var dragging = false
    private var progressSaved = false
    private var confettiDone = false
    private var msg = ""
    private var msgT = 0f
    private val confetti = ArrayList<Conf>()
    private val buttons = ArrayList<Btn>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random()
    private val tools = listOf("سحب", "لكمة", "مطرقة", "قنبلة")
    private val bgTop = intArrayOf(0, 0xFF0D1B3E.toInt(), 0xFFFF7043.toInt(), 0xFF1B5E20.toInt(), 0xFFF48FB1.toInt(), 0xFF05050F.toInt(), 0xFF4FC3F7.toInt())
    private val bgBot = intArrayOf(0, 0xFF311B92.toInt(), 0xFF4A148C.toInt(), 0xFF003300.toInt(), 0xFF7E57C2.toInt(), 0xFF1A1033.toInt(), 0xFFE1F5FE.toInt())
    private val lookKeys = setOf("shirt", "pants", "skin", "hair", "hairColor", "beard", "hat", "face", "glasses2", "outfit", "girl")
    private val setKeys = setOf("s_volume", "s_btn", "s_star", "s_heart", "s_bg", "sound", "s_vibrate", "s_left")

    init {
        val f = File(context.filesDir, "bg.jpg")
        if (f.exists()) bgBitmap = BitmapFactory.decodeFile(f.path)
        if (settings.bg == 7 && bgBitmap == null) settings.bg = 0
        applySettings()
        Thread { Sfx.init() }.start()
    }

    private fun applySettings() {
        Sfx.enabled = settings.sound
        Sfx.master = settings.volume / 10f
        settings.save(prefs)
    }

    fun handleBack(): Boolean {
        if (screen == Screen.MENU) return false
        if (screen == Screen.CUSTOM) look.save(prefs)
        if (screen == Screen.SETTINGS) applySettings()
        screen = Screen.MENU
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                for (b in buttons.asReversed()) {
                    if (b.r.contains(e.x, e.y)) {
                        Sfx.play("click", 0.5f)
                        b.action()
                        return true
                    }
                }
                if (screen == Screen.PLAY) {
                    dragging = true
                    val s = width / 1000f
                    play?.pressAt(e.x / s, e.y / s + camY)
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging && screen == Screen.PLAY) {
                val s = width / 1000f
                play?.dragTo(e.x / s, e.y / s + camY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                play?.release()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        t += dt
        if (msgT > 0f) msgT -= dt
        buttons.clear()
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.CUSTOM -> drawCustom(c)
            Screen.LEVELS -> drawLevels(c)
            Screen.SETTINGS -> drawSettings(c)
            Screen.PLAY -> drawPlay(c, dt)
        }
        if (msgT > 0f) txt(c, msg, width / 2f, height * 0.5f, width * 0.05f, Color.WHITE)
        postInvalidateOnAnimation()
    }

    // ---------- أدوات ----------
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.textAlign = align
        paint.typeface = Typeface.DEFAULT_BOLD
        c.drawText(s, x, y, paint)
    }

    private fun btn(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, label: String, color: Int, sel: Boolean = false, action: () -> Unit) {
        val r = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        paint.style = Paint.Style.FILL
        paint.color = color
        c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        if (sel) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width * 0.008f
            paint.color = Color.WHITE
            c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        }
        if (label.isNotEmpty()) {
            val size = minOf(h * 0.45f, w / (maxOf(label.length, 2) * 0.62f))
            txt(c, label, cx, cy + size * 0.35f, size, Color.WHITE)
        }
        buttons.add(Btn(r, action))
    }

    private fun soundBtn(c: Canvas, x: Float, y: Float) {
        val w = width.toFloat()
        btn(c, x, y, w * 0.2f, w * 0.1f, if (settings.sound) "صوت" else "صامت", 0xCC37474F.toInt()) {
            settings.sound = !settings.sound
            applySettings()
        }
    }

    private fun toast(s: String) {
        msg = s
        msgT = 2.2f
    }

    @Suppress("DEPRECATION")
    private fun buzz(ms: Int) {
        try { (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(ms.toLong()) } catch (e: Exception) { }
    }

    private fun begin(pl: Play) {
        pl.sfx = { n, v -> Sfx.play(n, v) }
        pl.onBuzz = { ms -> if (settings.vibrate) buzz(ms) }
        play = pl
        screen = Screen.PLAY
        progressSaved = false
        confettiDone = false
        confetti.clear()
        camY = targetCam(pl)
    }

    private fun startPlay(id: Int) {
        levelId = id
        begin(Play(LevelBuilder.build(id)))
    }

    private fun startBattle() {
        levelId = 0
        begin(Play(LevelBuilder.build(0)))
    }

    private fun targetCam(pl: Play): Float {
        val s = width / 1000f
        val viewH = height / s
        val hipY = (pl.level.rd.hipL.y + pl.level.rd.hipR.y) / 2f
        // الكاميرا تنزل 320 وحدة تحت نهاية العالم ليظهر المزيد من الأرض الخضراء عند الهبوط
        return (hipY - viewH * 0.4f).coerceIn(0f, (pl.world.h + 320f - viewH).coerceAtLeast(0f))
    }

    private fun saveWin(pl: Play) {
        if (progressSaved) return
        progressSaved = true
        if (levelId + 1 > unlocked) {
            unlocked = levelId + 1
            prefs.edit().putInt("unlocked", unlocked).apply()
        }
        if (pl.starsEarned > prefs.getInt("st_$levelId", 0)) prefs.edit().putInt("st_$levelId", pl.starsEarned).apply()
    }

    // ---------- الخلفية ----------
    private fun drawBg(c: Canvas, hue: Float, cam: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val mode = settings.bg
        val bmp = bgBitmap
        if (mode == 7 && bmp != null) {
            val sc = maxOf(w / bmp.width, h / bmp.height)
            val sw = w / sc
            val sh = h / sc
            val l = ((bmp.width - sw) / 2f).toInt()
            val tp = ((bmp.height - sh) / 2f).toInt()
            c.drawBitmap(bmp, Rect(l, tp, l + sw.toInt(), tp + sh.toInt()), RectF(0f, 0f, w, h), null)
            paint.style = Paint.Style.FILL
            paint.color = 0x66000000
            c.drawRect(0f, 0f, w, h, paint)
            return
        }
        if (mode == 0 || mode == 7) {
            c.drawColor(Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.16f)))
            return
        }
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, 0f, h, bgTop[mode], bgBot[mode], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
        if (mode == 5) {
            paint.color = Color.WHITE
            for (i in 0 until 60) {
                val x = (i * 137 % 1000) / 1000f * w
                val y = (((i * 263 % 1000) / 1000f * h) - cam * 0.05f * (1 + i % 3)).mod(h)
                c.drawCircle(x, y, w * 0.003f * (1 + i % 3), paint)
            }
        }
    }

    private fun deleteBg() {
        File(context.filesDir, "bg.jpg").delete()
        bgBitmap = null
        if (settings.bg == 7) settings.bg = 0
        applySettings()
        toast("حُذفت الصورة")
    }

    fun setBackgroundUri(uri: Uri) {
        Thread {
            try {
                val cr = context.contentResolver
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
                var sample = 1
                while (maxOf(b.outWidth, b.outHeight) / sample > 2400) sample *= 2
                val o = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: throw IllegalStateException()
                val sc = 1280f / maxOf(bmp.width, bmp.height)
                if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt().coerceAtLeast(1), (bmp.height * sc).toInt().coerceAtLeast(1), true)
                File(context.filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                val done = bmp
                post {
                    bgBitmap = done
                    settings.bg = 7
                    applySettings()
                    toast("تم تعيين الخلفية")
                }
            } catch (e: Exception) {
                post { toast("تعذّر فتح الصورة") }
            }
        }.start()
    }

    // ---------- حفظ التقدم ----------
    private fun snapshot(): String {
        look.save(prefs)
        settings.save(prefs)
        val sb = StringBuilder()
        sb.append("unlocked=").append(unlocked).append('\n')
        val st = StringBuilder()
        for (id in 1..unlocked) {
            val s = prefs.getInt("st_$id", 0)
            if (s > 0) st.append(id).append(':').append(s).append(',')
        }
        sb.append("stars=").append(st).append('\n')
        for ((k, v) in prefs.all) if (k in lookKeys || k in setKeys) sb.append(k).append('=').append(v.toString()).append('\n')
        return sb.toString()
    }

    private fun restore(text: String): Boolean {
        val ed = prefs.edit()
        var any = false
        for (line in text.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = line.substring(0, i).trim()
            val v = line.substring(i + 1).trim()
            if (k == "unlocked") {
                v.toIntOrNull()?.let { ed.putInt("unlocked", it.coerceIn(1, 100000)); any = true }
            } else if (k == "stars") {
                for (pair in v.split(',')) {
                    val a = pair.split(':')
                    if (a.size != 2) continue
                    val id = a[0].toIntOrNull() ?: continue
                    val s = a[1].toIntOrNull() ?: continue
                    if (id in 1..100000) ed.putInt("st_$id", s.coerceIn(0, 3))
                }
            } else if (k == "girl" || k == "sound" || k == "s_vibrate" || k == "s_left") {
                ed.putBoolean(k, v == "true")
            } else if (k in lookKeys || k in setKeys) {
                v.toIntOrNull()?.let { ed.putInt(k, it.coerceIn(0, 50)) }
            }
        }
        ed.apply()
        if (!any) return false
        unlocked = prefs.getInt("unlocked", 1).coerceAtLeast(1)
        look.load(prefs)
        settings.load(prefs)
        if (settings.bg == 7 && bgBitmap == null) settings.bg = 0
        applySettings()
        preview = null
        return true
    }

    private fun copyCode() {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("why", ProgressCodec.encode(snapshot())))
        toast("نُسخ رمز التقدم")
    }

    private fun restoreFromClipboard() {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val raw = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
        val text = if (raw == null) null else ProgressCodec.decode(raw)
        if (text != null && restore(text)) toast("تم استرجاع التقدم") else toast("لا يوجد رمز تقدم صالح في الحافظة")
    }

    private fun askEmail() {
        val a = context as? Activity ?: return
        val et = EditText(a)
        et.setText(settings.email)
        et.hint = "name@example.com"
        et.inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        AlertDialog.Builder(a)
            .setTitle("بريدك الإلكتروني")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                settings.email = et.text.toString().trim()
                applySettings()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun sendMail() {
        val a = context as? Activity ?: return
        val code = ProgressCodec.encode(snapshot())
        val i = Intent(Intent.ACTION_SENDTO)
        i.data = Uri.parse("mailto:")
        if (settings.email.isNotEmpty()) i.putExtra(Intent.EXTRA_EMAIL, arrayOf(settings.email))
        i.putExtra(Intent.EXTRA_SUBJECT, "تقدمي في لعبة لماذا؟")
        i.putExtra(Intent.EXTRA_TEXT, "للاسترجاع: انسخ الرمز الذي في آخر الرسالة ثم افتح اللعبة > الإعدادات > التقدم > استرجاع من الحافظة\n\n$code")
        try {
            a.startActivity(Intent.createChooser(i, "إرسال التقدم بالبريد"))
        } catch (e: Exception) {
            toast("لا يوجد تطبيق بريد")
        }
    }

    // ---------- القائمة ----------
    private fun drawMenu(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        Draw.logo(c, w / 2f, h * 0.19f, w * 0.21f, t)
        txt(c, "لماذا؟", w / 2f, h * 0.44f, w * 0.14f, 0xFFFFD54F.toInt())
        txt(c, "WHY", w / 2f, h * 0.485f, w * 0.06f, 0xFFC0C0C8.toInt())

        btn(c, w / 2f, h * 0.57f, w * 0.7f, h * 0.065f, "العب (المستوى $unlocked)", 0xFF7E57C2.toInt()) { startPlay(unlocked) }
        btn(c, w / 2f, h * 0.65f, w * 0.7f, h * 0.06f, "المستويات", 0xFF3949AB.toInt()) { levelPage = (unlocked - 1) / 30; screen = Screen.LEVELS }
        btn(c, w / 2f, h * 0.73f, w * 0.7f, h * 0.06f, "ساحة الحرب", 0xFFEF6C00.toInt()) { startBattle() }
        btn(c, w / 2f, h * 0.81f, w * 0.7f, h * 0.06f, "الشخصية", 0xFF00897B.toInt()) { screen = Screen.CUSTOM }
        btn(c, w / 2f, h * 0.89f, w * 0.7f, h * 0.06f, "الإعدادات", 0xFF546E7A.toInt()) { screen = Screen.SETTINGS }
    }

    // ---------- الإعدادات ----------
    private fun drawSettings(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (settingsTab == 1) drawBg(c, 260f, 0f) else c.drawColor(0xFF120A24.toInt())
        txt(c, "الإعدادات", w / 2f, h * 0.06f, w * 0.07f, 0xFFFFD54F.toInt())
        val names = listOf("الصوت والأزرار", "المظهر", "التقدم")
        for (i in names.indices) {
            btn(c, w * (0.17f + 0.33f * i), h * 0.115f, w * 0.31f, h * 0.05f, names[i], if (i == settingsTab) 0xFF7E57C2.toInt() else 0xFF37474F.toInt(), i == settingsTab) { settingsTab = i }
        }
        val bw = w * 0.7f
        val bh = h * 0.055f
        when (settingsTab) {
            0 -> {
                txt(c, "مستوى الصوت: ${settings.volume * 10}%", w / 2f, h * 0.205f, w * 0.045f, Color.WHITE)
                btn(c, w * 0.15f, h * 0.265f, w * 0.18f, bh, "−", 0xFF37474F.toInt()) { settings.volume = (settings.volume - 1).coerceAtLeast(0); applySettings() }
                paint.style = Paint.Style.FILL
                paint.color = 0xFF455A64.toInt()
                c.drawRoundRect(w * 0.29f, h * 0.255f, w * 0.71f, h * 0.275f, 12f, 12f, paint)
                paint.color = 0xFF7E57C2.toInt()
                c.drawRoundRect(w * 0.29f, h * 0.255f, w * (0.29f + 0.42f * settings.volume / 10f), h * 0.275f, 12f, 12f, paint)
                btn(c, w * 0.85f, h * 0.265f, w * 0.18f, bh, "+", 0xFF37474F.toInt()) { settings.volume = (settings.volume + 1).coerceAtMost(10); applySettings() }
                btn(c, w / 2f, h * 0.35f, bw, bh, if (settings.sound) "الصوت: يعمل" else "الصوت: متوقف", 0xFF37474F.toInt()) { settings.sound = !settings.sound; applySettings() }
                btn(c, w / 2f, h * 0.43f, bw, bh, if (settings.vibrate) "الاهتزاز: يعمل" else "الاهتزاز: متوقف", 0xFF37474F.toInt()) { settings.vibrate = !settings.vibrate; applySettings() }
                btn(c, w / 2f, h * 0.51f, bw, bh, "حجم الأزرار: ${Settings.BTN[settings.btnScale]}", 0xFF37474F.toInt()) { settings.btnScale = (settings.btnScale + 1) % 3; applySettings() }
                btn(c, w / 2f, h * 0.59f, bw, bh, if (settings.toolsLeft) "مكان الأدوات: يسار" else "مكان الأدوات: يمين", 0xFF37474F.toInt()) { settings.toolsLeft = !settings.toolsLeft; applySettings() }
                btn(c, w / 2f, h * 0.67f, bw, bh, "تجربة الصوت", 0xFFEF6C00.toInt()) { Sfx.play("bonk", 1f) }
            }
            1 -> {
                txt(c, "أيقونة النجوم", w / 2f, h * 0.18f, w * 0.04f, Color.WHITE)
                Draw.icon(c, settings.starIcon, w * 0.17f, h * 0.225f, w * 0.045f)
                btn(c, w * 0.58f, h * 0.225f, w * 0.55f, bh, Settings.ICONS[settings.starIcon], 0xFF37474F.toInt()) { settings.starIcon = (settings.starIcon + 1) % Settings.ICONS.size; applySettings() }
                txt(c, "أيقونة القلوب", w / 2f, h * 0.3f, w * 0.04f, Color.WHITE)
                Draw.icon(c, settings.heartIcon, w * 0.17f, h * 0.345f, w * 0.045f)
                btn(c, w * 0.58f, h * 0.345f, w * 0.55f, bh, Settings.ICONS[settings.heartIcon], 0xFF37474F.toInt()) { settings.heartIcon = (settings.heartIcon + 1) % Settings.ICONS.size; applySettings() }
                btn(c, w / 2f, h * 0.45f, bw, bh, "الخلفية: ${Settings.BG[settings.bg]}", 0xFF37474F.toInt()) {
                    var nb = (settings.bg + 1) % Settings.BG.size
                    if (nb == 7 && bgBitmap == null) nb = 0
                    settings.bg = nb
                    applySettings()
                }
                btn(c, w / 2f, h * 0.53f, bw, bh, "اختيار صورة من الهاتف", 0xFF00897B.toInt()) { onPickImage?.invoke() }
                btn(c, w / 2f, h * 0.61f, bw, bh, "حذف الصورة", 0xFFC62828.toInt()) { deleteBg() }
                txt(c, "الصورة تُحفظ داخل اللعبة وتظهر خلف المراحل", w / 2f, h * 0.69f, w * 0.034f, 0xFFC0C0C8.toInt())
            }
            else -> {
                txt(c, "البريد: " + (if (settings.email.isEmpty()) "غير محدد" else settings.email), w / 2f, h * 0.2f, w * 0.04f, Color.WHITE)
                btn(c, w / 2f, h * 0.27f, bw, bh, "تغيير البريد", 0xFF37474F.toInt()) { askEmail() }
                btn(c, w / 2f, h * 0.35f, bw, bh, "إرسال التقدم بالبريد", 0xFF7E57C2.toInt()) { sendMail() }
                btn(c, w / 2f, h * 0.43f, bw, bh, "نسخ رمز التقدم", 0xFF37474F.toInt()) { copyCode() }
                btn(c, w / 2f, h * 0.51f, bw, bh, "استرجاع من الحافظة", 0xFF00897B.toInt()) { restoreFromClipboard() }
                txt(c, "الحفظ يدوي: لا يوجد حساب سحابي.", w / 2f, h * 0.6f, w * 0.036f, 0xFFC0C0C8.toInt())
                txt(c, "أرسل الرمز لبريدك واحتفظ به.", w / 2f, h * 0.635f, w * 0.036f, 0xFFC0C0C8.toInt())
                txt(c, "للاسترجاع: انسخ الرمز من البريد ثم اضغط استرجاع.", w / 2f, h * 0.67f, w * 0.036f, 0xFFC0C0C8.toInt())
            }
        }
        btn(c, w / 2f, h * 0.94f, w * 0.5f, h * 0.06f, "رجوع", 0xFF7E57C2.toInt()) { applySettings(); screen = Screen.MENU }
    }

    // ---------- المستويات ----------
    private fun drawLevels(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        txt(c, "المستويات", w / 2f, h * 0.07f, w * 0.08f, 0xFFFFD54F.toInt())
        txt(c, "اجتز كل مستوى لتفتح الذي بعده", w / 2f, h * 0.105f, w * 0.036f, 0xFFC0C0C8.toInt())
        for (idx in 0 until 30) {
            val id = levelPage * 30 + idx + 1
            val x = w * (0.5f + ((idx % 5) - 2) * 0.18f)
            val y = h * (0.18f + (idx / 5) * 0.1f)
            val locked = id > unlocked
            val st = prefs.getInt("st_$id", 0)
            val color = when {
                locked -> 0xFF263238.toInt()
                st > 0 -> 0xFF2E7D32.toInt()
                else -> 0xFF7E57C2.toInt()
            }
            btn(c, x, y, w * 0.15f, w * 0.15f, if (locked) "🔒" else "$id", color) {
                if (!locked) startPlay(id) else toast("اجتز المستوى $unlocked أولًا")
            }
            if (!locked && st > 0) txt(c, "★".repeat(st), x, y + w * 0.105f, w * 0.032f, 0xFFFFD54F.toInt())
        }
        txt(c, "صفحة ${levelPage + 1}", w / 2f, h * 0.855f, w * 0.04f, Color.WHITE)
        val maxPage = (unlocked - 1) / 30 + 1
        btn(c, w * 0.15f, h * 0.92f, w * 0.2f, h * 0.06f, "▶", 0xFF37474F.toInt()) { if (levelPage > 0) levelPage-- }
        btn(c, w * 0.5f, h * 0.92f, w * 0.3f, h * 0.06f, "رجوع", 0xFF7E57C2.toInt()) { screen = Screen.MENU }
        btn(c, w * 0.85f, h * 0.92f, w * 0.2f, h * 0.06f, "◀", 0xFF37474F.toInt()) { if (levelPage < maxPage) levelPage++ }
    }

    // ---------- تخصيص الشخصية ----------
    private fun swatches(c: Canvas, y: Float, label: String, arr: IntArray, cur: Int, pick: (Int) -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, label, w / 2f, y - h * 0.03f, w * 0.034f, 0xFFC0C0C8.toInt())
        val n = arr.size
        for (i in 0 until n) {
            val x = w / 2f + (i - (n - 1) / 2f) * w * 0.115f
            btn(c, x, y, w * 0.09f, w * 0.09f, "", arr[i], i == cur) { pick(i) }
        }
    }

    private fun cyc(c: Canvas, x: Float, y: Float, caption: String, value: String, onTap: () -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, caption, x, y - h * 0.037f, w * 0.032f, 0xFFC0C0C8.toInt())
        btn(c, x, y, w * 0.29f, h * 0.048f, value, 0xFF37474F.toInt(), false, onTap)
    }

    private fun drawCustom(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        if (preview == null || previewW != width) {
            preview = Ragdoll(null, w / 2f, h * 0.22f, w / 320f)
            previewW = width
        }
        Draw.character(c, preview!!, look, 0f)

        swatches(c, h * 0.40f, "القميص", Look.COLORS, look.shirt) { look.shirt = it }
        swatches(c, h * 0.465f, "البنطال", Look.COLORS, look.pants) { look.pants = it }
        swatches(c, h * 0.53f, "لون البشرة", Look.SKIN, look.skin) { look.skin = it }
        swatches(c, h * 0.595f, "لون الشعر", Look.HAIRC, look.hairColor) { look.hairColor = it }

        val r1 = h * 0.675f
        val r2 = h * 0.75f
        cyc(c, w * 0.17f, r1, "القبعة", Look.HATS[look.hat]) { look.hat = (look.hat + 1) % Look.HATS.size }
        cyc(c, w * 0.50f, r1, "النظارة", Look.GLASSES[look.glasses]) { look.glasses = (look.glasses + 1) % Look.GLASSES.size }
        cyc(c, w * 0.83f, r1, "البدلة", Look.OUTFITS[look.outfit]) { look.outfit = (look.outfit + 1) % Look.OUTFITS.size }
        cyc(c, w * 0.17f, r2, "الشعر", Look.HAIR[look.hair]) { look.hair = (look.hair + 1) % Look.HAIR.size }
        cyc(c, w * 0.50f, r2, "اللحية", Look.BEARD[look.beard]) { look.beard = (look.beard + 1) % Look.BEARD.size }
        cyc(c, w * 0.83f, r2, "الوجه", Look.FACE[look.face]) { look.face = (look.face + 1) % Look.FACE.size }

        btn(c, w * 0.27f, h * 0.83f, w * 0.4f, h * 0.055f, if (look.girl) "الشكل: بنت" else "الشكل: ولد", 0xFFD81B60.toInt()) {
            look.girl = !look.girl
            if (look.girl && look.beard != 0) look.beard = 0
        }
        btn(c, w * 0.73f, h * 0.83f, w * 0.4f, h * 0.055f, "عشوائي", 0xFFEF6C00.toInt()) { look.randomize(rnd) }
        btn(c, w / 2f, h * 0.915f, w * 0.7f, h * 0.065f, "حفظ ورجوع", 0xFF7E57C2.toInt()) {
            look.save(prefs)
            screen = Screen.MENU
        }
    }

    // ---------- اللعب ----------
    private fun drawPlay(c: Canvas, dt: Float) {
        val pl = play ?: return
        val lv = pl.level
        val battle = lv.mode == 3
        val w = width.toFloat()
        val h = height.toFloat()
        val s = w / 1000f
        val sc = settings.scale
        pl.update(dt)
        camY += (targetCam(pl) - camY) * min(1f, 5f * dt)

        drawBg(c, lv.hue, camY)
        c.save()
        if (pl.shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * 36f * pl.shake, (rnd.nextFloat() - 0.5f) * 36f * pl.shake)
        c.scale(s, s)
        c.translate(0f, -camY)
        val bottom = camY + h / s
        Draw.meadow(c, pl.world.h, bottom)
        Draw.world(c, lv, camY, bottom)
        if (!battle) {
            if (lv.mission?.kind == 2) Draw.goal(c, lv.goalX, pl.world.h, t)
            Draw.items(c, lv.items, t, camY, bottom, settings.starIcon, settings.heartIcon)
        }
        for (f in lv.fighters) {
            val dz = if (battle) (if (f.ko || f.flash > 0f) 1f else 0f) else pl.dazed
            Draw.character(c, f.rd, f.look ?: look, dz)
            if (battle && !f.ko) Draw.hpBar(c, f.rd.head.x, f.rd.head.y - 38f, f.hp / 100f, if (f.team == 0) 0xFFE53935.toInt() else 0xFF1E88E5.toInt())
        }
        Draw.fx(c, pl.fx)
        for (pp in pl.popups) txt(c, pp.text, pp.x, pp.y, 38f, Color.WHITE)
        if (pl.countdown >= 0f && !pl.won) {
            txt(c, "${ceil(pl.countdown).toInt()}", lv.rd.head.x, lv.rd.head.y - 90f, 120f, 0xFFFFA726.toInt())
        }
        if (pl.world.grab != null) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            paint.color = 0xFFFFEB3B.toInt()
            c.drawCircle(pl.world.gx, pl.world.gy, 22f, paint)
        }
        c.restore()

        // ----- الواجهة العلوية -----
        txt(c, lv.title, w / 2f, h * 0.03f, w * 0.04f, 0xFFC0C0C8.toInt())
        if (battle) {
            val r = pl.teamHp(0) / 500f
            val b = pl.teamHp(1) / 500f
            paint.style = Paint.Style.FILL
            paint.color = 0xAA000000.toInt()
            c.drawRect(w * 0.03f, h * 0.045f, w * 0.97f, h * 0.07f, paint)
            paint.color = 0xFFE53935.toInt()
            c.drawRect(w * 0.5f - w * 0.46f * r.coerceIn(0f, 1f), h * 0.047f, w * 0.5f, h * 0.068f, paint)
            paint.color = 0xFF1E88E5.toInt()
            c.drawRect(w * 0.5f, h * 0.047f, w * 0.5f + w * 0.46f * b.coerceIn(0f, 1f), h * 0.068f, paint)
            txt(c, "الأحمر", w * 0.15f, h * 0.095f, w * 0.036f, 0xFFE57373.toInt())
            txt(c, "الأزرق", w * 0.85f, h * 0.095f, w * 0.036f, 0xFF64B5F6.toInt())
        } else {
            txt(c, "الألم: ${pl.pain}", w * 0.04f, h * 0.065f, w * 0.045f, 0xFFFFD54F.toInt(), Paint.Align.LEFT)
            txt(c, "الكسور: ${pl.fractures}", w * 0.96f, h * 0.065f, w * 0.045f, 0xFFFF5252.toInt(), Paint.Align.RIGHT)
            lv.mission?.let {
                txt(c, "المهمة: ${it.text}", w / 2f, h * 0.097f, w * 0.04f, 0xFFFFF59D.toInt())
                txt(c, pl.progressText(), w / 2f, h * 0.12f, w * 0.036f, 0xFFC0C0C8.toInt())
            }
        }

        val ry = h * 0.165f
        btn(c, w * 0.09f, ry, w * 0.14f * sc, w * 0.1f * sc, "☰", 0xCC37474F.toInt()) { handleBack() }
        soundBtn(c, w * 0.27f, ry)
        btn(c, w * 0.91f, ry, w * 0.16f * sc, w * 0.1f * sc, "إعادة", 0xCC37474F.toInt()) { if (battle) startBattle() else startPlay(levelId) }

        if (!pl.started && lv.mode in 0..2) {
            val label = when (lv.mode) {
                0 -> "اقطع الخيط!"
                1 -> "أطلق!"
                else -> "ادفعه!"
            }
            btn(c, w * 0.5f, h * 0.9f, w * 0.62f * sc, h * 0.07f * sc, label, 0xFFE53935.toInt()) { pl.start() }
        }
        if (!pl.world.frozen) {
            val tx = if (settings.toolsLeft) w * 0.11f else w * 0.89f
            for (i in tools.indices) {
                btn(c, tx, h * 0.3f + h * 0.095f * i * sc, w * 0.2f * sc, h * 0.075f * sc, tools[i], 0xFF37474F.toInt(), pl.tool == i) { pl.tool = i }
            }
            val hint = if (pl.tool == 0) "اسحب الشخصية بإصبعك" else "المس الشخصية لتضربها"
            txt(c, hint, w * 0.5f, h * 0.965f, w * 0.036f, 0xFFC0C0C8.toInt())
        }

        if (pl.failMsg > 0f && !pl.won) {
            paint.style = Paint.Style.FILL
            paint.color = 0xAA000000.toInt()
            c.drawRect(0f, h * 0.2f, w, h * 0.28f, paint)
            txt(c, "لم تكتمل المهمة!", w / 2f, h * 0.235f, w * 0.06f, 0xFFFF5252.toInt())
            txt(c, lv.mission?.text ?: "", w / 2f, h * 0.265f, w * 0.04f, Color.WHITE)
        }

        if (pl.won) {
            saveWin(pl)
            if (!confettiDone) {
                confettiDone = true
                val cols = intArrayOf(0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFDD835.toInt(), 0xFF8E24AA.toInt(), 0xFFFB8C00.toInt())
                repeat(70) { confetti.add(Conf(rnd.nextFloat() * w, -rnd.nextFloat() * h * 0.3f, (rnd.nextFloat() - 0.5f) * w * 0.3f, rnd.nextFloat() * h * 0.2f + h * 0.15f, cols[rnd.nextInt(cols.size)])) }
            }
            paint.style = Paint.Style.FILL
            paint.color = 0xDD000000.toInt()
            c.drawRect(0f, h * 0.27f, w, h * 0.72f, paint)
            txt(c, "نجحت!", w / 2f, h * 0.35f, w * 0.12f, 0xFF69F0AE.toInt())
            txt(c, "★".repeat(pl.starsEarned) + "☆".repeat(3 - pl.starsEarned), w / 2f, h * 0.43f, w * 0.12f, 0xFFFFD54F.toInt())
            txt(c, pl.verdict(), w / 2f, h * 0.49f, w * 0.045f, Color.WHITE)
            txt(c, "الألم: ${pl.pain}    الكسور: ${pl.fractures}", w / 2f, h * 0.54f, w * 0.04f, 0xFFC0C0C8.toInt())
            btn(c, w / 2f, h * 0.61f, w * 0.7f, h * 0.065f, "المستوى التالي", 0xFF7E57C2.toInt()) { startPlay(levelId + 1) }
            btn(c, w * 0.27f, h * 0.70f, w * 0.4f, h * 0.055f, "إعادة", 0xFF37474F.toInt()) { startPlay(levelId) }
            btn(c, w * 0.73f, h * 0.70f, w * 0.4f, h * 0.055f, "المستويات", 0xFF37474F.toInt()) { levelPage = (levelId - 1) / 30; screen = Screen.LEVELS }
        }

        if (battle && pl.winner >= 0) {
            paint.style = Paint.Style.FILL
            paint.color = 0xDD000000.toInt()
            c.drawRect(0f, h * 0.3f, w, h * 0.62f, paint)
            txt(c, if (pl.winner == 0) "فاز الفريق الأحمر!" else "فاز الفريق الأزرق!", w / 2f, h * 0.4f, w * 0.085f, if (pl.winner == 0) 0xFFE57373.toInt() else 0xFF64B5F6.toInt())
            btn(c, w / 2f, h * 0.5f, w * 0.7f, h * 0.065f, "جولة جديدة", 0xFF7E57C2.toInt()) { startBattle() }
            btn(c, w / 2f, h * 0.58f, w * 0.7f, h * 0.055f, "القائمة", 0xFF37474F.toInt()) { screen = Screen.MENU }
        }

        val ci = confetti.iterator()
        while (ci.hasNext()) {
            val p = ci.next()
            p.vy += h * 0.4f * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            if (p.y > h + 40f) { ci.remove(); continue }
            paint.style = Paint.Style.FILL
            paint.color = p.color
            c.drawRect(p.x, p.y, p.x + w * 0.02f, p.y + w * 0.012f, paint)
        }
    }
}
