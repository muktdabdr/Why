package com.why.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class GameView(context: Context) : View(context) {

    private enum class Screen { MENU, CUSTOM, PLAY }
    private class Btn(val r: RectF, val action: () -> Unit)

    private var screen = Screen.MENU
    private val prefs = context.getSharedPreferences("why", Context.MODE_PRIVATE)
    private val look = Look().also { it.load(prefs) }
    private var levelId = prefs.getInt("level", 1).coerceAtLeast(1)
    private var play: Play? = null
    private var preview: Ragdoll? = null
    private var camY = 0f
    private var last = System.nanoTime()
    private var t = 0f
    private val buttons = ArrayList<Btn>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun handleBack(): Boolean {
        if (screen == Screen.MENU) return false
        if (screen == Screen.CUSTOM) look.save(prefs)
        screen = Screen.MENU
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) {
            for (b in buttons.asReversed()) {
                if (b.r.contains(e.x, e.y)) { b.action(); return true }
            }
            if (screen == Screen.PLAY) play?.tap()
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        t += dt
        buttons.clear()
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.CUSTOM -> drawCustom(c)
            Screen.PLAY -> drawPlay(c, dt)
        }
        postInvalidateOnAnimation()
    }

    // ---------- أدوات ----------
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.textAlign = align
        paint.typeface = Typeface.DEFAULT_BOLD
        c.drawText(s, x, y, paint)
    }

    private fun btn(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, label: String, color: Int, sel: Boolean = false, action: () -> Unit) {
        val r = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        paint.style = Paint.Style.FILL
        paint.color = color
        c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        if (sel) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width * 0.008f
            paint.color = Color.WHITE
            c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        }
        if (label.isNotEmpty()) txt(c, label, cx, cy + h * 0.17f, h * 0.45f, Color.WHITE)
        buttons.add(Btn(r, action))
    }

    private fun startPlay() {
        prefs.edit().putInt("level", levelId).apply()
        val pl = Play(LevelBuilder.build(levelId))
        play = pl
        screen = Screen.PLAY
        camY = targetCam(pl)
    }

    private fun targetCam(pl: Play): Float {
        val s = width / 1000f
        val viewH = height / s
        val hipY = (pl.level.rd.hipL.y + pl.level.rd.hipR.y) / 2f
        return (hipY - viewH * 0.4f).coerceIn(0f, (LevelBuilder.H - viewH).coerceAtLeast(0f))
    }

    // ---------- القائمة ----------
    private fun drawMenu(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        Draw.logo(c, w / 2f, h * 0.22f, w * 0.22f, t)
        txt(c, "لماذا؟", w / 2f, h * 0.50f, w * 0.14f, 0xFFFFD54F.toInt())
        txt(c, "WHY", w / 2f, h * 0.555f, w * 0.06f, 0xFFC0C0C8.toInt())

        btn(c, w / 2f, h * 0.65f, w * 0.7f, h * 0.075f, "العب", 0xFF7E57C2.toInt()) { startPlay() }

        val ry = h * 0.75f
        txt(c, "المرحلة $levelId", w / 2f, ry + h * 0.012f, w * 0.06f, Color.WHITE)
        txt(c, LevelBuilder.describe(levelId), w / 2f, ry + h * 0.047f, w * 0.04f, 0xFFC0C0C8.toInt())
        val bw = w * 0.12f
        val bh = h * 0.05f
        btn(c, w * 0.10f, ry, bw, bh, "−10", 0xFF37474F.toInt()) { levelId = (levelId - 10).coerceAtLeast(1) }
        btn(c, w * 0.24f, ry, bw, bh, "−1", 0xFF37474F.toInt()) { levelId = (levelId - 1).coerceAtLeast(1) }
        btn(c, w * 0.76f, ry, bw, bh, "+1", 0xFF37474F.toInt()) { levelId += 1 }
        btn(c, w * 0.90f, ry, bw, bh, "+10", 0xFF37474F.toInt()) { levelId += 10 }

        btn(c, w / 2f, h * 0.88f, w * 0.7f, h * 0.07f, "الشخصية", 0xFF00897B.toInt()) {
            screen = Screen.CUSTOM
        }
    }

    // ---------- تخصيص الشخصية ----------
    private fun swatches(c: Canvas, y: Float, label: String, arr: IntArray, cur: Int, pick: (Int) -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, label, w / 2f, y - h * 0.035f, w * 0.04f, 0xFFC0C0C8.toInt())
        val n = arr.size
        for (i in 0 until n) {
            val x = w / 2f + (i - (n - 1) / 2f) * w * 0.115f
            btn(c, x, y, w * 0.09f, w * 0.09f, "", arr[i], i == cur) { pick(i) }
        }
    }

    private fun drawCustom(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        val rd = preview ?: Ragdoll(null, w / 2f, h * 0.27f, w / 220f).also { preview = it }
        Draw.character(c, rd, look, 0f)

        swatches(c, h * 0.53f, "القميص", Look.COLORS, look.shirt) { look.shirt = it }
        swatches(c, h * 0.62f, "البنطال", Look.COLORS, look.pants) { look.pants = it }
        swatches(c, h * 0.71f, "لون البشرة", Look.SKIN, look.skin) { look.skin = it }

        val y = h * 0.79f
        val bw = w * 0.29f
        val bh = h * 0.06f
        btn(c, w * 0.18f, y, bw, bh, "القبعة ${look.hat}", 0xFF37474F.toInt()) { look.hat = (look.hat + 1) % 4 }
        btn(c, w * 0.5f, y, bw, bh, "الوجه ${look.face + 1}", 0xFF37474F.toInt()) { look.face = (look.face + 1) % 3 }
        btn(c, w * 0.82f, y, bw, bh, if (look.glasses) "نظارة ✓" else "نظارة", 0xFF37474F.toInt()) { look.glasses = !look.glasses }

        btn(c, w / 2f, h * 0.89f, w * 0.7f, h * 0.07f, "حفظ ورجوع", 0xFF7E57C2.toInt()) {
            look.save(prefs)
            screen = Screen.MENU
        }
    }

    // ---------- اللعب ----------
    private fun drawPlay(c: Canvas, dt: Float) {
        val pl = play ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val s = w / 1000f
        pl.update(dt)
        camY += (targetCam(pl) - camY) * min(1f, 5f * dt)

        c.drawColor(Color.HSVToColor(floatArrayOf(pl.level.hue, 0.45f, 0.16f)))
        c.save()
        c.scale(s, s)
        c.translate(0f, -camY)
        Draw.world(c, pl.level, camY, camY + h / s)
        Draw.character(c, pl.level.rd, look, pl.dazed)
        for (pp in pl.popups) txt(c, pp.text, pp.x, pp.y, 38f, Color.WHITE)
        c.restore()

        txt(c, pl.level.title, w / 2f, h * 0.035f, w * 0.04f, 0xFFC0C0C8.toInt())
        txt(c, "الألم: ${pl.pain}", w * 0.04f, h * 0.075f, w * 0.05f, 0xFFFFD54F.toInt(), Paint.Align.LEFT)
        txt(c, "الكسور: ${pl.fractures}", w * 0.96f, h * 0.075f, w * 0.05f, 0xFFFF5252.toInt(), Paint.Align.RIGHT)

        btn(c, w * 0.09f, h * 0.12f, w * 0.14f, w * 0.1f, "☰", 0xCC37474F.toInt()) { handleBack() }
        btn(c, w * 0.91f, h * 0.12f, w * 0.2f, w * 0.1f, "إعادة", 0xCC37474F.toInt()) { startPlay() }

        if (!pl.started) {
            val msg = when (pl.level.mode) {
                0 -> "المس الشاشة لقطع الخيط في اللحظة المناسبة"
                1 -> "المس الشاشة لإطلاقه من المدفع"
                else -> "المس الشاشة لدفعه"
            }
            txt(c, msg, w / 2f, h * 0.94f, w * 0.045f, Color.WHITE)
        }
        if (pl.ended) {
            paint.style = Paint.Style.FILL
            paint.color = 0xCC000000.toInt()
            c.drawRect(0f, h * 0.3f, w, h * 0.72f, paint)
            txt(c, pl.verdict(), w / 2f, h * 0.40f, w * 0.06f, Color.WHITE)
            txt(c, "الألم: ${pl.pain}    الكسور: ${pl.fractures}", w / 2f, h * 0.47f, w * 0.05f, 0xFFFFD54F.toInt())
            btn(c, w * 0.28f, h * 0.60f, w * 0.38f, h * 0.07f, "إعادة", 0xFF37474F.toInt()) { startPlay() }
            btn(c, w * 0.72f, h * 0.60f, w * 0.38f, h * 0.07f, "التالية", 0xFF7E57C2.toInt()) {
                levelId++
                startPlay()
            }
        }
    }
}
