package com.why.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.min

class GameView(context: Context) : View(context) {

    private enum class Screen { MENU, CUSTOM, PLAY }
    private class Btn(val r: RectF, val action: () -> Unit)

    private var screen = Screen.MENU
    private val prefs = context.getSharedPreferences("why", Context.MODE_PRIVATE)
    private val look = Look().also { it.load(prefs) }
    private var levelId = prefs.getInt("level", 1).coerceAtLeast(1)
    private var play: Play? = null
    private var preview: Ragdoll? = null
    private var previewW = 0
    private var camY = 0f
    private var last = System.nanoTime()
    private var t = 0f
    private var dragging = false
    private var best = 0
    private var bestChecked = false
    private val buttons = ArrayList<Btn>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random()
    private val tools = listOf("سحب", "لكمة", "مطرقة", "قنبلة")

    init {
        Sfx.enabled = prefs.getBoolean("sound", true)
        Thread { Sfx.init() }.start()
    }

    fun handleBack(): Boolean {
        if (screen == Screen.MENU) return false
        if (screen == Screen.CUSTOM) look.save(prefs)
        screen = Screen.MENU
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                for (b in buttons.asReversed()) {
                    if (b.r.contains(e.x, e.y)) {
                        Sfx.play("click", 0.5f)
                        b.action()
                        return true
                    }
                }
                if (screen == Screen.PLAY) {
                    dragging = true
                    val s = width / 1000f
                    play?.pressAt(e.x / s, e.y / s + camY)
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging && screen == Screen.PLAY) {
                val s = width / 1000f
                play?.dragTo(e.x / s, e.y / s + camY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                play?.release()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        t += dt
        buttons.clear()
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.CUSTOM -> drawCustom(c)
            Screen.PLAY -> drawPlay(c, dt)
        }
        postInvalidateOnAnimation()
    }

    // ---------- أدوات ----------
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.textAlign = align
        paint.typeface = Typeface.DEFAULT_BOLD
        c.drawText(s, x, y, paint)
    }

    private fun btn(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, label: String, color: Int, sel: Boolean = false, action: () -> Unit) {
        val r = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        paint.style = Paint.Style.FILL
        paint.color = color
        c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        if (sel) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width * 0.008f
            paint.color = Color.WHITE
            c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        }
        if (label.isNotEmpty()) {
            val size = minOf(h * 0.45f, w * 0.16f)
            txt(c, label, cx, cy + size * 0.35f, size, Color.WHITE)
        }
        buttons.add(Btn(r, action))
    }

    private fun toggleSound() {
        Sfx.enabled = !Sfx.enabled
        prefs.edit().putBoolean("sound", Sfx.enabled).apply()
    }

    private fun startPlay() {
        prefs.edit().putInt("level", levelId).apply()
        val pl = Play(LevelBuilder.build(levelId))
        pl.sfx = { n, v -> Sfx.play(n, v) }
        play = pl
        screen = Screen.PLAY
        best = prefs.getInt("best_$levelId", 0)
        bestChecked = false
        camY = targetCam(pl)
    }

    private fun startSandbox() {
        val pl = Play(LevelBuilder.build(0))
        pl.sfx = { n, v -> Sfx.play(n, v) }
        play = pl
        screen = Screen.PLAY
        best = 0
        bestChecked = true
        camY = targetCam(pl)
    }

    private fun targetCam(pl: Play): Float {
        val s = width / 1000f
        val viewH = height / s
        val hipY = (pl.level.rd.hipL.y + pl.level.rd.hipR.y) / 2f
        return (hipY - viewH * 0.4f).coerceIn(0f, (LevelBuilder.H - viewH).coerceAtLeast(0f))
    }

    private fun soundBtn(c: Canvas, x: Float, y: Float) {
        val w = width.toFloat()
        btn(c, x, y, w * 0.2f, w * 0.1f, if (Sfx.enabled) "صوت" else "صامت", 0xCC37474F.toInt()) { toggleSound() }
    }

    // ---------- القائمة ----------
    private fun drawMenu(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        Draw.logo(c, w / 2f, h * 0.2f, w * 0.22f, t)
        txt(c, "لماذا؟", w / 2f, h * 0.46f, w * 0.14f, 0xFFFFD54F.toInt())
        txt(c, "WHY", w / 2f, h * 0.505f, w * 0.06f, 0xFFC0C0C8.toInt())
        soundBtn(c, w * 0.88f, h * 0.05f)

        btn(c, w / 2f, h * 0.59f, w * 0.7f, h * 0.07f, "العب", 0xFF7E57C2.toInt()) { startPlay() }

        val ry = h * 0.69f
        txt(c, "المرحلة $levelId", w / 2f, ry + h * 0.012f, w * 0.06f, Color.WHITE)
        txt(c, LevelBuilder.describe(levelId), w / 2f, ry + h * 0.045f, w * 0.04f, 0xFFC0C0C8.toInt())
        val bw = w * 0.12f
        val bh = h * 0.05f
        btn(c, w * 0.10f, ry, bw, bh, "−10", 0xFF37474F.toInt()) { levelId = (levelId - 10).coerceAtLeast(1) }
        btn(c, w * 0.24f, ry, bw, bh, "−1", 0xFF37474F.toInt()) { levelId = (levelId - 1).coerceAtLeast(1) }
        btn(c, w * 0.76f, ry, bw, bh, "+1", 0xFF37474F.toInt()) { levelId += 1 }
        btn(c, w * 0.90f, ry, bw, bh, "+10", 0xFF37474F.toInt()) { levelId += 10 }

        btn(c, w / 2f, h * 0.79f, w * 0.7f, h * 0.065f, "الساحة الحرة", 0xFFEF6C00.toInt()) { startSandbox() }
        btn(c, w / 2f, h * 0.88f, w * 0.7f, h * 0.065f, "الشخصية", 0xFF00897B.toInt()) { screen = Screen.CUSTOM }
    }

    // ---------- تخصيص الشخصية ----------
    private fun swatches(c: Canvas, y: Float, label: String, arr: IntArray, cur: Int, pick: (Int) -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, label, w / 2f, y - h * 0.032f, w * 0.036f, 0xFFC0C0C8.toInt())
        val n = arr.size
        for (i in 0 until n) {
            val x = w / 2f + (i - (n - 1) / 2f) * w * 0.115f
            btn(c, x, y, w * 0.09f, w * 0.09f, "", arr[i], i == cur) { pick(i) }
        }
    }

    private fun cyc(c: Canvas, x: Float, y: Float, caption: String, value: String, onTap: () -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, caption, x, y - h * 0.04f, w * 0.034f, 0xFFC0C0C8.toInt())
        btn(c, x, y, w * 0.29f, h * 0.05f, value, 0xFF37474F.toInt(), false, onTap)
    }

    private fun drawCustom(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        if (preview == null || previewW != width) {
            preview = Ragdoll(null, w / 2f, h * 0.24f, w / 300f)
            previewW = width
        }
        Draw.character(c, preview!!, look, 0f)

        swatches(c, h * 0.43f, "القميص", Look.COLORS, look.shirt) { look.shirt = it }
        swatches(c, h * 0.50f, "البنطال", Look.COLORS, look.pants) { look.pants = it }
        swatches(c, h * 0.57f, "لون البشرة", Look.SKIN, look.skin) { look.skin = it }
        swatches(c, h * 0.64f, "لون الشعر", Look.HAIRC, look.hairColor) { look.hairColor = it }

        val r1 = h * 0.73f
        val r2 = h * 0.81f
        cyc(c, w * 0.17f, r1, "القبعة", Look.HATS[look.hat]) { look.hat = (look.hat + 1) % Look.HATS.size }
        cyc(c, w * 0.50f, r1, "النظارة", Look.GLASSES[look.glasses]) { look.glasses = (look.glasses + 1) % Look.GLASSES.size }
        cyc(c, w * 0.83f, r1, "البدلة", Look.OUTFITS[look.outfit]) { look.outfit = (look.outfit + 1) % Look.OUTFITS.size }
        cyc(c, w * 0.17f, r2, "الشعر", Look.HAIR[look.hair]) { look.hair = (look.hair + 1) % Look.HAIR.size }
        cyc(c, w * 0.50f, r2, "اللحية", Look.BEARD[look.beard]) { look.beard = (look.beard + 1) % Look.BEARD.size }
        cyc(c, w * 0.83f, r2, "الوجه", Look.FACE[look.face]) { look.face = (look.face + 1) % Look.FACE.size }

        btn(c, w * 0.27f, h * 0.91f, w * 0.4f, h * 0.06f, "عشوائي", 0xFFEF6C00.toInt()) { look.randomize(rnd) }
        btn(c, w * 0.73f, h * 0.91f, w * 0.4f, h * 0.06f, "حفظ ورجوع", 0xFF7E57C2.toInt()) {
            look.save(prefs)
            screen = Screen.MENU
        }
    }

    // ---------- اللعب ----------
    private fun drawPlay(c: Canvas, dt: Float) {
        val pl = play ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val s = w / 1000f
        pl.update(dt)
        camY += (targetCam(pl) - camY) * min(1f, 5f * dt)

        c.drawColor(Color.HSVToColor(floatArrayOf(pl.level.hue, 0.45f, 0.16f)))
        c.save()
        c.scale(s, s)
        c.translate(0f, -camY)
        Draw.world(c, pl.level, camY, camY + h / s)
        Draw.character(c, pl.level.rd, look, pl.dazed)
        Draw.fx(c, pl.fx)
        for (pp in pl.popups) txt(c, pp.text, pp.x, pp.y, 38f, Color.WHITE)
        val g = pl.world.grab
        if (g != null) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            paint.color = 0xFFFFEB3B.toInt()
            c.drawCircle(pl.world.gx, pl.world.gy, 22f, paint)
        }
        c.restore()

        if (pl.level.mode != 3 && pl.settled && !bestChecked) {
            bestChecked = true
            if (pl.pain > best) {
                best = pl.pain
                prefs.edit().putInt("best_$levelId", best).apply()
            }
        }

        txt(c, pl.level.title, w / 2f, h * 0.035f, w * 0.04f, 0xFFC0C0C8.toInt())
        txt(c, "الألم: ${pl.pain}", w * 0.04f, h * 0.075f, w * 0.05f, 0xFFFFD54F.toInt(), Paint.Align.LEFT)
        txt(c, "الكسور: ${pl.fractures}", w * 0.96f, h * 0.075f, w * 0.05f, 0xFFFF5252.toInt(), Paint.Align.RIGHT)
        if (pl.level.mode != 3) txt(c, "الأفضل: $best", w / 2f, h * 0.075f, w * 0.04f, 0xFFC0C0C8.toInt())

        val ry = h * 0.125f
        btn(c, w * 0.09f, ry, w * 0.14f, w * 0.1f, "☰", 0xCC37474F.toInt()) { handleBack() }
        soundBtn(c, w * 0.27f, ry)
        if (pl.level.mode != 3) {
            btn(c, w * 0.73f, ry, w * 0.2f, w * 0.1f, "التالية", 0xCC37474F.toInt()) { levelId++; startPlay() }
            btn(c, w * 0.91f, ry, w * 0.16f, w * 0.1f, "إعادة", 0xCC37474F.toInt()) { startPlay() }
        } else {
            btn(c, w * 0.91f, ry, w * 0.16f, w * 0.1f, "إعادة", 0xCC37474F.toInt()) { startSandbox() }
        }

        if (!pl.started && pl.level.mode in 0..2) {
            val label = when (pl.level.mode) {
                0 -> "اقطع الخيط!"
                1 -> "أطلق!"
                else -> "ادفعه!"
            }
            val by = if (pl.world.frozen) h * 0.92f else h * 0.84f
            btn(c, w / 2f, by, w * 0.62f, h * 0.07f, label, 0xFFE53935.toInt()) { pl.start() }
        }
        if (!pl.world.frozen) {
            val hint = if (pl.tool == 0) "اسحب الشخصية بإصبعك" else "المس الشخصية لتضربها"
            txt(c, hint, w / 2f, h * 0.885f, w * 0.036f, 0xFFC0C0C8.toInt())
            for (i in tools.indices) {
                btn(c, w * (0.125f + 0.25f * i), h * 0.935f, w * 0.23f, h * 0.06f, tools[i], 0xFF37474F.toInt(), pl.tool == i) { pl.tool = i }
            }
        }

        if (pl.settled) {
            paint.style = Paint.Style.FILL
            paint.color = 0xAA000000.toInt()
            c.drawRect(0f, h * 0.17f, w, h * 0.235f, paint)
            txt(c, pl.verdict(), w / 2f, h * 0.213f, w * 0.05f, Color.WHITE)
        }
    }
}
