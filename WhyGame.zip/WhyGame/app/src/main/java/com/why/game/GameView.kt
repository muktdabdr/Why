package com.why.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.ceil
import kotlin.math.min

class GameView(context: Context) : View(context) {

    private enum class Screen { MENU, CUSTOM, LEVELS, PLAY }
    private class Btn(val r: RectF, val action: () -> Unit)

    private var screen = Screen.MENU
    private val prefs = context.getSharedPreferences("why", Context.MODE_PRIVATE)
    private val look = Look().also { it.load(prefs) }
    private var unlocked = prefs.getInt("unlocked", 1).coerceAtLeast(1)
    private var levelId = 1
    private var levelPage = 0
    private var play: Play? = null
    private var preview: Ragdoll? = null
    private var previewW = 0
    private var camY = 0f
    private var last = System.nanoTime()
    private var t = 0f
    private var dragging = false
    private var progressSaved = false
    private var msg = ""
    private var msgT = 0f
    private val buttons = ArrayList<Btn>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random()
    private val tools = listOf("سحب", "لكمة", "مطرقة", "قنبلة")

    init {
        Sfx.enabled = prefs.getBoolean("sound", true)
        Thread { Sfx.init() }.start()
    }

    fun handleBack(): Boolean {
        if (screen == Screen.MENU) return false
        if (screen == Screen.CUSTOM) look.save(prefs)
        screen = Screen.MENU
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                for (b in buttons.asReversed()) {
                    if (b.r.contains(e.x, e.y)) {
                        Sfx.play("click", 0.5f)
                        b.action()
                        return true
                    }
                }
                if (screen == Screen.PLAY) {
                    dragging = true
                    val s = width / 1000f
                    play?.pressAt(e.x / s, e.y / s + camY)
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging && screen == Screen.PLAY) {
                val s = width / 1000f
                play?.dragTo(e.x / s, e.y / s + camY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                play?.release()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        t += dt
        if (msgT > 0f) msgT -= dt
        buttons.clear()
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.CUSTOM -> drawCustom(c)
            Screen.LEVELS -> drawLevels(c)
            Screen.PLAY -> drawPlay(c, dt)
        }
        if (msgT > 0f) txt(c, msg, width / 2f, height * 0.5f, width * 0.05f, Color.WHITE)
        postInvalidateOnAnimation()
    }

    // ---------- أدوات ----------
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.textAlign = align
        paint.typeface = Typeface.DEFAULT_BOLD
        c.drawText(s, x, y, paint)
    }

    private fun btn(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, label: String, color: Int, sel: Boolean = false, action: () -> Unit) {
        val r = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        paint.style = Paint.Style.FILL
        paint.color = color
        c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        if (sel) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width * 0.008f
            paint.color = Color.WHITE
            c.drawRoundRect(r, h * 0.25f, h * 0.25f, paint)
        }
        if (label.isNotEmpty()) {
            val size = minOf(h * 0.45f, w / (maxOf(label.length, 2) * 0.62f))
            txt(c, label, cx, cy + size * 0.35f, size, Color.WHITE)
        }
        buttons.add(Btn(r, action))
    }

    private fun toggleSound() {
        Sfx.enabled = !Sfx.enabled
        prefs.edit().putBoolean("sound", Sfx.enabled).apply()
    }

    private fun soundBtn(c: Canvas, x: Float, y: Float) {
        val w = width.toFloat()
        btn(c, x, y, w * 0.2f, w * 0.1f, if (Sfx.enabled) "صوت" else "صامت", 0xCC37474F.toInt()) { toggleSound() }
    }

    private fun begin(pl: Play) {
        pl.sfx = { n, v -> Sfx.play(n, v) }
        play = pl
        screen = Screen.PLAY
        progressSaved = false
        camY = targetCam(pl)
    }

    private fun startPlay(id: Int) {
        levelId = id
        begin(Play(LevelBuilder.build(id)))
    }

    private fun startBattle() {
        levelId = 0
        begin(Play(LevelBuilder.build(0)))
    }

    private fun targetCam(pl: Play): Float {
        val s = width / 1000f
        val viewH = height / s
        val hipY = (pl.level.rd.hipL.y + pl.level.rd.hipR.y) / 2f
        return (hipY - viewH * 0.4f).coerceIn(0f, (pl.world.h - viewH).coerceAtLeast(0f))
    }

    private fun saveWin(pl: Play) {
        if (progressSaved) return
        progressSaved = true
        if (levelId + 1 > unlocked) {
            unlocked = levelId + 1
            prefs.edit().putInt("unlocked", unlocked).apply()
        }
        if (pl.starsEarned > prefs.getInt("st_$levelId", 0)) prefs.edit().putInt("st_$levelId", pl.starsEarned).apply()
    }

    // ---------- القائمة ----------
    private fun drawMenu(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        Draw.logo(c, w / 2f, h * 0.2f, w * 0.22f, t)
        txt(c, "لماذا؟", w / 2f, h * 0.46f, w * 0.14f, 0xFFFFD54F.toInt())
        txt(c, "WHY", w / 2f, h * 0.505f, w * 0.06f, 0xFFC0C0C8.toInt())
        soundBtn(c, w * 0.88f, h * 0.05f)

        btn(c, w / 2f, h * 0.6f, w * 0.7f, h * 0.07f, "العب (المستوى $unlocked)", 0xFF7E57C2.toInt()) { startPlay(unlocked) }
        btn(c, w / 2f, h * 0.69f, w * 0.7f, h * 0.065f, "المستويات", 0xFF3949AB.toInt()) { levelPage = (unlocked - 1) / 30; screen = Screen.LEVELS }
        btn(c, w / 2f, h * 0.78f, w * 0.7f, h * 0.065f, "ساحة الحرب", 0xFFEF6C00.toInt()) { startBattle() }
        btn(c, w / 2f, h * 0.87f, w * 0.7f, h * 0.065f, "الشخصية", 0xFF00897B.toInt()) { screen = Screen.CUSTOM }
    }

    // ---------- المستويات ----------
    private fun drawLevels(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        txt(c, "المستويات", w / 2f, h * 0.07f, w * 0.08f, 0xFFFFD54F.toInt())
        txt(c, "اجتز كل مستوى لتفتح الذي بعده", w / 2f, h * 0.105f, w * 0.036f, 0xFFC0C0C8.toInt())
        for (idx in 0 until 30) {
            val id = levelPage * 30 + idx + 1
            val x = w * (0.5f + ((idx % 5) - 2) * 0.18f)
            val y = h * (0.18f + (idx / 5) * 0.1f)
            val locked = id > unlocked
            val st = prefs.getInt("st_$id", 0)
            val color = when {
                locked -> 0xFF263238.toInt()
                st > 0 -> 0xFF2E7D32.toInt()
                else -> 0xFF7E57C2.toInt()
            }
            btn(c, x, y, w * 0.15f, w * 0.15f, if (locked) "🔒" else "$id", color) {
                if (!locked) startPlay(id) else { msg = "اجتز المستوى $unlocked أولًا"; msgT = 2f }
            }
            if (!locked && st > 0) txt(c, "★".repeat(st), x, y + w * 0.105f, w * 0.032f, 0xFFFFD54F.toInt())
        }
        txt(c, "صفحة ${levelPage + 1}", w / 2f, h * 0.855f, w * 0.04f, Color.WHITE)
        val maxPage = (unlocked - 1) / 30 + 1
        btn(c, w * 0.15f, h * 0.92f, w * 0.2f, h * 0.06f, "▶", 0xFF37474F.toInt()) { if (levelPage > 0) levelPage-- }
        btn(c, w * 0.5f, h * 0.92f, w * 0.3f, h * 0.06f, "رجوع", 0xFF7E57C2.toInt()) { screen = Screen.MENU }
        btn(c, w * 0.85f, h * 0.92f, w * 0.2f, h * 0.06f, "◀", 0xFF37474F.toInt()) { if (levelPage < maxPage) levelPage++ }
    }

    // ---------- تخصيص الشخصية ----------
    private fun swatches(c: Canvas, y: Float, label: String, arr: IntArray, cur: Int, pick: (Int) -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, label, w / 2f, y - h * 0.03f, w * 0.034f, 0xFFC0C0C8.toInt())
        val n = arr.size
        for (i in 0 until n) {
            val x = w / 2f + (i - (n - 1) / 2f) * w * 0.115f
            btn(c, x, y, w * 0.09f, w * 0.09f, "", arr[i], i == cur) { pick(i) }
        }
    }

    private fun cyc(c: Canvas, x: Float, y: Float, caption: String, value: String, onTap: () -> Unit) {
        val w = width.toFloat()
        val h = height.toFloat()
        txt(c, caption, x, y - h * 0.037f, w * 0.032f, 0xFFC0C0C8.toInt())
        btn(c, x, y, w * 0.29f, h * 0.048f, value, 0xFF37474F.toInt(), false, onTap)
    }

    private fun drawCustom(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF120A24.toInt())
        if (preview == null || previewW != width) {
            preview = Ragdoll(null, w / 2f, h * 0.22f, w / 320f)
            previewW = width
        }
        Draw.character(c, preview!!, look, 0f)

        swatches(c, h * 0.40f, "القميص", Look.COLORS, look.shirt) { look.shirt = it }
        swatches(c, h * 0.465f, "البنطال", Look.COLORS, look.pants) { look.pants = it }
        swatches(c, h * 0.53f, "لون البشرة", Look.SKIN, look.skin) { look.skin = it }
        swatches(c, h * 0.595f, "لون الشعر", Look.HAIRC, look.hairColor) { look.hairColor = it }

        val r1 = h * 0.675f
        val r2 = h * 0.75f
        cyc(c, w * 0.17f, r1, "القبعة", Look.HATS[look.hat]) { look.hat = (look.hat + 1) % Look.HATS.size }
        cyc(c, w * 0.50f, r1, "النظارة", Look.GLASSES[look.glasses]) { look.glasses = (look.glasses + 1) % Look.GLASSES.size }
        cyc(c, w * 0.83f, r1, "البدلة", Look.OUTFITS[look.outfit]) { look.outfit = (look.outfit + 1) % Look.OUTFITS.size }
        cyc(c, w * 0.17f, r2, "الشعر", Look.HAIR[look.hair]) { look.hair = (look.hair + 1) % Look.HAIR.size }
        cyc(c, w * 0.50f, r2, "اللحية", Look.BEARD[look.beard]) { look.beard = (look.beard + 1) % Look.BEARD.size }
        cyc(c, w * 0.83f, r2, "الوجه", Look.FACE[look.face]) { look.face = (look.face + 1) % Look.FACE.size }

        btn(c, w * 0.27f, h * 0.83f, w * 0.4f, h * 0.055f, if (look.girl) "الشكل: بنت" else "الشكل: ولد", 0xFFD81B60.toInt()) {
            look.girl = !look.girl
            if (look.girl && look.beard != 0) look.beard = 0
        }
        btn(c, w * 0.73f, h * 0.83f, w * 0.4f, h * 0.055f, "عشوائي", 0xFFEF6C00.toInt()) { look.randomize(rnd) }
        btn(c, w / 2f, h * 0.915f, w * 0.7f, h * 0.065f, "حفظ ورجوع", 0xFF7E57C2.toInt()) {
            look.save(prefs)
            screen = Screen.MENU
        }
    }

    // ---------- اللعب ----------
    private fun drawPlay(c: Canvas, dt: Float) {
        val pl = play ?: return
        val lv = pl.level
        val battle = lv.mode == 3
        val w = width.toFloat()
        val h = height.toFloat()
        val s = w / 1000f
        pl.update(dt)
        camY += (targetCam(pl) - camY) * min(1f, 5f * dt)

        c.drawColor(Color.HSVToColor(floatArrayOf(lv.hue, 0.45f, 0.16f)))
        c.save()
        c.scale(s, s)
        c.translate(0f, -camY)
        val bottom = camY + h / s
        Draw.world(c, lv, camY, bottom)
        if (!battle) {
            if (lv.mission?.kind == 2) Draw.goal(c, lv.goalX, pl.world.h, t)
            Draw.items(c, lv.items, t, camY, bottom)
        }
        for (f in lv.fighters) {
            val dz = if (battle) (if (f.ko || f.flash > 0f) 1f else 0f) else pl.dazed
            Draw.character(c, f.rd, f.look ?: look, dz)
            if (battle && !f.ko) Draw.hpBar(c, f.rd.head.x, f.rd.head.y - 38f, f.hp / 100f, if (f.team == 0) 0xFFE53935.toInt() else 0xFF1E88E5.toInt())
        }
        Draw.fx(c, pl.fx)
        for (pp in pl.popups) txt(c, pp.text, pp.x, pp.y, 38f, Color.WHITE)
        if (pl.countdown >= 0f && !pl.won) {
            txt(c, "${ceil(pl.countdown).toInt()}", lv.rd.head.x, lv.rd.head.y - 90f, 120f, 0xFFFFA726.toInt())
        }
        if (pl.world.grab != null) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            paint.color = 0xFFFFEB3B.toInt()
            c.drawCircle(pl.world.gx, pl.world.gy, 22f, paint)
        }
        c.restore()

        // ----- الواجهة العلوية -----
        txt(c, lv.title, w / 2f, h * 0.03f, w * 0.04f, 0xFFC0C0C8.toInt())
        if (battle) {
            val r = pl.teamHp(0) / 500f
            val b = pl.teamHp(1) / 500f
            paint.style = Paint.Style.FILL
            paint.color = 0xAA000000.toInt()
            c.drawRect(w * 0.03f, h * 0.045f, w * 0.97f, h * 0.07f, paint)
            paint.color = 0xFFE53935.toInt()
            c.drawRect(w * 0.5f - w * 0.46f * r.coerceIn(0f, 1f), h * 0.047f, w * 0.5f, h * 0.068f, paint)
            paint.color = 0xFF1E88E5.toInt()
            c.drawRect(w * 0.5f, h * 0.047f, w * 0.5f + w * 0.46f * b.coerceIn(0f, 1f), h * 0.068f, paint)
            txt(c, "الأحمر", w * 0.15f, h * 0.095f, w * 0.036f, 0xFFE57373.toInt())
            txt(c, "الأزرق", w * 0.85f, h * 0.095f, w * 0.036f, 0xFF64B5F6.toInt())
        } else {
            txt(c, "الألم: ${pl.pain}", w * 0.04f, h * 0.065f, w * 0.045f, 0xFFFFD54F.toInt(), Paint.Align.LEFT)
            txt(c, "الكسور: ${pl.fractures}", w * 0.96f, h * 0.065f, w * 0.045f, 0xFFFF5252.toInt(), Paint.Align.RIGHT)
            lv.mission?.let {
                txt(c, "المهمة: ${it.text}", w / 2f, h * 0.097f, w * 0.04f, 0xFFFFF59D.toInt())
                txt(c, pl.progressText(), w / 2f, h * 0.12f, w * 0.036f, 0xFFC0C0C8.toInt())
            }
        }

        val ry = h * 0.165f
        btn(c, w * 0.09f, ry, w * 0.14f, w * 0.1f, "☰", 0xCC37474F.toInt()) { handleBack() }
        soundBtn(c, w * 0.27f, ry)
        if (battle) {
            btn(c, w * 0.91f, ry, w * 0.16f, w * 0.1f, "إعادة", 0xCC37474F.toInt()) { startBattle() }
        } else {
            btn(c, w * 0.91f, ry, w * 0.16f, w * 0.1f, "إعادة", 0xCC37474F.toInt()) { startPlay(levelId) }
        }

        if (!pl.started && lv.mode in 0..2) {
            val label = when (lv.mode) {
                0 -> "اقطع الخيط!"
                1 -> "أطلق!"
                else -> "ادفعه!"
            }
            btn(c, w * 0.45f, h * 0.9f, w * 0.62f, h * 0.07f, label, 0xFFE53935.toInt()) { pl.start() }
        }
        if (!pl.world.frozen) {
            for (i in tools.indices) {
                btn(c, w * 0.89f, h * (0.3f + 0.095f * i), w * 0.2f, h * 0.075f, tools[i], 0xFF37474F.toInt(), pl.tool == i) { pl.tool = i }
            }
            val hint = if (pl.tool == 0) "اسحب الشخصية بإصبعك" else "المس الشخصية لتضربها"
            txt(c, hint, w * 0.45f, h * 0.965f, w * 0.036f, 0xFFC0C0C8.toInt())
        }

        if (pl.failMsg > 0f && !pl.won) {
            paint.style = Paint.Style.FILL
            paint.color = 0xAA000000.toInt()
            c.drawRect(0f, h * 0.2f, w, h * 0.28f, paint)
            txt(c, "لم تكتمل المهمة!", w / 2f, h * 0.235f, w * 0.06f, 0xFFFF5252.toInt())
            txt(c, lv.mission?.text ?: "", w / 2f, h * 0.265f, w * 0.04f, Color.WHITE)
        }

        if (pl.won) {
            saveWin(pl)
            paint.style = Paint.Style.FILL
            paint.color = 0xDD000000.toInt()
            c.drawRect(0f, h * 0.27f, w, h * 0.72f, paint)
            txt(c, "نجحت!", w / 2f, h * 0.35f, w * 0.12f, 0xFF69F0AE.toInt())
            txt(c, "★".repeat(pl.starsEarned) + "☆".repeat(3 - pl.starsEarned), w / 2f, h * 0.43f, w * 0.12f, 0xFFFFD54F.toInt())
            txt(c, pl.verdict(), w / 2f, h * 0.49f, w * 0.045f, Color.WHITE)
            txt(c, "الألم: ${pl.pain}    الكسور: ${pl.fractures}", w / 2f, h * 0.54f, w * 0.04f, 0xFFC0C0C8.toInt())
            btn(c, w / 2f, h * 0.61f, w * 0.7f, h * 0.065f, "المستوى التالي", 0xFF7E57C2.toInt()) { startPlay(levelId + 1) }
            btn(c, w * 0.27f, h * 0.70f, w * 0.4f, h * 0.055f, "إعادة", 0xFF37474F.toInt()) { startPlay(levelId) }
            btn(c, w * 0.73f, h * 0.70f, w * 0.4f, h * 0.055f, "المستويات", 0xFF37474F.toInt()) { levelPage = (levelId - 1) / 30; screen = Screen.LEVELS }
        }

        if (battle && pl.winner >= 0) {
            paint.style = Paint.Style.FILL
            paint.color = 0xDD000000.toInt()
            c.drawRect(0f, h * 0.3f, w, h * 0.62f, paint)
            txt(c, if (pl.winner == 0) "فاز الفريق الأحمر!" else "فاز الفريق الأزرق!", w / 2f, h * 0.4f, w * 0.085f, if (pl.winner == 0) 0xFFE57373.toInt() else 0xFF64B5F6.toInt())
            btn(c, w / 2f, h * 0.5f, w * 0.7f, h * 0.065f, "جولة جديدة", 0xFF7E57C2.toInt()) { startBattle() }
            btn(c, w / 2f, h * 0.58f, w * 0.7f, h * 0.055f, "القائمة", 0xFF37474F.toInt()) { screen = Screen.MENU }
        }
    }
}
