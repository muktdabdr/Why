package com.why.game

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Popup(val x: Float, var y: Float, val text: String, var life: Float)

class Fx(val x: Float, val y: Float, val kind: Int, val maxLife: Float) {
    var life = maxLife
}

/** حالة جولة واحدة: المهمة، العدّاد، الأدوات، والحرب. بلا رسم وبلا Android. */
class Play(val level: Level) {
    companion object {
        const val GOAL_HALF = 220f
    }

    val world = level.world
    val mission = level.mission
    var started = level.mode == 3
    var pain = 0
    var fractures = 0
    var stars = 0
    var hearts = 0
    var dazed = 0f
    var time = 0f
    var tool = 0
    var countdown = -1f
    var won = false
    var starsEarned = 0
    var failMsg = 0f
    var winner = -1
    var slowMo = 0f
    var shake = 0f
    var simMode = false
    var onBuzz: ((Int) -> Unit)? = null
    val totalStars = level.items.count { it.kind == 0 }
    private var calm = 0f
    private var acc = 0f
    val popups = ArrayList<Popup>()
    val fx = ArrayList<Fx>()
    var sfx: ((String, Float) -> Unit)? = null
    private val rnd = java.util.Random()
    private val fracAt = FloatArray(world.points.size) { -9f }
    private val hurt = listOf("آخ!", "لماذا؟!", "أوه لا!", "ااه!", "ضربة!", "ليس مرة أخرى!")

    init {
        world.onImpact = { onImpact(it) }
    }

    // ---------- المهمة ----------
    fun missionDone(): Boolean {
        val m = mission ?: return false
        return when (m.kind) {
            0 -> stars >= m.target
            1 -> hearts >= m.target
            2 -> {
                val rd = level.rd
                val hx = (rd.hipL.x + rd.hipR.x) / 2f
                val hy = (rd.hipL.y + rd.hipR.y) / 2f
                abs(hx - level.goalX) < GOAL_HALF && hy > world.h - 260f
            }
            3 -> pain >= m.target
            4 -> fractures >= m.target
            else -> fractures <= m.target
        }
    }

    fun progressText(): String {
        val m = mission ?: return ""
        return when (m.kind) {
            0 -> "النجوم: $stars / ${m.target}"
            1 -> "القلوب: $hearts / ${m.target}"
            2 -> if (missionDone()) "أنت في المنطقة الخضراء ✓" else "المنطقة الخضراء على الأرض"
            3 -> "الألم: $pain / ${m.target}"
            4 -> "الكسور: $fractures / ${m.target}"
            else -> "الكسور: $fractures (الحد ${m.target})"
        }
    }

    // ---------- البدء والأدوات ----------
    /** زر البدء: قطع الخيط، المدفع، أو الدفعة. */
    fun start() {
        if (started) return
        when (level.mode) {
            0 -> if (world.rope != null) { world.rope = null; world.frozen = false; started = true; sfx?.invoke("snap", 1f) }
            1 -> { started = true; world.launch(level.launchVx, level.launchVy); sfx?.invoke("boom", 1f) }
            else -> { started = true; world.launch(level.launchVx, level.launchVy); sfx?.invoke("whoosh", 0.9f) }
        }
    }

    fun pressAt(wx: Float, wy: Float) {
        if (world.frozen || won || winner >= 0) return
        when (tool) {
            0 -> {
                val p = world.nearest(wx, wy, 90f)
                if (p != null) {
                    world.grab = p
                    world.gx = wx
                    world.gy = wy
                    sfx?.invoke("squeak", 0.5f)
                }
            }
            1 -> hit(wx, wy, 120f, 1500f, false, 20, "بام!", "pop", 0)
            2 -> hit(wx, wy, 140f, 1900f, true, 35, "بونك!", "bonk", 1)
            else -> { shake = 1f; hit(wx, wy, 300f, 2300f, false, 60, "بوم!", "boom", 2) }
        }
    }

    fun dragTo(wx: Float, wy: Float) {
        world.gx = wx
        world.gy = wy
    }

    fun release() {
        world.grab = null
    }

    private fun hit(wx: Float, wy: Float, radius: Float, speed: Float, down: Boolean, dmg: Int, word: String, snd: String, kind: Int) {
        fx.add(Fx(wx, wy, kind, if (kind == 2) 0.5f else 0.3f))
        val f = world.impulse(wx, wy, radius, speed, down)
        if (f <= 0f) {
            sfx?.invoke("whoosh", 0.3f)
            return
        }
        sfx?.invoke(snd, 0.6f + 0.4f * f)
        calm = 0f
        popups.add(Popup(wx, wy - 40f, word, 0.9f))
        if (level.mode == 3) {
            for (fi in level.fighters) {
                var m = 0f
                for (p in fi.rd.pts) {
                    val d = hypot(p.x - wx, p.y - wy)
                    if (d < radius) m = max(m, 1f - d / radius)
                }
                if (m > 0f) hurtFighter(fi, dmg * m * 0.6f)
            }
            return
        }
        pain += (dmg * f).toInt() + 1
        dazed = 1f
        if (f > 0.6f && rnd.nextFloat() < (if (kind == 2) 1f else 0.4f)) {
            fractures = min(12, fractures + 1)
            sfx?.invoke("crack", 0.8f)
        }
    }

    // ---------- التحديث ----------
    fun update(dt: Float) {
        acc += if (slowMo > 0f && !simMode) dt * 0.4f else dt
        slowMo = max(0f, slowMo - dt)
        shake = max(0f, shake - dt * 2.5f)
        var n = 0
        while (acc >= World.DT && n < 6) {
            world.step(World.DT)
            acc -= World.DT
            n++
        }
        if (acc > World.DT * 6) acc = 0f
        dazed = max(0f, dazed - dt)
        failMsg = max(0f, failMsg - dt)

        val pi = popups.iterator()
        while (pi.hasNext()) {
            val p = pi.next()
            p.life -= dt
            p.y -= 60f * dt
            if (p.life <= 0f) pi.remove()
        }
        val fi = fx.iterator()
        while (fi.hasNext()) {
            val f = fi.next()
            f.life -= dt
            if (f.life <= 0f) fi.remove()
        }

        if (level.mode == 3) {
            battle(dt)
            return
        }
        collect()
        if (started && !won) {
            time += dt
            var fastest = 0f
            for (p in world.points) fastest = max(fastest, hypot(p.x - p.px, p.y - p.py) / World.DT)
            if (world.grab != null || fastest >= 40f) calm = 0f else calm += dt
            if (calm > 0.5f) {
                countdown = 3f - (calm - 0.5f)
                if (countdown <= 0f) {
                    countdown = -1f
                    if (missionDone()) {
                        won = true
                        starsEarned = 1 + (if (totalStars > 0 && stars * 10 >= totalStars * 6) 1 else 0) + (if (time <= 25f) 1 else 0)
                        sfx?.invoke("tada", 0.9f)
                    } else {
                        failMsg = 2.5f
                        calm = 0f
                        sfx?.invoke("sad", 0.7f)
                    }
                }
            } else countdown = -1f
        }
    }

    private fun collect() {
        for (it in level.items) {
            if (it.taken) continue
            for (p in level.rd.pts) {
                if (hypot(p.x - it.x, p.y - it.y) < 60f) {
                    it.taken = true
                    if (it.kind == 0) stars++ else hearts++
                    sfx?.invoke("coin", 0.7f)
                    popups.add(Popup(it.x, it.y - 20f, "+1", 0.8f))
                    break
                }
            }
        }
    }

    // ---------- الحرب ----------
    private fun hurtFighter(f: Fighter, amount: Float) {
        if (f.ko || winner >= 0) return
        f.hp -= amount
        f.flash = 0.5f
        if (f.hp <= 0f) {
            f.ko = true
            sfx?.invoke("ow", 0.8f)
            popups.add(Popup(f.rd.head.x, f.rd.head.y - 40f, "خرج!", 1.2f))
            val alive0 = level.fighters.any { it.team == 0 && !it.ko }
            val alive1 = level.fighters.any { it.team == 1 && !it.ko }
            if (!alive0) winner = 1 else if (!alive1) winner = 0
            if (winner >= 0) sfx?.invoke("tada", 0.9f)
        }
    }

    fun teamHp(team: Int): Float = level.fighters.filter { it.team == team }.sumOf { max(0f, it.hp).toDouble() }.toFloat()

    private fun battle(dt: Float) {
        if (winner >= 0) return
        for (f in level.fighters) {
            f.flash = max(0f, f.flash - dt)
            if (f.ko) continue
            f.jumpCd -= dt
            f.atkCd -= dt
            var target: Fighter? = null
            var bd = 1e9f
            for (o in level.fighters) {
                if (o.team == f.team || o.ko) continue
                val d = hypot(o.rd.hipL.x - f.rd.hipL.x, o.rd.hipL.y - f.rd.hipL.y)
                if (d < bd) { bd = d; target = o }
            }
            val t = target ?: continue
            val dx = t.rd.hipL.x - f.rd.hipL.x
            val dir = if (dx >= 0f) 1f else -1f
            if (f.jumpCd <= 0f) {
                f.jumpCd = 1.4f + rnd.nextFloat() * 1.2f
                val vx = dir * (250f + rnd.nextFloat() * 250f)
                val vy = -(750f + rnd.nextFloat() * 450f)
                for (p in f.rd.pts) {
                    p.px -= vx * World.DT
                    p.py -= vy * World.DT
                }
            }
            if (f.atkCd <= 0f && bd < 190f) {
                f.atkCd = 0.8f
                val hand = if (rnd.nextBoolean()) f.rd.haL else f.rd.haR
                val tx = t.rd.hipL.x
                val ty = t.rd.hipL.y
                val l = max(1f, hypot(tx - hand.x, ty - hand.y))
                hand.px -= (tx - hand.x) / l * 1100f * World.DT
                hand.py -= (ty - hand.y) / l * 1100f * World.DT
                world.impulse(hand.x, hand.y, 110f, 1000f, false, only = t.id)
                fx.add(Fx(hand.x, hand.y, 0, 0.3f))
                sfx?.invoke("pop", 0.5f)
                hurtFighter(t, 9f)
                if (rnd.nextFloat() < 0.3f) popups.add(Popup(t.rd.head.x, t.rd.head.y - 40f, hurt[rnd.nextInt(hurt.size)], 0.9f))
            }
        }
    }

    private fun onImpact(im: Impact) {
        val owner = world.points[im.index].owner
        val vol = (im.speed / 1500f).coerceIn(0.2f, 1f)
        if (im.bounce > 1f) sfx?.invoke("boing", vol)
        else if (im.speed > 600f) sfx?.invoke("bonk", vol)
        else sfx?.invoke("thud", vol)
        if (level.mode == 3) {
            if (im.speed > 450f) level.fighters.firstOrNull { it.id == owner }?.let { hurtFighter(it, (im.speed - 450f) * 0.03f) }
            return
        }
        pain += ((im.speed - 250f) * 0.05f).toInt().coerceAtLeast(0)
        if (im.speed > 1200f) slowMo = 0.5f
        if (im.speed > 500f) shake = max(shake, min(1f, im.speed / 3000f))
        if (im.speed > 900f) onBuzz?.invoke(30)
        if (im.speed > 450f) {
            dazed = 1.2f
            if (rnd.nextFloat() < 0.6f) popups.add(Popup(im.x, im.y - 30f, hurt[rnd.nextInt(hurt.size)], 1.1f))
            if (im.speed > 600f && rnd.nextFloat() < 0.35f) sfx?.invoke("ow", 0.6f)
        }
        if (im.speed > 700f && time - fracAt[im.index] > 0.6f) {
            fracAt[im.index] = time
            fractures = (fractures + 1).coerceAtMost(12)
            sfx?.invoke("crack", 0.8f)
        }
    }

    fun verdict(): String = when {
        fractures == 0 && pain < 60 -> "نجا بلا خدش... تقريبًا!"
        fractures <= 3 -> "بعض الكسور... ضمادات للجميع"
        fractures <= 7 -> "رحلة طويلة إلى المستشفى!"
        else -> "صعد إلى النجوم ☆ (كرتونيًا)"
    }
}
