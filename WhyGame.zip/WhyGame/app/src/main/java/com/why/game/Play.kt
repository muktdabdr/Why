package com.why.game

import kotlin.math.hypot
import kotlin.math.max

class Popup(val x: Float, var y: Float, val text: String, var life: Float)

/** حالة جولة واحدة: الألم، الكسور، النهاية. بلا رسم وبلا Android. */
class Play(val level: Level) {
    val world = level.world
    var started = false
    var ended = false
    var pain = 0
    var fractures = 0
    var dazed = 0f
    var time = 0f
    private var calm = 0f
    private var acc = 0f
    val popups = ArrayList<Popup>()
    private val rnd = java.util.Random()
    private val fracAt = FloatArray(level.rd.pts.size) { -9f }
    private val hurt = listOf("آخ!", "لماذا؟!", "أوه لا!", "ااه!", "ضربة!", "ليس مرة أخرى!")

    init {
        world.onImpact = { onImpact(it) }
    }

    fun tap() {
        if (ended) return
        if (level.mode == 0) {
            if (world.rope != null) { world.rope = null; started = true }
        } else if (!started) {
            started = true
            world.launch(level.launchVx, level.launchVy)
        }
    }

    fun update(dt: Float) {
        acc += dt
        var n = 0
        while (acc >= World.DT && n < 6) {
            world.step(World.DT)
            acc -= World.DT
            n++
        }
        if (acc > World.DT * 6) acc = 0f
        dazed = max(0f, dazed - dt)
        val it = popups.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= dt
            p.y -= 60f * dt
            if (p.life <= 0f) it.remove()
        }
        if (started && !ended) {
            time += dt
            var fastest = 0f
            for (p in world.points) fastest = max(fastest, hypot(p.x - p.px, p.y - p.py) / World.DT)
            if (fastest < 40f) calm += dt else calm = 0f
            if (calm > 1.5f || time > 30f) ended = true
        }
    }

    private fun onImpact(im: Impact) {
        pain += ((im.speed - 250f) * 0.05f).toInt().coerceAtLeast(0)
        if (im.speed > 450f) {
            dazed = 1.2f
            if (rnd.nextFloat() < 0.6f) popups.add(Popup(im.x, im.y - 30f, hurt[rnd.nextInt(hurt.size)], 1.1f))
        }
        if (im.speed > 700f && time - fracAt[im.index] > 0.6f) {
            fracAt[im.index] = time
            fractures = (fractures + 1).coerceAtMost(12)
        }
    }

    fun verdict(): String = when {
        fractures == 0 && pain < 60 -> "نجا بلا خدش... تقريبًا!"
        fractures <= 3 -> "بعض الكسور... ضمادات للجميع"
        fractures <= 7 -> "رحلة طويلة إلى المستشفى!"
        else -> "صعد إلى النجوم ☆ (كرتونيًا)"
    }
}
