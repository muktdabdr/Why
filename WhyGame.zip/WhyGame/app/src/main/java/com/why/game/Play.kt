package com.why.game

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Popup(val x: Float, var y: Float, val text: String, var life: Float)

class Fx(val x: Float, val y: Float, val kind: Int, val maxLife: Float) {
    var life = maxLife
}

/** حالة جولة واحدة: الألم، الكسور، الأدوات (سحب، لكمة، مطرقة، قنبلة). بلا رسم وبلا Android. */
class Play(val level: Level) {
    val world = level.world
    var started = level.mode == 3
    var settled = false
    var pain = 0
    var fractures = 0
    var dazed = 0f
    var time = 0f
    var tool = 0
    private var calm = 0f
    private var acc = 0f
    private var wasSettled = false
    val popups = ArrayList<Popup>()
    val fx = ArrayList<Fx>()
    var sfx: ((String, Float) -> Unit)? = null
    private val rnd = java.util.Random()
    private val fracAt = FloatArray(level.rd.pts.size) { -9f }
    private val hurt = listOf("آخ!", "لماذا؟!", "أوه لا!", "ااه!", "ضربة!", "ليس مرة أخرى!")

    init {
        world.onImpact = { onImpact(it) }
    }

    /** زر البدء: قطع الخيط، المدفع، أو الدفعة. */
    fun start() {
        if (started) return
        when (level.mode) {
            0 -> if (world.rope != null) { world.rope = null; started = true; sfx?.invoke("snap", 1f) }
            1 -> { started = true; world.launch(level.launchVx, level.launchVy); sfx?.invoke("boom", 1f) }
            else -> { started = true; world.launch(level.launchVx, level.launchVy); sfx?.invoke("whoosh", 0.9f) }
        }
    }

    fun pressAt(wx: Float, wy: Float) {
        if (world.frozen) return
        when (tool) {
            0 -> {
                val p = world.nearest(wx, wy, 90f)
                if (p != null) {
                    world.grab = p
                    world.gx = wx
                    world.gy = wy
                    sfx?.invoke("squeak", 0.5f)
                }
            }
            1 -> hit(wx, wy, 120f, 1500f, false, 20, "بام!", "pop", 0)
            2 -> hit(wx, wy, 140f, 1900f, true, 35, "بونك!", "bonk", 1)
            else -> hit(wx, wy, 300f, 2300f, false, 60, "بوم!", "boom", 2)
        }
    }

    fun dragTo(wx: Float, wy: Float) {
        world.gx = wx
        world.gy = wy
    }

    fun release() {
        world.grab = null
    }

    private fun hit(wx: Float, wy: Float, radius: Float, speed: Float, down: Boolean, dmg: Int, word: String, snd: String, kind: Int) {
        fx.add(Fx(wx, wy, kind, if (kind == 2) 0.5f else 0.3f))
        val f = world.impulse(wx, wy, radius, speed, down)
        if (f <= 0f) {
            sfx?.invoke("whoosh", 0.3f)
            return
        }
        sfx?.invoke(snd, 0.6f + 0.4f * f)
        pain += (dmg * f).toInt() + 1
        dazed = 1f
        calm = 0f
        popups.add(Popup(wx, wy - 40f, word, 0.9f))
        if (f > 0.6f && rnd.nextFloat() < (if (kind == 2) 1f else 0.4f)) {
            fractures = min(12, fractures + 1)
            sfx?.invoke("crack", 0.8f)
        }
    }

    fun update(dt: Float) {
        acc += dt
        var n = 0
        while (acc >= World.DT && n < 6) {
            world.step(World.DT)
            acc -= World.DT
            n++
        }
        if (acc > World.DT * 6) acc = 0f
        dazed = max(0f, dazed - dt)

        val pi = popups.iterator()
        while (pi.hasNext()) {
            val p = pi.next()
            p.life -= dt
            p.y -= 60f * dt
            if (p.life <= 0f) pi.remove()
        }
        val fi = fx.iterator()
        while (fi.hasNext()) {
            val f = fi.next()
            f.life -= dt
            if (f.life <= 0f) fi.remove()
        }

        if (started) {
            time += dt
            var fastest = 0f
            for (p in world.points) fastest = max(fastest, hypot(p.x - p.px, p.y - p.py) / World.DT)
            if (world.grab != null || fastest >= 40f) calm = 0f else calm += dt
            settled = calm > 1.2f && level.mode != 3
            if (settled && !wasSettled) sfx?.invoke(if (fractures <= 3) "tada" else "sad", 0.8f)
            wasSettled = settled
        }
    }

    private fun onImpact(im: Impact) {
        pain += ((im.speed - 250f) * 0.05f).toInt().coerceAtLeast(0)
        val vol = (im.speed / 1500f).coerceIn(0.2f, 1f)
        if (im.bounce > 1f) sfx?.invoke("boing", vol)
        else if (im.speed > 600f) sfx?.invoke("bonk", vol)
        else sfx?.invoke("thud", vol)
        if (im.speed > 450f) {
            dazed = 1.2f
            if (rnd.nextFloat() < 0.6f) popups.add(Popup(im.x, im.y - 30f, hurt[rnd.nextInt(hurt.size)], 1.1f))
            if (im.speed > 600f && rnd.nextFloat() < 0.35f) sfx?.invoke("ow", 0.6f)
        }
        if (im.speed > 700f && time - fracAt[im.index] > 0.6f) {
            fracAt[im.index] = time
            fractures = (fractures + 1).coerceAtMost(12)
            sfx?.invoke("crack", 0.8f)
        }
    }

    fun verdict(): String = when {
        fractures == 0 && pain < 60 -> "نجا بلا خدش... تقريبًا!"
        fractures <= 3 -> "بعض الكسور... ضمادات للجميع"
        fractures <= 7 -> "رحلة طويلة إلى المستشفى!"
        else -> "صعد إلى النجوم ☆ (كرتونيًا)"
    }
}
