package com.why.game

import android.content.SharedPreferences
import java.util.Random

/** شكل الشخصية (يُحفظ على الجهاز). */
class Look {
    var shirt = 0
    var pants = 1
    var skin = 0
    var hair = 1
    var hairColor = 0
    var beard = 0
    var hat = 0
    var face = 0
    var glasses = 0
    var outfit = 0

    fun load(p: SharedPreferences) {
        shirt = p.getInt("shirt", 0).coerceIn(0, COLORS.size - 1)
        pants = p.getInt("pants", 1).coerceIn(0, COLORS.size - 1)
        skin = p.getInt("skin", 0).coerceIn(0, SKIN.size - 1)
        hair = p.getInt("hair", 1).coerceIn(0, HAIR.size - 1)
        hairColor = p.getInt("hairColor", 0).coerceIn(0, HAIRC.size - 1)
        beard = p.getInt("beard", 0).coerceIn(0, BEARD.size - 1)
        hat = p.getInt("hat", 0).coerceIn(0, HATS.size - 1)
        face = p.getInt("face", 0).coerceIn(0, FACE.size - 1)
        glasses = p.getInt("glasses2", 0).coerceIn(0, GLASSES.size - 1)
        outfit = p.getInt("outfit", 0).coerceIn(0, OUTFITS.size - 1)
    }

    fun save(p: SharedPreferences) {
        p.edit().putInt("shirt", shirt).putInt("pants", pants).putInt("skin", skin)
            .putInt("hair", hair).putInt("hairColor", hairColor).putInt("beard", beard)
            .putInt("hat", hat).putInt("face", face).putInt("glasses2", glasses)
            .putInt("outfit", outfit).apply()
    }

    fun randomize(r: Random) {
        shirt = r.nextInt(COLORS.size); pants = r.nextInt(COLORS.size); skin = r.nextInt(SKIN.size)
        hair = r.nextInt(HAIR.size); hairColor = r.nextInt(HAIRC.size); beard = r.nextInt(BEARD.size)
        hat = r.nextInt(HATS.size); face = r.nextInt(FACE.size); glasses = r.nextInt(GLASSES.size)
        outfit = r.nextInt(OUTFITS.size)
    }

    companion object {
        val COLORS = intArrayOf(
            0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFDD835.toInt(),
            0xFF8E24AA.toInt(), 0xFFFB8C00.toInt(), 0xFF212121.toInt(), 0xFFF5F5F5.toInt()
        )
        val SKIN = intArrayOf(
            0xFFFFCC99.toInt(), 0xFFE0AC69.toInt(), 0xFFC68642.toInt(),
            0xFF8D5524.toInt(), 0xFF9ED08C.toInt(), 0xFF9AD0F5.toInt()
        )
        val HAIRC = intArrayOf(
            0xFF3B2314.toInt(), 0xFF111111.toInt(), 0xFFE6C068.toInt(), 0xFFB5451B.toInt(),
            0xFFBDBDBD.toInt(), 0xFFE91E63.toInt(), 0xFF42A5F5.toInt()
        )
        val HATS = listOf("بدون", "عالية", "صوفية", "ضمادة", "تاج", "كاوبوي", "حفلة", "خوذة", "طاهٍ")
        val GLASSES = listOf("بدون", "دائرية", "مربعة", "شمسية", "قلوب", "نجوم", "غوص", "عدسة")
        val OUTFITS = listOf("قميص", "مخطط", "بدلة", "هودي", "فستان", "أفرول", "بطل خارق", "بيجامة")
        val HAIR = listOf("أصلع", "قصير", "شائك", "طويل", "مجعّد")
        val BEARD = listOf("بدون", "شارب", "لحية")
        val FACE = listOf("عيون ١", "عيون ٢", "نعسان")
    }
}
