package com.why.game

import android.content.SharedPreferences

/** شكل الشخصية (يُحفظ على الجهاز). */
class Look {
    var shirt = 0
    var pants = 1
    var skin = 0
    var hat = 0
    var face = 0
    var glasses = false

    fun load(p: SharedPreferences) {
        shirt = p.getInt("shirt", 0).coerceIn(0, COLORS.size - 1)
        pants = p.getInt("pants", 1).coerceIn(0, COLORS.size - 1)
        skin = p.getInt("skin", 0).coerceIn(0, SKIN.size - 1)
        hat = p.getInt("hat", 0).coerceIn(0, 3)
        face = p.getInt("face", 0).coerceIn(0, 2)
        glasses = p.getBoolean("glasses", false)
    }

    fun save(p: SharedPreferences) {
        p.edit().putInt("shirt", shirt).putInt("pants", pants).putInt("skin", skin)
            .putInt("hat", hat).putInt("face", face).putBoolean("glasses", glasses).apply()
    }

    companion object {
        val COLORS = intArrayOf(
            0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFDD835.toInt(),
            0xFF8E24AA.toInt(), 0xFFFB8C00.toInt(), 0xFF212121.toInt(), 0xFFF5F5F5.toInt()
        )
        val SKIN = intArrayOf(
            0xFFFFCC99.toInt(), 0xFFE0AC69.toInt(), 0xFFC68642.toInt(),
            0xFF8D5524.toInt(), 0xFF9ED08C.toInt(), 0xFF9AD0F5.toInt()
        )
    }
}
