package com.why.game

import java.util.Random
import kotlin.math.hypot
import kotlin.math.sin

/** mode: 0 = معلّق بخيط، 1 = مدفع، 2 = دفعة، 3 = الساحة الحرة. */
class Level(
    val id: Int,
    val title: String,
    val world: World,
    val rd: Ragdoll,
    val mode: Int,
    val launchVx: Float,
    val launchVy: Float,
    val hue: Float,
)

/**
 * كل "نوع" مرحلة = دالة تبني الأرضية (حوالي 10 أسطر). المراحل تتولد من رقمها:
 * النوع × طريقة البدء × عوامل عشوائية ثابتة (جاذبية، احتكاك، أبعاد...). إضافة نوع جديد = إضافة اسم و case.
 */
object LevelBuilder {
    const val W = 1000f
    const val H = 2400f
    val names = listOf(
        "الدرج الطويل", "متاهة المنحدرات", "لوحة الدبابيس", "حقل القفز", "الدوّارات", "جرف الصخور",
        "المطحنة", "درج النطّاطات", "القمع", "الأرفف", "الزلاجة", "الفوضى"
    )
    val modeNames = listOf("معلّق بخيط", "من المدفع", "بدفعة")

    fun describe(id: Int): String {
        if (id <= 0) return "الساحة الحرة"
        val i = id - 1
        return "${names[(i / 3) % names.size]} — ${modeNames[i % 3]}"
    }

    private fun walls(w: World) {
        w.boxes.add(Box(-300f, -500f, 300f, H + 900f))
        w.boxes.add(Box(W, -500f, 300f, H + 900f))
        w.boxes.add(Box(-300f, H, W + 600f, 400f))
    }

    private fun pegs(w: World, rnd: Random, y0: Float, y1: Float, gap: Float) {
        var row = 0
        var y = y0
        while (y < y1) {
            var x = if (row % 2 == 0) 50f else 100f
            while (x < 980f) {
                if (rnd.nextFloat() > 0.12f) w.segs.add(Seg(x, y, x, y, 14f, 0.5f))
                x += 100f
            }
            y += gap
            row++
        }
    }

    private fun sandbox(): Level {
        val w = World(W, H)
        walls(w)
        w.segs.add(Seg(0f, H - 330f, 330f, H - 170f, 9f))
        w.segs.add(Seg(1000f, H - 480f, 640f, H - 280f, 9f))
        w.boxes.add(Box(700f, H - 650f, 250f, 30f))
        w.boxes.add(Box(380f, H - 30f, 150f, 30f, 1.4f, true))
        for (i in 0 until 5) w.segs.add(Seg(250f + i * 60f, H - 700f + (i % 2) * 40f, 250f + i * 60f, H - 700f + (i % 2) * 40f, 14f, 0.5f))
        val rd = Ragdoll(w, 500f, H - 140f, 1f)
        return Level(0, "الساحة الحرة", w, rd, 3, 0f, 0f, 260f)
    }

    fun build(id: Int): Level {
        if (id <= 0) return sandbox()
        val rnd = Random(id * 7919L + 13L)
        val type = ((id - 1) / 3) % names.size
        val mode = (id - 1) % 3
        val w = World(W, H)
        w.gravity = listOf(1800f, 1800f, 1100f, 2300f)[rnd.nextInt(4)]
        w.friction = 0.05f + rnd.nextFloat() * 0.2f
        walls(w)

        var sx = 150f
        var sy = 400f
        when (type) {
            0 -> {
                val n = 9 + rnd.nextInt(10)
                val sw = 800f / n
                val sh = 1700f / n
                sx = 90f; sy = 400f
                w.boxes.add(Box(0f, 400f, 170f, H - 400f))
                for (i in 0 until n) {
                    val top = 400f + (i + 1) * sh
                    w.boxes.add(Box(170f + i * sw, top, sw + 1f, H - top))
                }
            }
            1 -> {
                val rows = 6 + rnd.nextInt(3)
                for (i in 0 until rows) {
                    val y = 450f + i * 220f
                    if (i % 2 == 0) w.segs.add(Seg(0f, y, 850f, y + 150f, 9f))
                    else w.segs.add(Seg(1000f, y, 150f, y + 150f, 9f))
                }
                sx = 120f; sy = 470f
            }
            2 -> {
                pegs(w, rnd, 600f, 2200f, 90f)
                sx = 500f + (rnd.nextFloat() - 0.5f) * 300f
            }
            3 -> {
                for (i in 0 until 10) {
                    w.boxes.add(Box(40f + rnd.nextFloat() * 780f, 700f + i * 160f, 150f, 24f, 1.35f, true))
                }
                sx = 200f
            }
            4 -> {
                val n = 5 + rnd.nextInt(2)
                for (i in 0 until n) {
                    val speed = (if (rnd.nextBoolean()) 1f else -1f) * (2f + rnd.nextFloat() * 2f)
                    w.spinners.add(Spinner(250f + rnd.nextFloat() * 500f, 650f + i * 270f, 170f + rnd.nextFloat() * 100f, speed))
                }
                sx = 500f
            }
            5 -> {
                for (i in 0 until 11) {
                    val y = 550f + i * 160f
                    val len = 350f + rnd.nextFloat() * 150f
                    if (i % 2 == 0) w.boxes.add(Box(0f, y, len, 36f)) else w.boxes.add(Box(W - len, y, len, 36f))
                }
                sx = 120f; sy = 550f
            }
            6 -> {
                for (i in 0 until 3) {
                    val speed = (if (rnd.nextBoolean()) 1f else -1f) * (2f + rnd.nextFloat() * 1.5f)
                    w.spinners.add(Spinner(300f + rnd.nextFloat() * 400f, 700f + i * 350f, 220f, speed))
                }
                pegs(w, rnd, 1800f, 2250f, 110f)
                sx = 500f
            }
            7 -> {
                val n = 8 + rnd.nextInt(5)
                val sw = 800f / n
                val sh = 1700f / n
                sx = 90f; sy = 400f
                w.boxes.add(Box(0f, 400f, 170f, H - 400f))
                for (i in 0 until n) {
                    val top = 400f + (i + 1) * sh
                    val pad = i > 0 && rnd.nextFloat() < 0.35f
                    w.boxes.add(if (pad) Box(170f + i * sw, top, sw + 1f, H - top, 1.3f, true) else Box(170f + i * sw, top, sw + 1f, H - top))
                }
            }
            8 -> {
                w.segs.add(Seg(0f, 700f, 400f, 1500f, 9f))
                w.segs.add(Seg(1000f, 900f, 600f, 1500f, 9f))
                w.spinners.add(Spinner(500f, 1700f, 200f, 3f))
                pegs(w, rnd, 1900f, 2250f, 110f)
                sx = 250f; sy = 600f
            }
            9 -> {
                for (i in 0 until 22) w.boxes.add(Box(rnd.nextFloat() * 820f, 600f + i * 80f, 120f + rnd.nextFloat() * 140f, 26f))
                sx = 500f
            }
            10 -> {
                var px = 40f
                var py = 500f
                val n = 14
                for (i in 1..n) {
                    val x = 40f + i * (920f / n)
                    val y = 500f + i * 100f + 110f * sin(i * 0.9f)
                    w.segs.add(Seg(px, py, x, y, 9f))
                    px = x; py = y
                }
                w.boxes.add(Box(650f, 2150f, 300f, 24f, 1.4f, true))
                sx = 70f; sy = 470f
            }
            else -> {
                for (i in 0 until 14) {
                    val cx = 100f + rnd.nextFloat() * 800f
                    val y = 600f + i * 115f
                    val half = 90f + rnd.nextFloat() * 80f
                    val tilt = (30f + rnd.nextFloat() * 60f) * (if (rnd.nextBoolean()) 1f else -1f)
                    w.segs.add(Seg(cx - half, y - tilt, cx + half, y + tilt, 9f))
                }
                sx = 500f
            }
        }
        if (type in intArrayOf(2, 3, 4, 6, 8, 9, 11)) w.boxes.add(Box(sx - 80f, sy, 160f, 30f))

        val rd = Ragdoll(w, sx, sy - 58f, 1f)
        var lvx = 0f
        var lvy = 0f
        when (mode) {
            0 -> {
                val pt = listOf(rd.haL, rd.ftL, rd.hipL)[rnd.nextInt(3)]
                val upLen = 110f + rnd.nextFloat() * 100f
                var off = (60f + rnd.nextFloat() * 120f) * (if (rnd.nextBoolean()) 1f else -1f)
                if (pt.x + off < 40f || pt.x + off > 960f) off = -off
                w.rope = Rope(pt.x + off, pt.y - upLen, pt, hypot(off, upLen))
            }
            1 -> {
                w.frozen = true
                lvx = 300f + rnd.nextFloat() * 500f
                lvy = -(500f + rnd.nextFloat() * 900f)
            }
            else -> {
                w.frozen = true
                lvx = 250f + rnd.nextFloat() * 300f
                lvy = -150f
            }
        }
        return Level(id, "${describe(id)}  #$id", w, rd, mode, lvx, lvy, rnd.nextFloat() * 360f)
    }
}
