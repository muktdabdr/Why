package com.why.game

import java.util.Random
import kotlin.math.hypot

/** mode: 0 = معلّق بخيط (المس لقطعه)، 1 = مدفع، 2 = دفعة. */
class Level(
    val id: Int,
    val title: String,
    val world: World,
    val rd: Ragdoll,
    val mode: Int,
    val launchVx: Float,
    val launchVy: Float,
    val hue: Float,
)

/**
 * كل "نوع" مرحلة = دالة تبني الأرضية (حوالي 10 أسطر). المراحل تتولد من رقمها:
 * النوع × طريقة البدء × عوامل عشوائية ثابتة (جاذبية، احتكاك، أبعاد...). إضافة نوع جديد = إضافة اسم و case.
 */
object LevelBuilder {
    const val W = 1000f
    const val H = 2400f
    val names = listOf("الدرج الطويل", "متاهة المنحدرات", "لوحة الدبابيس", "حقل القفز", "الدوّارات", "جرف الصخور")
    val modeNames = listOf("معلّق بخيط", "من المدفع", "بدفعة")

    fun describe(id: Int): String {
        val i = (id - 1).coerceAtLeast(0)
        return "${names[i % names.size]} — ${modeNames[(i / names.size) % 3]}"
    }

    fun build(id: Int): Level {
        val rnd = Random(id * 7919L + 13L)
        val type = (id - 1).coerceAtLeast(0) % names.size
        val mode = ((id - 1).coerceAtLeast(0) / names.size) % 3
        val w = World(W, H)
        w.gravity = listOf(1800f, 1800f, 1100f, 2300f)[rnd.nextInt(4)]
        w.friction = 0.05f + rnd.nextFloat() * 0.2f

        w.boxes.add(Box(-300f, -500f, 300f, H + 900f))
        w.boxes.add(Box(W, -500f, 300f, H + 900f))
        w.boxes.add(Box(-300f, H, W + 600f, 400f))

        var sx = 150f
        var sy = 400f
        var dir = 1f
        when (type) {
            0 -> {
                val n = 9 + rnd.nextInt(10)
                val sw = 800f / n
                val sh = 1700f / n
                sx = 90f; sy = 400f
                w.boxes.add(Box(0f, 400f, 170f, H - 400f))
                for (i in 0 until n) {
                    val x0 = 170f + i * sw
                    val top = 400f + (i + 1) * sh
                    w.boxes.add(Box(x0, top, sw + 1f, H - top))
                }
            }
            1 -> {
                val rows = 6 + rnd.nextInt(3)
                for (i in 0 until rows) {
                    val y = 450f + i * 220f
                    if (i % 2 == 0) w.segs.add(Seg(0f, y, 850f, y + 150f, 9f))
                    else w.segs.add(Seg(1000f, y, 150f, y + 150f, 9f))
                }
                sx = 120f; sy = 470f
            }
            2 -> {
                var row = 0
                var y = 600f
                while (y < 2200f) {
                    val off = if (row % 2 == 0) 50f else 100f
                    var x = off
                    while (x < 980f) {
                        if (rnd.nextFloat() > 0.12f) w.segs.add(Seg(x, y, x, y, 14f, 0.5f))
                        x += 100f
                    }
                    y += 90f
                    row++
                }
                sx = 500f + (rnd.nextFloat() - 0.5f) * 300f; sy = 400f
                w.boxes.add(Box(sx - 60f, sy, 120f, 30f))
            }
            3 -> {
                for (i in 0 until 10) {
                    val y = 700f + i * 160f
                    val x = 40f + rnd.nextFloat() * 780f
                    w.boxes.add(Box(x, y, 150f, 24f, 1.35f, true))
                }
                sx = 200f; sy = 400f
                w.boxes.add(Box(sx - 90f, sy, 180f, 30f))
            }
            4 -> {
                val n = 5 + rnd.nextInt(2)
                for (i in 0 until n) {
                    val cx = 250f + rnd.nextFloat() * 500f
                    val half = 170f + rnd.nextFloat() * 100f
                    val speed = (if (rnd.nextBoolean()) 1f else -1f) * (2f + rnd.nextFloat() * 2f)
                    w.spinners.add(Spinner(cx, 650f + i * 270f, half, speed))
                }
                sx = 500f; sy = 400f
                w.boxes.add(Box(sx - 90f, sy, 180f, 30f))
            }
            else -> {
                for (i in 0 until 11) {
                    val y = 550f + i * 160f
                    val len = 350f + rnd.nextFloat() * 150f
                    if (i % 2 == 0) w.boxes.add(Box(0f, y, len, 36f))
                    else w.boxes.add(Box(W - len, y, len, 36f))
                }
                sx = 120f; sy = 550f
            }
        }

        val rd = Ragdoll(w, sx, sy - 58f, 1f)
        var lvx = 0f
        var lvy = 0f
        when (mode) {
            0 -> {
                val pt = listOf(rd.haL, rd.ftL, rd.hipL)[rnd.nextInt(3)]
                val upLen = 110f + rnd.nextFloat() * 100f
                var off = (60f + rnd.nextFloat() * 120f) * (if (rnd.nextBoolean()) 1f else -1f)
                if (pt.x + off < 40f || pt.x + off > 960f) off = -off
                w.rope = Rope(pt.x + off, pt.y - upLen, pt, hypot(off, upLen))
            }
            1 -> {
                w.frozen = true
                lvx = dir * (300f + rnd.nextFloat() * 500f)
                lvy = -(500f + rnd.nextFloat() * 900f)
            }
            else -> {
                w.frozen = true
                lvx = dir * (250f + rnd.nextFloat() * 300f)
                lvy = -150f
            }
        }
        return Level(id, "${describe(id)}  #$id", w, rd, mode, lvx, lvy, rnd.nextFloat() * 360f)
    }
}
