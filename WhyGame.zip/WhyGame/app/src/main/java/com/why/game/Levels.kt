package com.why.game

import java.util.Random
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** مهمة المستوى. kind: 0 نجوم، 1 قلوب، 2 منطقة خضراء، 3 ألم، 4 كسور، 5 نجاة بأقل كسور. */
class Mission(val kind: Int, val target: Int, val text: String)

/** عنصر يُجمع (kind 0 = نجمة، 1 = قلب). */
class Item(val x: Float, val y: Float, val kind: Int) {
    var taken = false
}

class Fighter(val id: Int, val team: Int, val rd: Ragdoll, val look: Look?) {
    var hp = 100f
    var ko = false
    var jumpCd = 1f
    var atkCd = 0.5f
    var flash = 0f
}

/** mode: 0 = معلّق بخيط، 1 = مدفع، 2 = دفعة، 3 = ساحة الحرب. */
class Level(
    val id: Int,
    val title: String,
    val world: World,
    val fighters: List<Fighter>,
    val mode: Int,
    val launchVx: Float,
    val launchVy: Float,
    val hue: Float,
    val mission: Mission?,
    val items: List<Item>,
    val goalX: Float,
) {
    val rd: Ragdoll get() = fighters[0].rd
}

object Shapes {
    fun ngon(cx: Float, cy: Float, r: Float, n: Int, rot: Float): FloatArray {
        val a = FloatArray(n * 2)
        for (i in 0 until n) {
            val ang = rot + i * 6.2831855f / n
            a[2 * i] = cx + cos(ang) * r
            a[2 * i + 1] = cy + sin(ang) * r
        }
        return a
    }

    fun star(cx: Float, cy: Float, r: Float, rot: Float): FloatArray {
        val a = FloatArray(20)
        for (i in 0 until 10) {
            val rr = if (i % 2 == 0) r else r * 0.45f
            val ang = rot - 1.5708f + i * 0.62831855f
            a[2 * i] = cx + cos(ang) * rr
            a[2 * i + 1] = cy + sin(ang) * rr
        }
        return a
    }

    fun heart(cx: Float, cy: Float, s: Float, n: Int = 22): FloatArray {
        val a = FloatArray(n * 2)
        for (i in 0 until n) {
            val t = i * 6.2831855f / n
            val x = 16f * sin(t) * sin(t) * sin(t)
            val y = -(13f * cos(t) - 5f * cos(2f * t) - 2f * cos(3f * t) - cos(4f * t))
            a[2 * i] = cx + x * s / 16f
            a[2 * i + 1] = cy + y * s / 16f
        }
        return a
    }
}

/**
 * كل مستوى = بداية (منصة) + عدة أقسام سقوط. كل قسم "نوع" يُبنى بدالة قصيرة.
 * عدد الأقسام يزيد مع رقم المستوى (2 إلى 5)، والمهمة تتغير، والمستويات تُفتح بالتسلسل.
 */
object LevelBuilder {
    const val W = 1000f
    const val SECTION = 1900f
    const val TOP = 700f
    const val TYPES = 16
    val modeNames = listOf("معلّق بخيط", "من المدفع", "بدفعة")

    fun sectionsFor(id: Int) = 2 + min(3, (id - 1) / 8)

    fun describe(id: Int): String {
        if (id <= 0) return "ساحة الحرب"
        return "المستوى $id — ${modeNames[(id - 1) % 3]}"
    }

    private fun walls(w: World, h: Float) {
        w.boxes.add(Box(-300f, -500f, 300f, h + 900f))
        w.boxes.add(Box(W, -500f, 300f, h + 900f))
        w.boxes.add(Box(-300f, h, W + 600f, 400f))
    }

    private fun pegs(w: World, rnd: Random, y0: Float, y1: Float, gap: Float) {
        var row = 0
        var y = y0
        while (y < y1) {
            var x = if (row % 2 == 0) 50f else 100f
            while (x < 980f) {
                if (rnd.nextFloat() > 0.12f) w.segs.add(Seg(x, y, x, y, 14f, 0.5f))
                x += 100f
            }
            y += gap
            row++
        }
    }

    private fun poly(w: World, pts: FloatArray, color: Int, bounce: Float = 0.3f) {
        w.shapes.add(Shape(pts, color))
        val n = pts.size / 2
        for (i in 0 until n) {
            val j = (i + 1) % n
            w.segs.add(Seg(pts[2 * i], pts[2 * i + 1], pts[2 * j], pts[2 * j + 1], 8f, bounce))
        }
    }

    private fun section(w: World, rnd: Random, type: Int, oy: Float, last: Boolean, h: Float) {
        when (type) {
            0, 7 -> {
                val n = 7 + rnd.nextInt(8)
                val sw = 620f / n
                val sh = 1500f / n
                val bottom = if (last) h else oy + 1700f
                for (i in 0 until n) {
                    val top = oy + (i + 1) * sh
                    val pad = type == 7 && i > 0 && rnd.nextFloat() < 0.35f
                    w.boxes.add(if (pad) Box(170f + i * sw, top, sw + 1f, bottom - top, 1.3f, true) else Box(170f + i * sw, top, sw + 1f, bottom - top))
                }
            }
            1 -> {
                val rows = 5 + rnd.nextInt(3)
                for (i in 0 until rows) {
                    val y = oy + i * 250f
                    if (i % 2 == 0) w.segs.add(Seg(0f, y, 850f, y + 150f, 9f)) else w.segs.add(Seg(1000f, y, 150f, y + 150f, 9f))
                }
            }
            2 -> pegs(w, rnd, oy, oy + 1700f, 90f)
            3 -> for (i in 0 until 10) w.boxes.add(Box(40f + rnd.nextFloat() * 780f, oy + i * 160f, 150f, 24f, 1.35f, true))
            4 -> for (i in 0 until 6) {
                val speed = (if (rnd.nextBoolean()) 1f else -1f) * (2f + rnd.nextFloat() * 2f)
                w.spinners.add(Spinner(250f + rnd.nextFloat() * 500f, oy + 100f + i * 270f, 170f + rnd.nextFloat() * 100f, speed))
            }
            5 -> for (i in 0 until 10) {
                val y = oy + i * 160f
                val len = 350f + rnd.nextFloat() * 150f
                if (i % 2 == 0) w.boxes.add(Box(0f, y, len, 36f)) else w.boxes.add(Box(W - len, y, len, 36f))
            }
            6 -> {
                for (i in 0 until 3) {
                    val speed = (if (rnd.nextBoolean()) 1f else -1f) * (2f + rnd.nextFloat() * 1.5f)
                    w.spinners.add(Spinner(300f + rnd.nextFloat() * 400f, oy + 100f + i * 350f, 220f, speed))
                }
                pegs(w, rnd, oy + 1150f, oy + 1700f, 110f)
            }
            8 -> {
                w.segs.add(Seg(0f, oy, 400f, oy + 800f, 9f))
                w.segs.add(Seg(1000f, oy + 200f, 600f, oy + 800f, 9f))
                w.spinners.add(Spinner(500f, oy + 1000f, 200f, 3f))
                pegs(w, rnd, oy + 1200f, oy + 1700f, 110f)
            }
            9 -> for (i in 0 until 20) w.boxes.add(Box(rnd.nextFloat() * 820f, oy + i * 85f, 120f + rnd.nextFloat() * 140f, 26f))
            10 -> {
                var px = 40f
                var py = oy
                val n = 14
                for (i in 1..n) {
                    val x = 40f + i * (920f / n)
                    val y = oy + i * 100f + 110f * sin(i * 0.9f)
                    w.segs.add(Seg(px, py, x, y, 9f))
                    px = x; py = y
                }
                w.boxes.add(Box(650f, oy + 1550f, 300f, 24f, 1.4f, true))
            }
            11 -> for (i in 0 until 14) {
                val cx = 100f + rnd.nextFloat() * 800f
                val y = oy + i * 115f
                val half = 90f + rnd.nextFloat() * 80f
                val tilt = (30f + rnd.nextFloat() * 60f) * (if (rnd.nextBoolean()) 1f else -1f)
                w.segs.add(Seg(cx - half, y - tilt, cx + half, y + tilt, 9f))
            }
            12 -> for (i in 0 until 8) poly(w, Shapes.star(120f + rnd.nextFloat() * 760f, oy + 80f + i * 200f, 90f + rnd.nextFloat() * 50f, rnd.nextFloat() * 6f), i % 6)
            13 -> for (i in 0 until 8) poly(w, Shapes.heart(120f + rnd.nextFloat() * 760f, oy + 80f + i * 200f, 100f + rnd.nextFloat() * 40f), (i + 1) % 6)
            14 -> for (i in 0 until 10) {
                val n = intArrayOf(3, 4, 5, 6)[rnd.nextInt(4)]
                poly(w, Shapes.ngon(100f + rnd.nextFloat() * 800f, oy + 60f + i * 165f, 70f + rnd.nextFloat() * 50f, n, rnd.nextFloat() * 6f), i % 6)
            }
            else -> for (i in 0 until 12) {
                val r = 40f + rnd.nextFloat() * 40f
                val x = 100f + rnd.nextFloat() * 800f
                val y = oy + 60f + i * 135f
                w.segs.add(Seg(x, y, x, y, r, 0.45f))
                w.shapes.add(Shape(floatArrayOf(x, y, r), i % 6, true))
            }
        }
    }

    private fun segDist(x: Float, y: Float, s: Seg): Float {
        val abx = s.bx - s.ax
        val aby = s.by - s.ay
        val l2 = abx * abx + aby * aby
        var t = if (l2 > 0f) ((x - s.ax) * abx + (y - s.ay) * aby) / l2 else 0f
        t = t.coerceIn(0f, 1f)
        return hypot(x - (s.ax + abx * t), y - (s.ay + aby * t))
    }

    private fun free(w: World, x: Float, y: Float): Boolean {
        for (b in w.boxes) if (x > b.x - 30f && x < b.x + b.w + 30f && y > b.y - 30f && y < b.y + b.h + 30f) return false
        for (s in w.segs) if (segDist(x, y, s) < s.th + 30f) return false
        for (sp in w.spinners) if (hypot(x - sp.cx, y - sp.cy) < sp.half + 30f) return false
        return true
    }

    private fun place(w: World, rnd: Random, count: Int, kind: Int, yMin: Float, yMax: Float, out: MutableList<Item>) {
        repeat(count) {
            for (tries in 0 until 40) {
                val x = 80f + rnd.nextFloat() * 840f
                val y = yMin + rnd.nextFloat() * (yMax - yMin)
                if (free(w, x, y)) { out.add(Item(x, y, kind)); break }
            }
        }
    }

    private fun arena(): Level {
        val h = 2200f
        val w = World(W, h)
        w.multi = true
        w.friction = 0.05f
        walls(w, h)
        w.segs.add(Seg(0f, h - 330f, 330f, h - 170f, 9f))
        w.segs.add(Seg(1000f, h - 330f, 670f, h - 170f, 9f))
        w.boxes.add(Box(380f, h - 30f, 240f, 30f, 1.4f, true))
        w.boxes.add(Box(380f, h - 700f, 240f, 28f))
        w.boxes.add(Box(40f, h - 900f, 220f, 28f))
        w.boxes.add(Box(740f, h - 900f, 220f, 28f))
        val rnd = Random(5)
        val fighters = ArrayList<Fighter>()
        for (team in 0..1) {
            for (i in 0 until 5) {
                val id = team * 5 + i
                val x = if (team == 0) 120f + i * 45f else 880f - i * 45f
                val rd = Ragdoll(w, x, h - 160f - i * 150f, 1f, id)
                val look = Look()
                look.randomize(rnd)
                look.shirt = team
                fighters.add(Fighter(id, team, rd, look))
            }
        }
        w.buildIndex()
        return Level(0, "ساحة الحرب", w, fighters, 3, 0f, 0f, 260f, null, emptyList(), 0f)
    }

    private class Geo(
        val w: World, val rd: Ragdoll, val mode: Int, val lvx: Float, val lvy: Float,
        val rnd: Random, val h: Float, val hue: Float,
    )

    private class Sim(val path: List<FloatArray>, val endX: Float, val pain: Int, val fractures: Int, val stuck: Boolean)

    private fun geometry(id: Int, attempt: Int): Geo {
        val rnd = Random(id * 7919L + 13L + attempt * 104729L)
        val nSec = sectionsFor(id)
        val h = TOP + SECTION * nSec
        val w = World(W, h)
        w.gravity = listOf(1800f, 1800f, 1100f, 2300f)[rnd.nextInt(4)]
        w.friction = 0.01f + rnd.nextFloat() * 0.04f
        walls(w, h)

        val sx = 200f + rnd.nextFloat() * 600f
        val sy = 400f
        w.boxes.add(Box(sx - 80f, sy, 160f, 30f))
        var prev = -1
        for (k in 0 until nSec) {
            var t = rnd.nextInt(TYPES)
            if (t == prev) t = (t + 1) % TYPES
            prev = t
            section(w, rnd, t, TOP + k * SECTION, k == nSec - 1, h)
        }

        val rd = Ragdoll(w, sx, sy - 58f, 1f, 0)
        val mode = (id - 1) % 3
        var lvx = 0f
        var lvy = 0f
        when (mode) {
            0 -> {
                val pt = listOf(rd.haL, rd.ftL, rd.hipL)[rnd.nextInt(3)]
                val upLen = 110f + rnd.nextFloat() * 100f
                var off = (60f + rnd.nextFloat() * 120f) * (if (rnd.nextBoolean()) 1f else -1f)
                if (pt.x + off < 40f || pt.x + off > 960f) off = -off
                w.rope = Rope(pt.x + off, pt.y - upLen, pt, hypot(off, upLen))
                w.frozen = true
            }
            1 -> {
                w.frozen = true
                lvx = (if (rnd.nextBoolean()) 1f else -1f) * (300f + rnd.nextFloat() * 500f)
                lvy = -(500f + rnd.nextFloat() * 900f)
            }
            else -> {
                w.frozen = true
                lvx = (if (rnd.nextBoolean()) 1f else -1f) * (250f + rnd.nextFloat() * 300f)
                lvy = -150f
            }
        }
        w.buildIndex()
        return Geo(w, rd, mode, lvx, lvy, rnd, h, rnd.nextFloat() * 360f)
    }

    /** يشغّل المستوى بلا أي تدخل (نفس كود Play) ليعرف المسار الطبيعي والنهاية والألم والكسور. */
    private fun simulate(g: Geo): Sim {
        val lv = Level(-1, "sim", g.w, listOf(Fighter(0, 0, g.rd, null)), g.mode, g.lvx, g.lvy, g.hue, null, emptyList(), 0f)
        val pl = Play(lv)
        pl.simMode = true
        pl.start()
        val path = ArrayList<FloatArray>()
        var calm = 0f
        var rested = false
        var f = 0
        while (f < 4200) {
            pl.update(1f / 60f)
            if (f % 8 == 0) path.add(floatArrayOf(g.rd.hipL.x, g.rd.hipL.y))
            var fastest = 0f
            for (p in g.w.points) fastest = max(fastest, hypot(p.x - p.px, p.y - p.py) / World.DT)
            if (fastest < 40f) calm += 1f / 60f else calm = 0f
            if (calm > 1.0f) { rested = true; break }
            f++
        }
        val hx = (g.rd.hipL.x + g.rd.hipR.x) / 2f
        val hy = (g.rd.hipL.y + g.rd.hipR.y) / 2f
        return Sim(path, hx, pl.pain, pl.fractures, !rested || hy < g.h - 300f)
    }

    /** يضع النجوم والقلوب على المسار الطبيعي للسقوط، فيجمعها اللاعب حتى دون جهد. */
    private fun pathItems(path: List<FloatArray>, rnd: Random, nStars: Int, nHearts: Int): List<Item> {
        val need = nStars + nHearts
        val cand = ArrayList<FloatArray>()
        var spacing = 220f
        while (true) {
            cand.clear()
            var lx = 0f
            var ly = 0f
            var first = true
            for (k in 8 until path.size) {
                val p = path[k]
                if (first || hypot(p[0] - lx, p[1] - ly) >= spacing) {
                    cand.add(p); lx = p[0]; ly = p[1]; first = false
                }
            }
            if (cand.size >= need || spacing <= 40f) break
            spacing *= 0.7f
        }
        val n = min(need, cand.size)
        val kinds = ArrayList<Int>()
        repeat(nStars) { kinds.add(0) }
        repeat(nHearts) { kinds.add(1) }
        kinds.shuffle(rnd)
        val out = ArrayList<Item>()
        for (j in 0 until n) {
            val idx = ((j + 0.5f) * cand.size / n).toInt().coerceIn(0, cand.size - 1)
            val p = cand[idx]
            out.add(Item(p[0] + (rnd.nextFloat() - 0.5f) * 16f, p[1] + (rnd.nextFloat() - 0.5f) * 16f, kinds[j]))
        }
        return out
    }

    fun build(id: Int): Level {
        if (id <= 0) return arena()
        var attempt = 0
        var sim = simulate(geometry(id, 0))
        while (sim.stuck && attempt < 5) {
            attempt++
            sim = simulate(geometry(id, attempt))
        }
        val g = geometry(id, attempt)
        val rnd = g.rnd
        val n = id - 1
        var kind = (n / 3 + n) % 6
        if (kind == 4 && sim.fractures < 2) kind = 3

        val items = ArrayList<Item>(pathItems(sim.path, rnd, if (kind == 0) min(2 + id / 6, 8) else 3, if (kind == 1) min(1 + id / 10, 5) else 1))
        val pathStars = items.count { it.kind == 0 }
        val pathHearts = items.count { it.kind == 1 }
        place(g.w, rnd, 3, 0, TOP, g.h - 300f, items)
        if (kind == 0 && pathStars < 1) kind = 3
        if (kind == 1 && pathHearts < 1) kind = 3

        var goalX = 0f
        val mission = when (kind) {
            0 -> Mission(0, pathStars, "اجمع $pathStars نجوم")
            1 -> Mission(1, pathHearts, "اجمع $pathHearts قلوب")
            2 -> { goalX = (sim.endX + (rnd.nextFloat() - 0.5f) * 120f).coerceIn(220f, 780f); Mission(2, 0, "اهبط على المنطقة الخضراء") }
            3 -> { val t = max(5, (sim.pain * 0.6f).toInt()); Mission(3, t, "تسبب بألم $t") }
            4 -> { val t = max(1, (sim.fractures * 0.6f).toInt()); Mission(4, t, "اكسر $t عظام") }
            else -> { val t = min(12, sim.fractures + 2); Mission(5, t, "أنهِ بـ $t كسور أو أقل") }
        }
        return Level(id, "المستوى $id", g.w, listOf(Fighter(0, 0, g.rd, null)), g.mode, g.lvx, g.lvy, g.hue, mission, items, goalX)
    }
}
