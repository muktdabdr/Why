package com.why.game

import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsTest {
    @Test
    fun pointFallsAndRestsOnFloor() {
        val w = World(1000f, 1000f)
        w.boxes.add(Box(0f, 900f, 1000f, 300f))
        val p = Pt(500f, 100f, 7f)
        w.points.add(p)
        repeat(800) { w.step(World.DT) }
        assertTrue(p.y <= 900f)
        assertTrue(p.y > 870f)
    }

    @Test
    fun frozenWorldDoesNotMove() {
        val w = World(1000f, 1000f)
        val p = Pt(500f, 100f, 7f)
        w.points.add(p)
        w.frozen = true
        repeat(60) { w.step(World.DT) }
        assertEquals(100f, p.y, 0.001f)
    }

    @Test
    fun ragdollKeepsStickLengthsInFreeFall() {
        val w = World(1000f, 100000f)
        Ragdoll(w, 500f, 100f, 1f)
        repeat(120) { w.step(World.DT) }
        for (s in w.sticks) {
            val d = hypot(s.a.x - s.b.x, s.a.y - s.b.y)
            assertEquals(s.len, d, s.len * 0.03f)
        }
    }

    @Test
    fun allLevelsBuild() {
        for (id in 0..200) {
            val l = LevelBuilder.build(id)
            assertEquals(14, l.rd.pts.size)
            assertTrue(l.title.isNotEmpty())
            if (l.mode == 0) assertNotNull(l.world.rope)
        }
    }

    @Test
    fun startLaunchesCannonLevel() {
        val play = Play(LevelBuilder.build(2))
        assertEquals(1, play.level.mode)
        play.start()
        assertTrue(play.started)
    }

    @Test
    fun punchPushesCharacterInSandbox() {
        val play = Play(LevelBuilder.build(0))
        play.tool = 1
        val hip = play.level.rd.hipL
        val before = hip.px
        play.pressAt(hip.x + 20f, hip.y)
        assertNotEquals(before, hip.px)
        assertTrue(play.pain > 0)
    }

    @Test
    fun toolsDoNothingWhileFrozen() {
        val play = Play(LevelBuilder.build(2))
        play.tool = 1
        val hip = play.level.rd.hipL
        val before = hip.px
        play.pressAt(hip.x + 20f, hip.y)
        assertEquals(before, hip.px, 0f)
    }

    @Test
    fun grabPullsPointTowardFinger() {
        val play = Play(LevelBuilder.build(0))
        play.tool = 0
        val hand = play.level.rd.haL
        play.pressAt(hand.x, hand.y)
        play.dragTo(hand.x - 300f, hand.y - 300f)
        val startX = hand.x
        repeat(30) { play.update(World.DT) }
        assertTrue(hand.x < startX)
        play.release()
    }

    @Test
    fun soundsAreGeneratedAndAudible() {
        val all = Synth.all()
        assertTrue(all.size >= 13)
        for ((_, data) in all) {
            assertTrue(data.isNotEmpty())
            val peak = data.maxOf { kotlin.math.abs(it.toInt()) }
            assertTrue(peak in 1000..32767)
        }
    }
}
