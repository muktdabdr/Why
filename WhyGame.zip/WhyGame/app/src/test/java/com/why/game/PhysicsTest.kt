package com.why.game

import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsTest {
    @Test
    fun pointFallsAndRestsOnFloor() {
        val w = World(1000f, 1000f)
        w.boxes.add(Box(0f, 900f, 1000f, 300f))
        val p = Pt(500f, 100f, 7f)
        w.points.add(p)
        repeat(800) { w.step(World.DT) }
        assertTrue(p.y <= 900f)
        assertTrue(p.y > 870f)
    }

    @Test
    fun frozenWorldDoesNotMove() {
        val w = World(1000f, 1000f)
        val p = Pt(500f, 100f, 7f)
        w.points.add(p)
        w.frozen = true
        repeat(60) { w.step(World.DT) }
        assertEquals(100f, p.y, 0.001f)
    }

    @Test
    fun ragdollKeepsStickLengthsInFreeFall() {
        val w = World(1000f, 100000f)
        Ragdoll(w, 500f, 100f, 1f)
        repeat(120) { w.step(World.DT) }
        for (s in w.sticks) {
            val d = hypot(s.a.x - s.b.x, s.a.y - s.b.y)
            assertEquals(s.len, d, s.len * 0.03f)
        }
    }

    @Test
    fun allLevelsBuild() {
        for (id in 1..120) {
            val l = LevelBuilder.build(id)
            assertEquals(14, l.rd.pts.size)
            assertTrue(l.title.isNotEmpty())
            if (l.mode == 0) assertNotNull(l.world.rope)
        }
    }

    @Test
    fun tapStartsCannonLevel() {
        val play = Play(LevelBuilder.build(7))
        assertTrue(play.level.mode == 1)
        play.tap()
        assertTrue(play.started)
    }
}
