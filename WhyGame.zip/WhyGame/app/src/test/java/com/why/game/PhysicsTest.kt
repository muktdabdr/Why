package com.why.game

import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsTest {
    @Test
    fun pointFallsAndRestsOnFloor() {
        val w = World(1000f, 1000f)
        w.boxes.add(Box(0f, 900f, 1000f, 300f))
        val p = Pt(500f, 100f, 7f)
        w.points.add(p)
        repeat(800) { w.step(World.DT) }
        assertTrue(p.y <= 900f)
        assertTrue(p.y > 870f)
    }

    @Test
    fun frozenWorldDoesNotMove() {
        val w = World(1000f, 1000f)
        val p = Pt(500f, 100f, 7f)
        w.points.add(p)
        w.frozen = true
        repeat(60) { w.step(World.DT) }
        assertEquals(100f, p.y, 0.001f)
    }

    @Test
    fun ragdollKeepsStickLengthsInFreeFall() {
        val w = World(1000f, 100000f)
        Ragdoll(w, 500f, 100f, 1f)
        repeat(120) { w.step(World.DT) }
        for (s in w.sticks) {
            val d = hypot(s.a.x - s.b.x, s.a.y - s.b.y)
            assertEquals(s.len, d, s.len * 0.03f)
        }
    }

    @Test
    fun allLevelsBuildWithMissionAndItems() {
        for (id in 0..30) {
            val l = LevelBuilder.build(id)
            assertEquals(World.PTS * l.fighters.size, l.world.points.size)
            assertTrue(l.title.isNotEmpty())
            if (id > 0) {
                assertNotNull(l.mission)
                assertTrue(l.items.any { it.kind == 0 })
                if (l.mode == 0) {
                    assertNotNull(l.world.rope)
                    assertTrue(l.world.frozen)
                }
                assertTrue(l.world.h >= 700f + LevelBuilder.SECTION * 2)
            }
        }
    }

    @Test
    fun levelsGetLongerWithProgress() {
        assertTrue(LevelBuilder.build(40).world.h > LevelBuilder.build(1).world.h)
    }

    @Test
    fun startReleasesRopeAndLaunchesCannon() {
        val rope = Play(LevelBuilder.build(1))
        assertTrue(rope.world.frozen)
        rope.start()
        assertTrue(rope.started)
        assertFalse(rope.world.frozen)
        assertNull(rope.world.rope)

        val cannon = Play(LevelBuilder.build(2))
        assertEquals(1, cannon.level.mode)
        cannon.start()
        assertTrue(cannon.started)
    }

    @Test
    fun battleHasTwoTeamsAndRunsWithoutErrors() {
        val play = Play(LevelBuilder.build(0))
        assertEquals(10, play.level.fighters.size)
        assertEquals(5, play.level.fighters.count { it.team == 0 })
        repeat(600) { play.update(1f / 60f) }
        assertTrue(play.teamHp(0) >= 0f)
    }

    @Test
    fun punchPushesCharacterInBattleArena() {
        val play = Play(LevelBuilder.build(0))
        play.tool = 1
        val hip = play.level.rd.hipL
        val before = hip.px
        play.pressAt(hip.x + 20f, hip.y)
        assertNotEquals(before, hip.px)
    }

    @Test
    fun toolsDoNothingWhileFrozen() {
        val play = Play(LevelBuilder.build(2))
        play.tool = 1
        val hip = play.level.rd.hipL
        val before = hip.px
        play.pressAt(hip.x + 20f, hip.y)
        assertEquals(before, hip.px, 0f)
    }

    @Test
    fun grabPullsPointTowardFinger() {
        val play = Play(LevelBuilder.build(0))
        play.tool = 0
        val hand = play.level.rd.haL
        play.pressAt(hand.x, hand.y)
        play.dragTo(hand.x - 300f, hand.y - 300f)
        val startX = hand.x
        repeat(30) { play.update(World.DT) }
        assertTrue(hand.x < startX)
        play.release()
    }

    @Test
    fun missionIsNotDoneAtStart() {
        val play = Play(LevelBuilder.build(1))
        assertFalse(play.won)
        assertEquals(-1f, play.countdown, 0f)
    }

    @Test
    fun progressCodeRoundTrips() {
        val text = "unlocked=7\nstars=1:3,2:2,\nshirt=2\nجولة=ok"
        val code = ProgressCodec.encode(text)
        assertTrue(code.startsWith("WHY1-"))
        assertEquals(text, ProgressCodec.decode("مرحبا\n" + code + "\n"))
        assertNull(ProgressCodec.decode("no code here"))
    }

    @Test
    fun soundsAreGeneratedAndAudible() {
        val all = Synth.all()
        assertTrue(all.size >= 14)
        for ((_, data) in all) {
            assertTrue(data.isNotEmpty())
            val peak = data.maxOf { kotlin.math.abs(it.toInt()) }
            assertTrue(peak in 1000..32767)
        }
    }
}
